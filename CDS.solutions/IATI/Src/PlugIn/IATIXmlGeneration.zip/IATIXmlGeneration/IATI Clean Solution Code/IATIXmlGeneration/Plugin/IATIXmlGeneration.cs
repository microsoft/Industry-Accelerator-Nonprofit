﻿using System;
using IATIXmlGeneration.Utilities;
using Microsoft.Xrm.Sdk;

namespace IATIXmlGeneration.Plugin
{
    public class IATIXmlGeneration : IPlugin
    {
        private ITracingService _tracingService;
        private IPluginExecutionContext _context;
        private IOrganizationServiceFactory _serviceFactory;
        private IOrganizationService _service;

        public void Execute(IServiceProvider serviceProvider)
        {
            //Create the tracing service
            _tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            //Create the context
            _context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            _serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            _service = _serviceFactory.CreateOrganizationService(_context.UserId);

            try
            {
                if (_context.PrimaryEntityName == "msiati_iatifilegeneration")
                {
                    var activityStandard = new ActivityStandard(_tracingService, _service, _context.PrimaryEntityId);
                    activityStandard.GenerateAndAttachXmlFile();

                    var organizationStandard = new OrganizationStandard(_tracingService, _service, _context.PrimaryEntityId);
                    organizationStandard.GenerateAndAttachXmlFile();
                }
                else
                {
                    _tracingService.Trace("Invalid entity. Can only be executed from IATI File Generation entity.");
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace(ex.ToString());
                throw;
            }
        }
    }
}
