﻿using System;
using System.Activities;
using IATIXmlGeneration.Utilities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace IATIXmlGeneration.Workflow_Activity
{
    public class IATIXmlGeneration : CodeActivity
    {
        private ITracingService _tracingService;
        private IWorkflowContext _context;
        private IOrganizationServiceFactory _serviceFactory;
        private IOrganizationService _service;

        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            _tracingService = executionContext.GetExtension<ITracingService>();

            //Create the context
            _context = executionContext.GetExtension<IWorkflowContext>();
            _serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            _service = _serviceFactory.CreateOrganizationService(_context.UserId);

            try
            {
                if (_context.PrimaryEntityName == "msiati_iatifilegeneration")
                {
                    var activityStandard = new ActivityStandard(_tracingService, _service, _context.PrimaryEntityId);
                    activityStandard.GenerateAndAttachXmlFile();

                    var organizationStandard = new OrganizationStandard(_tracingService, _service, _context.PrimaryEntityId);
                    organizationStandard.GenerateAndAttachXmlFile();
                }
                else
                {
                    _tracingService.Trace("Invalid entity. Can only be executed from IATI File Generation entity.");
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace(ex.ToString());
                throw;
            }
        }
    }
}
