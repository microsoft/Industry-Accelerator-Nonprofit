﻿using System;
using Microsoft.Xrm.Sdk;

namespace IATIXmlGeneration.Utilities
{
    public static class EntityExtensions
    {
        /// <summary>
        /// Get the value of an attribute of type AliasedValue.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity"></param>
        /// <param name="attributeKey"></param>
        /// <returns></returns>
        public static T GetAliasedValue<T>(this Entity entity, string attributeKey)
        {
            AliasedValue aliasedValue = entity.GetAttributeValue<object>(attributeKey) as AliasedValue;
            return aliasedValue == null ? default(T) : (T) aliasedValue.Value;
        }

        /// <summary>
        /// Get the value of an attribute of type OptionSetValue
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="attributeKey"></param>
        /// <param name="isAliased"></param>
        /// <returns></returns>
        public static int? GetOptionSetValue(this Entity entity, string attributeKey, bool isAliased = false)
        {
            OptionSetValue optionSetValue = isAliased
                ? entity.GetAliasedValue<object>(attributeKey) as OptionSetValue
                : entity.GetAttributeValue<object>(attributeKey) as OptionSetValue;
            return optionSetValue?.Value;
        }

        /// <summary>
        /// Get the ID of an attribute of type EntityReference
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="attributeKey"></param>
        /// <param name="isAliased"></param>
        /// <returns></returns>
        public static Guid? GetEntityReferenceId(this Entity entity, string attributeKey, bool isAliased = false)
        {
            EntityReference entityReference = isAliased
                ? entity.GetAliasedValue<EntityReference>(attributeKey)
                : entity.GetAttributeValue<EntityReference>(attributeKey);
            return entityReference?.Id;
        }
    }
}
