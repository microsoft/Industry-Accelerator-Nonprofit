﻿using System;

namespace IATIXmlGeneration.Containers
{
    public class Period
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
