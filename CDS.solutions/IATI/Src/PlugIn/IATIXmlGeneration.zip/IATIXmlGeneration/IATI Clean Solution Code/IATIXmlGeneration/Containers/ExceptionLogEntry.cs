﻿using System;

namespace IATIXmlGeneration.Containers
{
    public class ExceptionLogEntry
    {
        public ExceptionLogEntry(DateTime exceptionDate, string exceptionMessage, string exceptionStackTrace)
        {
            ExceptionDate = exceptionDate;
            ExceptionMessage = exceptionMessage;
            ExceptionStackTrace = exceptionStackTrace;
        }

        public DateTime ExceptionDate { get; set; }
        public string ExceptionMessage { get; set; }
        public string ExceptionStackTrace { get; set; }
    }
}
