﻿namespace IATIXmlGeneration.Utilities
{
    public enum NarrativeTranslationEntity
    {
        Account,
        Budget,
        Condition,
        Contact,
        DeliveryFramework,
        DeliveryFrameworkDescription,
        Disbursement,
        DocumentCountry,
        DocumentLink,
        DonorCommitment,
        Expenditure,
        HumanitarianScope,
        Indicator,
        IndicatorValue,
        Location,
        PolicyMarker,
        RecipientCountry,
        RecipientRegion,
        Result,
        Sector,
        Tag,
        Transaction
    }

    public enum TransactionEntity
    {
        Disbursement,
        DonorCommitment,
        Expenditure,
        Transaction
    }

    public enum NarrativeTranslationAttribute
    {
        Undefined = 0,
        Department = 453490002,
        FullName = 453490003,
        JobTitle = 453490004,
        Address1 = 453490005,
        Address2 = 453490006,
        Address3 = 453490007,
        RecipientRegionDescription = 453490008,
        RecipientCountryDescription = 453490009,
        ActivityLocationDescription = 453490010,
        Name = 453490000,
        Description = 453490001
    }

    public enum ActivityStatus
    {
        Cancelled = 844060005,
        Completion = 844060002,
        Implementation = 844060001,
        PipelineIdentification = 844060000,
        PostCompletion = 844060004,
        Suspended = 844060006
    }

    public enum ActivityDateType
    {
        PlannedStart,
        ActualStart,
        PlannedEnd,
        ActualEnd
    }

    public enum BudgetStatus
    {
        Indicative = 453490001,
        Commited = 453490002
    }

    public enum BudgetType
    {
        Original = 453490001,
        Revised = 453490002
    }

    public enum DocumentCategory
    {
        A01 = 453490000,
        A02 = 453490001,
        A03 = 453490002,
        A04 = 453490003,
        A05 = 453490004,
        A06 = 453490005,
        A07 = 453490006,
        A08 = 453490007,
        A09 = 453490008,
        A10 = 453490009,
        A11 = 453490010,
        A12 = 453490011,
        B01 = 453490012,
        B02 = 453490013,
        B03 = 453490014,
        B04 = 453490015,
        B05 = 453490016,
        B06 = 453490017,
        B07 = 453490018,
        B08 = 453490019,
        B09 = 453490020,
        B10 = 453490021,
        B11 = 453490022,
        B12 = 453490023,
        B13 = 453490024,
        B14 = 453490025,
        B15 = 453490026,
        B16 = 453490027,
        B17 = 453490028,
        B18 = 453490029
    }

    public enum DisbursementTransactionType
    {
        Disbursement = 453490002,
        OutgoingCommitment = 453490000,
        OutgoingPledge = 453490001
    }

    public enum DonorCommitmentTransactionType
    {
        IncomingCommitment = 453490000,
        IncomingPledge = 453490001
    }

    public enum ExpenditureTransactionType
    {
        Expenditure = 453490000,
        InterestPayment = 453490001,
        LoanRepayment = 453490002,
        PurchaseOfEquity = 453490004,
        Reimbursement = 453490003
    }

    public enum IndicatorValueType
    {
        Actual = 844060002,
        Baseline = 844060000,
        Target = 844060001
    }

    public enum LocationType
    {
        Administrative = 453490002,
        Child = 453490001,
        Parent = 453490000
    }

    public enum OrganizationBudgetType
    {
        PlannedDisbursement = 453490004,
        RecipientOrganizationBudget = 453490001,
        RecipientCountryBudget = 453490002,
        RecipientRegionBudget = 453490003,
        Total = 453490000
    }

    public enum OrganizationRole
    {
        Funding = 453490000,
        Accountable = 453490001,
        Extending = 453490002,
        Implementing = 453490003
    }
}
