﻿using System.Collections.Generic;
using System.Net.Mime;

namespace IATIXmlGeneration.Utilities
{
    public static class Constants
    {
        public const string IatiVersion = "2.03";
        public const string SrsName = "http://www.opengis.net/def/crs/EPSG/0/4326";
        public const string MimeTypeXml = MediaTypeNames.Text.Xml;
        public const string MimeTypeTxt = MediaTypeNames.Text.Plain;

        #region Format

        public const string DecimalFormatTwoDecimalDigits = "0.##";
        public const string DecimalFormatFiveDecimalDigits = "0.##";
        public const string DateFormatDateOnly = "yyyy-MM-dd";

        #endregion

        #region Connection Roles

        // Document Link
        public const string ConnectionRoleDesignationToDeliveryFramework = "Designation to Delivery Framework";
        public const string ConnectionRoleDocumentLinkToAccount = "Document Link to Account";
        public const string ConnectionRoleDocumentLinkToDeliveryFramework = "Document Link to Delivery Framework";
        public const string ConnectionRoleDocumentLinkToIndicator = "Document Link to Indicator";
        public const string ConnectionRoleDocumentLinkToIndicatorValue = "Document Link to Indicator Value";
        public const string ConnectionRoleDocumentLinkToResult = "Document Link to Result";

        // Related Activity (Delivery Framework)
        public const string ConnectionRoleParentDeliveryFramework = "Parent Delivery Framework";
        public const string ConnectionRoleChildDeliveryFramework = "Child Delivery Framework";
        public const string ConnectionRoleSiblingDeliveryFramework = "Sibling Delivery Framework";
        public const string ConnectionRoleCoFundedDeliveryFramework = "Co-Funded Delivery Framework";
        public const string ConnectionRoleThirdPartyDeliveryFramework = "Third Party Delivery Framework";

        #endregion

        #region Codelists

        public const string GeneralDescriptionTypeCode = "1";

        public static readonly Dictionary<ActivityStatus, string> ActivityStatusIdCodeMapping = new Dictionary<ActivityStatus, string>
        {
            {ActivityStatus.Cancelled, "5"},
            {ActivityStatus.Completion, "3"},
            {ActivityStatus.Implementation, "2"},
            {ActivityStatus.PipelineIdentification, "1"},
            {ActivityStatus.PostCompletion, "4"},
            {ActivityStatus.Suspended, "6"}
        };

        public static readonly Dictionary<ActivityDateType, string> ActivityDateTypeMapping = new Dictionary<ActivityDateType, string>
        {
            {ActivityDateType.PlannedStart, "1"},
            {ActivityDateType.ActualStart, "2"},
            {ActivityDateType.PlannedEnd, "3"},
            {ActivityDateType.ActualEnd, "4"}
        };

        public static readonly Dictionary<BudgetStatus, string> BudgetStatusIdCodeMapping = new Dictionary<BudgetStatus, string>
        {
            {BudgetStatus.Indicative, "1"},
            {BudgetStatus.Commited, "2"}
        };

        public static readonly Dictionary<BudgetType, string> BudgetTypeIdCodeMapping = new Dictionary<BudgetType, string>
        {
            {BudgetType.Original, "1"},
            {BudgetType.Revised, "2"}
        };

        public static readonly Dictionary<DocumentCategory, string> DocumentCategoryIdCodeMapping = new Dictionary<DocumentCategory, string>
        {
            {DocumentCategory.A01, "A01"},
            {DocumentCategory.A02, "A02"},
            {DocumentCategory.A03, "A03"},
            {DocumentCategory.A04, "A04"},
            {DocumentCategory.A05, "A05"},
            {DocumentCategory.A06, "A06"},
            {DocumentCategory.A07, "A07"},
            {DocumentCategory.A08, "A08"},
            {DocumentCategory.A09, "A09"},
            {DocumentCategory.A10, "A10"},
            {DocumentCategory.A11, "A11"},
            {DocumentCategory.A12, "A12"},
            {DocumentCategory.B01, "B01"},
            {DocumentCategory.B02, "B02"},
            {DocumentCategory.B03, "B03"},
            {DocumentCategory.B04, "B04"},
            {DocumentCategory.B05, "B05"},
            {DocumentCategory.B06, "B06"},
            {DocumentCategory.B07, "B07"},
            {DocumentCategory.B08, "B08"},
            {DocumentCategory.B09, "B09"},
            {DocumentCategory.B10, "B10"},
            {DocumentCategory.B11, "B11"},
            {DocumentCategory.B12, "B12"},
            {DocumentCategory.B13, "B13"},
            {DocumentCategory.B14, "B14"},
            {DocumentCategory.B15, "B15"},
            {DocumentCategory.B16, "B16"},
            {DocumentCategory.B17, "B17"},
            {DocumentCategory.B18, "B18"},
        };

        public static readonly Dictionary<DisbursementTransactionType, string> DisbursementTransactionTypeTypeIdCodeMapping = new Dictionary<DisbursementTransactionType, string>
        {
            {DisbursementTransactionType.Disbursement, "3"},
            {DisbursementTransactionType.OutgoingCommitment, "2"},
            {DisbursementTransactionType.OutgoingPledge, "12"},
        };

        public static readonly Dictionary<DonorCommitmentTransactionType, string> DonorCommitmentTransactionTypeTypeIdCodeMapping = new Dictionary<DonorCommitmentTransactionType, string>
        {
            {DonorCommitmentTransactionType.IncomingCommitment, "11"},
            {DonorCommitmentTransactionType.IncomingPledge, "13"}
        };

        public static readonly Dictionary<ExpenditureTransactionType, string> ExpenditureTransactionTypeTypeIdCodeMapping = new Dictionary<ExpenditureTransactionType, string>
        {
            {ExpenditureTransactionType.Expenditure, "4"},
            {ExpenditureTransactionType.InterestPayment, "5"},
            {ExpenditureTransactionType.LoanRepayment, "6"},
            {ExpenditureTransactionType.PurchaseOfEquity, "8"},
            {ExpenditureTransactionType.Reimbursement, "7"},
        };

        public const string CrmTransactionTransactionTypeCode = "1";

        public static readonly Dictionary<OrganizationRole, string> OrganizationRoleIdCodeMapping = new Dictionary<OrganizationRole, string>
        {
            {OrganizationRole.Funding, "1"},
            {OrganizationRole.Accountable, "2"},
            {OrganizationRole.Extending, "3"},
            {OrganizationRole.Implementing, "4"},
        };

        #endregion

        /// <summary>
        /// Mapping of entities that have lookup attributes in the Narrative Translation entity
        /// </summary>
        public static readonly Dictionary<NarrativeTranslationEntity, string> NarrativeTranslationEntityLookupMapping = new Dictionary<NarrativeTranslationEntity, string>
        {
            {NarrativeTranslationEntity.Account, "msiati_accountid"},
            {NarrativeTranslationEntity.Budget, "msiati_budgetid"},
            {NarrativeTranslationEntity.Condition, "msiati_conditionid"},
            {NarrativeTranslationEntity.Contact, "msiati_contactid"},
            {NarrativeTranslationEntity.DeliveryFramework, "msiati_deliveryframeworkdid"},
            {NarrativeTranslationEntity.DeliveryFrameworkDescription, "msiati_deliveryframeworkdescriptionid"},
            {NarrativeTranslationEntity.Disbursement, "msiati_disbursementid"},
            {NarrativeTranslationEntity.DocumentCountry, "msiati_docuemntcountryid"},
            {NarrativeTranslationEntity.DocumentLink, "msiati_documentlinkid"},
            {NarrativeTranslationEntity.DonorCommitment, "msiati_donorcommitmentid"},
            {NarrativeTranslationEntity.Expenditure, "msiati_expenditureid"},
            {NarrativeTranslationEntity.HumanitarianScope, "msiati_humanitarianscopeid"},
            {NarrativeTranslationEntity.Indicator, "msiati_indicatorid"},
            {NarrativeTranslationEntity.IndicatorValue, "msiati_indicatorvalueid"},
            {NarrativeTranslationEntity.Location, "msiati_locationid"},
            {NarrativeTranslationEntity.PolicyMarker, "msiati_policymakerid"},
            {NarrativeTranslationEntity.RecipientCountry, "msiati_recipientcountryid"},
            {NarrativeTranslationEntity.RecipientRegion, "msiati_recipientregionid"},
            {NarrativeTranslationEntity.Result, "msiati_resultid"},
            {NarrativeTranslationEntity.Sector, "msiati_sectorid"},
            {NarrativeTranslationEntity.Tag, "msiati_tagid"},
            {NarrativeTranslationEntity.Transaction, "msiati_transactionid"}
        };

        /// <summary>
        /// Mapping of transaction entities with lookup attributes in Sector entity
        /// </summary>
        public static readonly Dictionary<TransactionEntity, string> SectorTransactionLookupMapping = new Dictionary<TransactionEntity, string>
        {
            {TransactionEntity.Disbursement, "msiati_disbursementid"},
            {TransactionEntity.DonorCommitment, "msiati_donorcommitmentid"},
            {TransactionEntity.Expenditure, "msiati_expenditureid"},
            {TransactionEntity.Transaction, "msiati_transactionid"}
        };

        /// <summary>
        /// Mapping of transaction entities with lookup attributes in Aid Type entity
        /// </summary>
        public static readonly Dictionary<TransactionEntity, string> AidTypeTransactionLookupMapping = new Dictionary<TransactionEntity, string>
        {
            {TransactionEntity.Disbursement, "msiati_disbursementid"},
            {TransactionEntity.DonorCommitment, "msiati_donorcommitmentid"},
            {TransactionEntity.Expenditure, "msiati_expenditureid"},
            {TransactionEntity.Transaction, "msiati_transactionid"}
        };

        /// <summary>
        /// Mapping of transaction entities with lookup attributes in Sector entity
        /// </summary>
        public static readonly Dictionary<TransactionEntity, NarrativeTranslationEntity> TransactionEntityNarrativeTranslationEntityMapping = new Dictionary<TransactionEntity, NarrativeTranslationEntity>
        {
            {TransactionEntity.Disbursement, NarrativeTranslationEntity.Disbursement},
            {TransactionEntity.DonorCommitment, NarrativeTranslationEntity.DonorCommitment},
            {TransactionEntity.Expenditure, NarrativeTranslationEntity.Expenditure},
            {TransactionEntity.Transaction, NarrativeTranslationEntity.Transaction}
        };
    }
}
