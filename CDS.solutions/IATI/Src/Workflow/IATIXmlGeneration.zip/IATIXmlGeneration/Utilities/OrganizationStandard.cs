﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Xml;
using IATIXmlGeneration.Containers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace IATIXmlGeneration.Utilities
{
    public class OrganizationStandard
    {
        #region Member Variables

        private readonly ITracingService _tracingService;
        private readonly IOrganizationService _service;
        private readonly List<ExceptionLogEntry> _exceptionLog;
        private readonly Guid _iatiFileGenerationId;

        #endregion

        #region Constructor

        public OrganizationStandard(ITracingService tracingService, IOrganizationService service, Guid iatiFileGenerationId)
        {
            _tracingService = tracingService;
            _service = service;
            _iatiFileGenerationId = iatiFileGenerationId;
            _exceptionLog = new List<ExceptionLogEntry>();
        }

        #endregion

        #region File Generation

        /// <summary>
        /// Generate the Organization Standard XmlDocument
        /// </summary>
        /// <returns></returns>
        public XmlDocument GenerateXmlFile()
        {
            XmlDocument xmlDocument = XmlUtilities.CreateBaseXmlDocument();
            if (CreateIatiOrganisationsElement(xmlDocument))
            {
                return xmlDocument;
            }

            return null;
        }

        /// <summary>
        /// Generate the Organization Standard XML and attach it as a Note
        /// </summary>
        public void GenerateAndAttachXmlFile()
        {
            string relatedEntityLogicalName = "msiati_iatifilegeneration";

            try
            {
                _tracingService.Trace("Starting Organization file generation.");

                // Generate XmlDocument
                XmlDocument xmlDocument = GenerateXmlFile();

                if (xmlDocument != null)
                {
                    // Convert XmlDocument to Base64 string
                    string xmlDocumentContent = XmlUtilities.XmlDocumentToBase64(xmlDocument);

                    _tracingService.Trace("Organization file generated. Creating Note with file.");

                    // Create note with XML file
                    CommonUtilities.CreateNoteWithAttachment(_service, relatedEntityLogicalName, _iatiFileGenerationId, "IATI Organization file", Constants.MimeTypeXml,
                        "IATI Organization XML file", "IATI Organization.xml", xmlDocumentContent);

                    _tracingService.Trace("Organization Note created.");
                }
                else
                {
                    _tracingService.Trace("Organization file not generated. No organizations found or selected organizations have no IATI information.");
                }
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
            }
            finally
            {
                // Create note with Exception log
                CommonUtilities.CreateExceptionLogNote(_exceptionLog, _service, _tracingService, relatedEntityLogicalName, _iatiFileGenerationId, "Organization Standard Exception Log",
                    "Log of exceptions during Organization Standard file generation");
            }
        }

        #endregion

        #region XML Elements

        #region iati-organisations

        /// <summary>
        /// Create iati-organisations element
        /// </summary>
        /// <param name="xmlDocument"></param>
        private bool CreateIatiOrganisationsElement(XmlDocument xmlDocument)
        {
            try
            {
                // Create iati-organisations element
                XmlElement iatiOrganisationsElement = xmlDocument.CreateElement("iati-organisations");

                // Create version attribute
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, iatiOrganisationsElement, "version", Constants.IatiVersion);

                // Create generated-datetime attribute
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, iatiOrganisationsElement, "generated-datetime", DateTime.Now, "o");

                // Create iati-organisation elements
                bool anyChildElement = CreateIatiOrganisationElements(xmlDocument, iatiOrganisationsElement);

                // If any child element, add parent
                if (anyChildElement)
                {
                    xmlDocument.AppendChild(iatiOrganisationsElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region iati-organisation

        /// <summary>
        /// Create iati-organisations/iati-organisation element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiOrganisationsElement"></param>
        private bool CreateIatiOrganisationElements(XmlDocument xmlDocument, XmlElement iatiOrganisationsElement)
        {
            try
            {
                var accountIdsQueryExpression = new QueryExpression("msiati_iatifilegeneration_account")
                {
                    ColumnSet = new ColumnSet("accountid"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_iatifilegenerationid", ConditionOperator.Equal, _iatiFileGenerationId)
                        }
                    }
                };

                List<Guid> accountIdList = _service.RetrieveMultiple(accountIdsQueryExpression).Entities
                    .Select(t => t.GetAttributeValue<Guid>("accountid"))
                    .ToList();

                if (!accountIdList.Any())
                {
                    return false;
                }

                // Build query to fetch data
                // Some link entities were separated (additional queries) due to CRM limit on the amount of link entities per query
                var accountQueryExpression = new QueryExpression("account")
                {
                    ColumnSet = new ColumnSet(
                        "name",
                        "msiati_iatiorganizationidentifier",
                        "msiati_secondaryreporter"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("accountid", ConditionOperator.In, accountIdList)
                        }
                    },
                    LinkEntities =
                    {
                        // Default Language
                        new LinkEntity(
                            "account",
                            "msiati_nonembeddedcodelist",
                            "msiati_defaultlanguageid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("msiati_code"),
                            EntityAlias = "DefaultLanguage"
                        },
                        // Default Currency
                        new LinkEntity(
                            "account",
                            "transactioncurrency",
                            "msiati_defaultcurrencyid",
                            "transactioncurrencyid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("isocurrencycode"),
                            EntityAlias = "DefaultCurrency"
                        },
                        // Reporting Organization
                        new LinkEntity(
                            "account",
                            "account",
                            "msiati_reportingorganizationid",
                            "accountid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("accountid", "msiati_iatiorganizationidentifier", "name"),
                            EntityAlias = "ReportingOrg",
                            LinkEntities =
                            {
                                // Reporting Organization Type
                                new LinkEntity(
                                    "account",
                                    "msiati_nonembeddedcodelist",
                                    "msiati_organizationtypeid",
                                    "msiati_nonembeddedcodelistid",
                                    JoinOperator.LeftOuter)
                                {
                                    Columns = new ColumnSet("msiati_code"),
                                    EntityAlias = "ReportingOrgType"
                                }
                            }
                        },
                        // Organization Type
                        new LinkEntity(
                            "account",
                            "msiati_nonembeddedcodelist",
                            "msiati_organizationtypeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("msiati_code"),
                            EntityAlias = "OrganizationType"
                        }
                    }
                };

                DataCollection<Entity> accountList = _service.RetrieveMultiple(accountQueryExpression).Entities;

                bool anyChildElement = false;
                foreach (Entity account in accountList)
                {
                    // Create iati-organisation element
                    anyChildElement = CreateIatiOrganisationIndividualElement(xmlDocument, iatiOrganisationsElement, account) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-organisations/iati-organisation element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiOrganisationsElement"></param>
        /// <param name="account"></param>
        private bool CreateIatiOrganisationIndividualElement(XmlDocument xmlDocument, XmlElement iatiOrganisationsElement, Entity account)
        {
            try
            {
                // Create iati-organisation element
                XmlElement iatiOrganisationElement = xmlDocument.CreateElement("iati-organisation");

                // Create last-updated-datetime attribute
                DateTime? modifiedOn = account.GetAttributeValue<DateTime?>("modifiedon");
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, iatiOrganisationElement, "last-updated-datetime", modifiedOn, "o");

                // Create xml:lang attribute
                string defaultLanguage = account.GetAliasedValue<string>("DefaultLanguage.msiati_code");
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, iatiOrganisationElement, "xml:lang", defaultLanguage);

                // Create default-currency attribute
                string defaultCurrencyCode = account.GetAliasedValue<string>("DefaultCurrency.isocurrencycode");
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, iatiOrganisationElement, "default-currency", defaultCurrencyCode);

                Guid accountId = account.Id;

                // Create organisation-identifier element
                bool anyChildElement = CreateOrganisationIdentifierElement(xmlDocument, iatiOrganisationElement, account);

                // Create name element
                anyChildElement = CreateNameElement(xmlDocument, iatiOrganisationElement, account, accountId) || anyChildElement;

                // Create reporting-org element
                anyChildElement = CreateReportingOrgElement(xmlDocument, iatiOrganisationElement, account) || anyChildElement;

                // Create total-budget elements
                anyChildElement =
                    CreateBudgetElements(xmlDocument, iatiOrganisationElement, accountId, defaultCurrencyCode, OrganizationBudgetType.Total) ||
                    anyChildElement;

                // Create recipient-org-budget elements
                anyChildElement =
                    CreateBudgetElements(xmlDocument, iatiOrganisationElement, accountId, defaultCurrencyCode, OrganizationBudgetType.RecipientOrganizationBudget) ||
                    anyChildElement;

                // Create recipient-region-budget elements
                anyChildElement =
                    CreateBudgetElements(xmlDocument, iatiOrganisationElement, accountId, defaultCurrencyCode, OrganizationBudgetType.RecipientRegionBudget) ||
                    anyChildElement;

                // Create recipient-country-budget elements
                anyChildElement =
                    CreateBudgetElements(xmlDocument, iatiOrganisationElement, accountId, defaultCurrencyCode, OrganizationBudgetType.RecipientCountryBudget) ||
                    anyChildElement;

                // Create total-expenditure elements
                anyChildElement = CreateTotalExpenditureElements(xmlDocument, iatiOrganisationElement, accountId, defaultCurrencyCode) || anyChildElement;

                // Create document-link elements
                anyChildElement =
                    CommonUtilities.CreateDocumentLinkElements(_service, _tracingService, _exceptionLog, xmlDocument, iatiOrganisationElement, accountId,
                        Constants.ConnectionRoleDocumentLinkToAccount, true) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiOrganisationsElement.AppendChild(iatiOrganisationElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region iati-identifier

        /// <summary>
        /// Create iati-organisations/iati-organisation/organisation-identifier element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiOrganisationElement"></param>
        /// <param name="account"></param>
        private bool CreateOrganisationIdentifierElement(XmlDocument xmlDocument, XmlElement iatiOrganisationElement, Entity account)
        {
            try
            {
                string organisationIdentifier = account.GetAttributeValue<string>("msiati_iatiorganizationidentifier");
                if (!string.IsNullOrWhiteSpace(organisationIdentifier))
                {
                    // Create organisation-identifier element
                    XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, iatiOrganisationElement, "organisation-identifier", organisationIdentifier);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region name

        /// <summary>
        /// Create iati-organisations/iati-organisation/name element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiOrganisationElement"></param>
        /// <param name="account"></param>
        /// <param name="accountId"></param>
        private bool CreateNameElement(XmlDocument xmlDocument, XmlElement iatiOrganisationElement, Entity account, Guid accountId)
        {
            try
            {
                // Create name and narrative elements
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, iatiOrganisationElement, account, "name", false, accountId, NarrativeTranslationEntity.Account,
                    NarrativeTranslationAttribute.Name, true, "name");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region reporting-org

        /// <summary>
        /// Create iati-organisations/iati-organisation/reporting-org element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiOrganisationElement"></param>
        /// <param name="account"></param>
        private bool CreateReportingOrgElement(XmlDocument xmlDocument, XmlElement iatiOrganisationElement, Entity account)
        {
            try
            {
                string @ref;
                string typeCode;
                Guid reportingOrgAccountId;
                bool reportingAccountSpecified = false;

                if (account.Contains("ReportingOrg.accountid"))
                {
                    @ref = account.GetAliasedValue<string>("ReportingOrg.msiati_iatiorganizationidentifier");
                    typeCode = account.GetAliasedValue<string>("ReportingOrgType.msiati_code");
                    reportingOrgAccountId = account.GetAliasedValue<Guid>("ReportingOrg.accountid");
                    reportingAccountSpecified = true;
                }
                else
                {
                    @ref = account.GetAttributeValue<string>("msiati_iatiorganizationidentifier");
                    typeCode = account.GetAliasedValue<string>("OrganizationType.msiati_code");
                    reportingOrgAccountId = account.Id;
                }

                // Create reporting-org element
                XmlElement reportingOrgElement = xmlDocument.CreateElement("reporting-org");

                // Create ref attribute
                bool anyChildElement = !string.IsNullOrWhiteSpace(@ref);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, reportingOrgElement, "ref", @ref);

                // Create type attribute
                anyChildElement = !string.IsNullOrWhiteSpace(typeCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, reportingOrgElement, "type", typeCode);

                // Create secondary-reporter attribute
                string secondaryReporter = account.GetAttributeValue<bool?>("msiati_secondaryreporter") == true ? "1" : "0";
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, reportingOrgElement, "secondary-reporter", secondaryReporter);

                if (reportingAccountSpecified)
                {
                    // Create narrative elements
                    anyChildElement =
                        CommonUtilities.CreateNarrativeElements(_service, xmlDocument, reportingOrgElement, account, "ReportingOrg.name", true, reportingOrgAccountId,
                            NarrativeTranslationEntity.Account, NarrativeTranslationAttribute.Name, false) || anyChildElement;
                }
                else
                {
                    // Create narrative elements
                    anyChildElement =
                        CommonUtilities.CreateNarrativeElements(_service, xmlDocument, reportingOrgElement, account, "name", false, reportingOrgAccountId,
                            NarrativeTranslationEntity.Account, NarrativeTranslationAttribute.Name, false) || anyChildElement;
                }

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiOrganisationElement.AppendChild(reportingOrgElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region budget (total-budget, recipient-org-budget, recipient-region-budget, recipient-country-budget)

        /// <summary>
        /// Create budget elements (total-budget, recipient-org-budget, recipient-region-budget, recipient-country-budget)
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiOrganisationElement"></param>
        /// <param name="accountId"></param>
        /// <param name="defaultCurrencyCode"></param>
        /// <param name="organizationBudgetType"></param>
        private bool CreateBudgetElements(XmlDocument xmlDocument, XmlElement iatiOrganisationElement, Guid accountId, string defaultCurrencyCode, OrganizationBudgetType organizationBudgetType)
        {
            try
            {
                // Build query to fetch data
                var budgetQueryExpression = new QueryExpression("msnfp_budget")
                {
                    ColumnSet =
                        new ColumnSet("msiati_budgetstatus", "msnfp_startdate", "msnfp_enddate", "msnfp_totalbudget", "msiati_currencyvaluedate",
                            "msiati_recipientregiondescription", "msiati_recipientcountrydescription"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_accountid", ConditionOperator.Equal, accountId),
                            new ConditionExpression("msiati_parentbudgetid", ConditionOperator.Null),
                            new ConditionExpression("msiati_budgettype", ConditionOperator.Equal, (int) organizationBudgetType)
                        }
                    },
                    LinkEntities =
                    {
                        // Currency
                        new LinkEntity(
                            "msnfp_budget",
                            "transactioncurrency",
                            "transactioncurrencyid",
                            "transactioncurrencyid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "Currency",
                            Columns = new ColumnSet("isocurrencycode")
                        },
                        // Recipient Organization
                        new LinkEntity(
                            "msnfp_budget",
                            "account",
                            "msiati_recipientorganizationid",
                            "accountid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "RecipientOrganization",
                            Columns = new ColumnSet("accountid", "name", "msiati_iatiorganizationidentifier")
                        },
                        // Recipient Country
                        new LinkEntity(
                            "msnfp_budget",
                            "msiati_nonembeddedcodelist",
                            "msiati_recipientcountryid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "RecipientCountry",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Recipient Region
                        new LinkEntity(
                            "msnfp_budget",
                            "msiati_nonembeddedcodelist",
                            "msiati_recipientregionid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "RecipientRegion",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Recipient Region Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "RecipientRegionVocabulary",
                                    Columns = new ColumnSet("msiati_code", "msiati_uri")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> budgets = _service.RetrieveMultiple(budgetQueryExpression).Entities;
                foreach (Entity budget in budgets)
                {
                    // Create budget element
                    anyChildElement = CreateBudgetIndividualElement(xmlDocument, iatiOrganisationElement, budget, defaultCurrencyCode, organizationBudgetType) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual budget element (total-budget, recipient-org-budget, recipient-region-budget, recipient-country-budget)
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiOrganisationElement"></param>
        /// <param name="budget"></param>
        /// <param name="defaultCurrencyCode"></param>
        /// <param name="organizationBudgetType"></param>
        private bool CreateBudgetIndividualElement(XmlDocument xmlDocument, XmlElement iatiOrganisationElement, Entity budget, string defaultCurrencyCode,
            OrganizationBudgetType organizationBudgetType)
        {
            try
            {
                string elementName;
                switch (organizationBudgetType)
                {
                    case OrganizationBudgetType.Total:
                        elementName = "total-budget";
                        break;

                    case OrganizationBudgetType.RecipientOrganizationBudget:
                        elementName = "recipient-org-budget";
                        break;

                    case OrganizationBudgetType.RecipientRegionBudget:
                        elementName = "recipient-region-budget";
                        break;

                    case OrganizationBudgetType.RecipientCountryBudget:
                        elementName = "recipient-country-budget";
                        break;

                    default:
                        throw new ArgumentOutOfRangeException(nameof(organizationBudgetType), "Invalid organization budget type parameter.");
                }

                // Create budget element
                XmlElement budgetElement = xmlDocument.CreateElement(elementName);

                bool anyChildElement = false;

                if (organizationBudgetType == OrganizationBudgetType.RecipientOrganizationBudget)
                {
                    // Create recipient-org element
                    anyChildElement = CreateRecipientOrgBudgetRecipientOrgElement(xmlDocument, budgetElement, budget);
                }
                else if (organizationBudgetType == OrganizationBudgetType.RecipientRegionBudget)
                {
                    // Create recipient-region element
                    anyChildElement = CreateRecipientRegionBudgetRecipientRegionElement(xmlDocument, budgetElement, budget);
                }
                else if (organizationBudgetType == OrganizationBudgetType.RecipientCountryBudget)
                {
                    // Create recipient-country element
                    anyChildElement = CreateRecipientCountryBudgetRecipientCountryElement(xmlDocument, budgetElement, budget);
                }

                // Create status attribute
                int? statusId = budget.GetOptionSetValue("msiati_budgetstatus");
                if (statusId != null)
                {
                    string statusCode = CommonUtilities.GetCodelistCodeByOptionSetId(Constants.BudgetStatusIdCodeMapping, (BudgetStatus)statusId.Value);
                    anyChildElement = !string.IsNullOrWhiteSpace(statusCode) || anyChildElement;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, budgetElement, "status", statusCode);
                }

                // Create period-start element
                anyChildElement = CreateBudgetPeriodStartElement(xmlDocument, budgetElement, budget) || anyChildElement;

                // Create period-end element
                anyChildElement = CreateBudgetPeriodEndElement(xmlDocument, budgetElement, budget) || anyChildElement;

                // Create value element
                anyChildElement = CreateBudgetValueElement(xmlDocument, budgetElement, budget, defaultCurrencyCode) || anyChildElement;

                // Create budget-line elements
                anyChildElement = CreateBudgetBudgetLineElements(xmlDocument, budgetElement, budget.Id, defaultCurrencyCode) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiOrganisationElement.AppendChild(budgetElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create budget/period-start element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetElement"></param>
        /// <param name="budget"></param>
        private bool CreateBudgetPeriodStartElement(XmlDocument xmlDocument, XmlElement budgetElement, Entity budget)
        {
            try
            {
                DateTime? periodStart = budget.GetAttributeValue<DateTime?>("msnfp_startdate");
                if (periodStart != null)
                {
                    // Create period-start element
                    XmlElement periodStartElement = XmlUtilities.CreateChildXmlElement(xmlDocument, budgetElement, "period-start");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, periodStartElement, "iso-date", periodStart, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create budget/period-end element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetElement"></param>
        /// <param name="budget"></param>
        private bool CreateBudgetPeriodEndElement(XmlDocument xmlDocument, XmlElement budgetElement, Entity budget)
        {
            try
            {
                DateTime? periodEnd = budget.GetAttributeValue<DateTime?>("msnfp_enddate");
                if (periodEnd != null)
                {
                    // Create period-end element
                    XmlElement periodStartElement = XmlUtilities.CreateChildXmlElement(xmlDocument, budgetElement, "period-end");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, periodStartElement, "iso-date", periodEnd, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create budget/value element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetElement"></param>
        /// <param name="budget"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateBudgetValueElement(XmlDocument xmlDocument, XmlElement budgetElement, Entity budget, string defaultCurrencyCode)
        {
            try
            {
                Money value = budget.GetAttributeValue<Money>("msnfp_totalbudget");
                if (value != null)
                {
                    // Create value element
                    XmlElement valueElement = XmlUtilities.CreateChildXmlElement(xmlDocument, budgetElement, "value");

                    // Create currency attribute (if different from default currency)
                    CommonUtilities.CreateCurrencyAttribute(xmlDocument, valueElement, budget, "Currency.isocurrencycode", true, defaultCurrencyCode);

                    // Create value-date attribute
                    DateTime? valueDate = budget.GetAttributeValue<DateTime?>("msiati_currencyvaluedate");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, valueElement, "value-date", valueDate, Constants.DateFormatDateOnly);

                    // Set value inner text
                    valueElement.InnerText = value.Value.ToString(Constants.DecimalFormatTwoDecimalDigits);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create budget/budget-line elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetElement"></param>
        /// <param name="parentBudgetId"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateBudgetBudgetLineElements(XmlDocument xmlDocument, XmlElement budgetElement, Guid parentBudgetId, string defaultCurrencyCode)
        {
            try
            {
                // Build query to fetch data
                var budgetQueryExpression = new QueryExpression("msnfp_budget")
                {
                    ColumnSet = new ColumnSet("msnfp_name", "msnfp_totalbudget", "msiati_currencyvaluedate", "msiati_reference"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_parentbudgetid", ConditionOperator.Equal, parentBudgetId)
                        }
                    },
                    LinkEntities =
                    {
                        // Currency
                        new LinkEntity(
                            "msnfp_budget",
                            "transactioncurrency",
                            "transactioncurrencyid",
                            "transactioncurrencyid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "Currency",
                            Columns = new ColumnSet("isocurrencycode")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> budgetLines = _service.RetrieveMultiple(budgetQueryExpression).Entities;
                foreach (Entity budgetLine in budgetLines)
                {
                    // Create budget element
                    anyChildElement = CreateBudgetBudgetLineIndividualElement(xmlDocument, budgetElement, budgetLine, defaultCurrencyCode) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual budget/budget-line element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetElement"></param>
        /// <param name="budgetLine"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateBudgetBudgetLineIndividualElement(XmlDocument xmlDocument, XmlElement budgetElement, Entity budgetLine, string defaultCurrencyCode)
        {
            try
            {
                // Create budget-line element
                XmlElement budgetLineElement = xmlDocument.CreateElement("budget-line");

                // Create ref attribute
                string @ref = budgetLine.GetAttributeValue<string>("msiati_reference");
                bool anyChildElement = !string.IsNullOrWhiteSpace(@ref);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, budgetLineElement, "ref", @ref);

                // Create value element
                anyChildElement = CreateBudgetBudgetLineValueElement(xmlDocument, budgetLineElement, budgetLine, defaultCurrencyCode) || anyChildElement;

                // Create narrative elements
                CommonUtilities.CreateNarrativeElements(_service, xmlDocument, budgetLineElement, budgetLine, "msnfp_name", false, budgetLine.Id, NarrativeTranslationEntity.Budget,
                    NarrativeTranslationAttribute.Name, false);

                // If any child element, add parent
                if (anyChildElement)
                {
                    budgetElement.AppendChild(budgetLineElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual budget/budget-line/value element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetLineElement"></param>
        /// <param name="budgetLine"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateBudgetBudgetLineValueElement(XmlDocument xmlDocument, XmlElement budgetLineElement, Entity budgetLine, string defaultCurrencyCode)
        {
            try
            {
                Money value = budgetLine.GetAttributeValue<Money>("msnfp_totalbudget");
                if (value != null)
                {
                    // Create value element
                    XmlElement valueElement = XmlUtilities.CreateChildXmlElement(xmlDocument, budgetLineElement, "value");

                    // Create currency attribute (if different from default currency)
                    CommonUtilities.CreateCurrencyAttribute(xmlDocument, valueElement, budgetLine, "Currency.isocurrencycode", true, defaultCurrencyCode);

                    // Create value-date attribute
                    DateTime? valueDate = budgetLine.GetAttributeValue<DateTime?>("msiati_currencyvaluedate");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, valueElement, "value-date", valueDate, Constants.DateFormatDateOnly);

                    // Set value inner text
                    valueElement.InnerText = value.Value.ToString(Constants.DecimalFormatTwoDecimalDigits);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-organisations/iati-organisation/recipient-org-budget/recipient-org element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="recipientOrgBudgetElement"></param>
        /// <param name="recipientOrgBudget"></param>
        private bool CreateRecipientOrgBudgetRecipientOrgElement(XmlDocument xmlDocument, XmlElement recipientOrgBudgetElement, Entity recipientOrgBudget)
        {
            try
            {
                Guid? recipientOrgAccountId = recipientOrgBudget.GetAliasedValue<Guid?>("RecipientOrganization.accountid");
                if (recipientOrgAccountId != null)
                {
                    // Create recipient-org element
                    XmlElement recipientOrgElement = xmlDocument.CreateElement("recipient-org");

                    // Create ref attribute
                    string @ref = recipientOrgBudget.GetAliasedValue<string>("RecipientOrganization.msiati_iatiorganizationidentifier");
                    bool anyChildElement = !string.IsNullOrWhiteSpace(@ref);
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientOrgElement, "ref", @ref);

                    // Create narrative elements
                    anyChildElement =
                        CommonUtilities.CreateNarrativeElements(_service, xmlDocument, recipientOrgElement, recipientOrgBudget, "RecipientOrganization.name", true,
                            recipientOrgAccountId.Value, NarrativeTranslationEntity.Account, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                    // If any child element, add parent
                    if (anyChildElement)
                    {
                        recipientOrgBudgetElement.AppendChild(recipientOrgElement);
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-organisations/iati-organisation/recipient-region-budget/recipient-region element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="recipientRegionBudgetElement"></param>
        /// <param name="recipientRegionBudget"></param>
        private bool CreateRecipientRegionBudgetRecipientRegionElement(XmlDocument xmlDocument, XmlElement recipientRegionBudgetElement, Entity recipientRegionBudget)
        {
            try
            {
                // Create recipient-region element
                XmlElement recipientRegionElement = xmlDocument.CreateElement("recipient-region");

                // Create vocabulary attribute
                string vocabularyCode = recipientRegionBudget.GetAliasedValue<string>("RecipientRegionVocabulary.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(vocabularyCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientRegionElement, "vocabulary", vocabularyCode);

                // If reporting organization vocabulary, include vocabulary-uri
                if (vocabularyCode == "99")
                {
                    // Create vocabulary-uri attribute
                    string vocabularyUri = recipientRegionBudget.GetAliasedValue<string>("RecipientRegionVocabulary.msiati_uri");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientRegionElement, "vocabulary-uri", vocabularyUri);
                }

                // Create code attribute
                string code = recipientRegionBudget.GetAliasedValue<string>("RecipientRegion.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(code) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientRegionElement, "code", code);

                // Create narrative elements
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, recipientRegionElement, recipientRegionBudget, "msiati_recipientregiondescription", false,
                        recipientRegionBudget.Id, NarrativeTranslationEntity.Budget, NarrativeTranslationAttribute.RecipientRegionDescription, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    recipientRegionBudgetElement.AppendChild(recipientRegionElement);
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-organisations/iati-organisation/recipient-country-budget/recipient-country element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="recipientCountryBudgetElement"></param>
        /// <param name="recipientCountryBudget"></param>
        private bool CreateRecipientCountryBudgetRecipientCountryElement(XmlDocument xmlDocument, XmlElement recipientCountryBudgetElement, Entity recipientCountryBudget)
        {
            try
            {
                // Create recipient-country element
                XmlElement recipientCountryElement = xmlDocument.CreateElement("recipient-country");

                // Create code attribute
                string code = recipientCountryBudget.GetAliasedValue<string>("RecipientCountry.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(code);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientCountryElement, "code", code);

                // Create narrative elements
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, recipientCountryElement, recipientCountryBudget, "msiati_recipientcountrydescription", false,
                        recipientCountryBudget.Id, NarrativeTranslationEntity.Budget, NarrativeTranslationAttribute.RecipientCountryDescription, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    recipientCountryBudgetElement.AppendChild(recipientCountryElement);
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region total-expenditure

        /// <summary>
        /// Create iati-organisations/iati-organisation/total-expenditure elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiOrganisationElement"></param>
        /// <param name="accountId"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateTotalExpenditureElements(XmlDocument xmlDocument, XmlElement iatiOrganisationElement, Guid accountId, string defaultCurrencyCode)
        {
            try
            {
                // Build query to fetch data
                var expenditureQueryExpression = new QueryExpression("msiati_expenditure")
                {
                    ColumnSet =
                        new ColumnSet("msiati_startdate", "msiati_enddate", "msiati_totalexpenditure", "msiati_currencyvaluedate"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_organizationid", ConditionOperator.Equal, accountId),
                            new ConditionExpression("msiati_parentexpenditureid", ConditionOperator.Null)
                        }
                    },
                    LinkEntities =
                    {
                        // Currency
                        new LinkEntity(
                            "msiati_expenditure",
                            "transactioncurrency",
                            "transactioncurrencyid",
                            "transactioncurrencyid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "Currency",
                            Columns = new ColumnSet("isocurrencycode")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> budgets = _service.RetrieveMultiple(expenditureQueryExpression).Entities;
                foreach (Entity budget in budgets)
                {
                    // Create budget element
                    anyChildElement = CreateTotalExpenditureIndividualElement(xmlDocument, iatiOrganisationElement, budget, defaultCurrencyCode) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-organisations/iati-organisation/total-expenditure element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiOrganisationElement"></param>
        /// <param name="budget"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateTotalExpenditureIndividualElement(XmlDocument xmlDocument, XmlElement iatiOrganisationElement, Entity budget, string defaultCurrencyCode)
        {
            try
            {
                // Create total-expenditure element
                XmlElement budgetElement = xmlDocument.CreateElement("total-expenditure");

                // Create period-start element
                var anyChildElement = CreateTotalExpenditurePeriodStartElement(xmlDocument, budgetElement, budget);

                // Create period-end element
                anyChildElement = CreateTotalExpenditurePeriodEndElement(xmlDocument, budgetElement, budget) || anyChildElement;

                // Create value element
                anyChildElement = CreateTotalExpenditureValueElement(xmlDocument, budgetElement, budget, defaultCurrencyCode) || anyChildElement;

                // Create budget-line elements
                anyChildElement = CreateTotalExpenditureExpenseLineElements(xmlDocument, budgetElement, budget.Id, defaultCurrencyCode) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiOrganisationElement.AppendChild(budgetElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-organisations/iati-organisation/total-expenditure/period-start element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetElement"></param>
        /// <param name="budget"></param>
        private bool CreateTotalExpenditurePeriodStartElement(XmlDocument xmlDocument, XmlElement budgetElement, Entity budget)
        {
            try
            {
                DateTime? periodStart = budget.GetAttributeValue<DateTime?>("msiati_startdate");
                if (periodStart != null)
                {
                    // Create period-start element
                    XmlElement periodStartElement = XmlUtilities.CreateChildXmlElement(xmlDocument, budgetElement, "period-start");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, periodStartElement, "iso-date", periodStart, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-organisations/iati-organisation/total-expenditure/period-end element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetElement"></param>
        /// <param name="budget"></param>
        private bool CreateTotalExpenditurePeriodEndElement(XmlDocument xmlDocument, XmlElement budgetElement, Entity budget)
        {
            try
            {
                DateTime? periodEnd = budget.GetAttributeValue<DateTime?>("msiati_enddate");
                if (periodEnd != null)
                {
                    // Create period-end element
                    XmlElement periodStartElement = XmlUtilities.CreateChildXmlElement(xmlDocument, budgetElement, "period-end");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, periodStartElement, "iso-date", periodEnd, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-organisations/iati-organisation/total-expenditure/value element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetElement"></param>
        /// <param name="budget"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateTotalExpenditureValueElement(XmlDocument xmlDocument, XmlElement budgetElement, Entity budget, string defaultCurrencyCode)
        {
            try
            {
                Money value = budget.GetAttributeValue<Money>("msiati_totalexpenditure");
                if (value != null)
                {
                    // Create value element
                    XmlElement valueElement = XmlUtilities.CreateChildXmlElement(xmlDocument, budgetElement, "value");

                    // Create currency attribute (if different from default currency)
                    CommonUtilities.CreateCurrencyAttribute(xmlDocument, valueElement, budget, "Currency.isocurrencycode", true, defaultCurrencyCode);

                    // Create value-date attribute
                    DateTime? valueDate = budget.GetAttributeValue<DateTime?>("msiati_currencyvaluedate");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, valueElement, "value-date", valueDate, Constants.DateFormatDateOnly);

                    // Set value inner text
                    valueElement.InnerText = value.Value.ToString(Constants.DecimalFormatTwoDecimalDigits);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-organisations/iati-organisation/total-expenditure/expense-line elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="totalExpenditureElement"></param>
        /// <param name="parentExpenditureId"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateTotalExpenditureExpenseLineElements(XmlDocument xmlDocument, XmlElement totalExpenditureElement, Guid parentExpenditureId, string defaultCurrencyCode)
        {
            try
            {
                // Build query to fetch data
                var expenditureQueryExpression = new QueryExpression("msiati_expenditure")
                {
                    ColumnSet = new ColumnSet("msiati_name", "msiati_totalexpenditure", "msiati_currencyvaluedate", "msiati_reference"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_parentexpenditureid", ConditionOperator.Equal, parentExpenditureId)
                        }
                    },
                    LinkEntities =
                    {
                        // Currency
                        new LinkEntity(
                            "msiati_expenditure",
                            "transactioncurrency",
                            "transactioncurrencyid",
                            "transactioncurrencyid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "Currency",
                            Columns = new ColumnSet("isocurrencycode")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> expenseLines = _service.RetrieveMultiple(expenditureQueryExpression).Entities;
                foreach (Entity expenseLine in expenseLines)
                {
                    // Create budget element
                    anyChildElement = CreateTotalExpenditureExpenseLineIndividualElement(xmlDocument, totalExpenditureElement, expenseLine, defaultCurrencyCode) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-organisations/iati-organisation/total-expenditure/expense-line element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetElement"></param>
        /// <param name="expenseLine"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateTotalExpenditureExpenseLineIndividualElement(XmlDocument xmlDocument, XmlElement budgetElement, Entity expenseLine, string defaultCurrencyCode)
        {
            try
            {
                // Create budget-line element
                XmlElement budgetLineElement = xmlDocument.CreateElement("expense-line");

                // Create ref attribute
                string @ref = expenseLine.GetAttributeValue<string>("msiati_reference");
                bool anyChildElement = !string.IsNullOrWhiteSpace(@ref);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, budgetLineElement, "ref", @ref);

                // Create value element
                anyChildElement = CreateTotalExpenditureExpenseLineValueElement(xmlDocument, budgetLineElement, expenseLine, defaultCurrencyCode) || anyChildElement;

                // Create narrative elements
                CommonUtilities.CreateNarrativeElements(_service, xmlDocument, budgetLineElement, expenseLine, "msiati_name", false, expenseLine.Id,
                    NarrativeTranslationEntity.Expenditure, NarrativeTranslationAttribute.Name, false);

                // If any child element, add parent
                if (anyChildElement)
                {
                    budgetElement.AppendChild(budgetLineElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-organisations/iati-organisation/total-expenditure/expense-line/value element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetLineElement"></param>
        /// <param name="budgetLine"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateTotalExpenditureExpenseLineValueElement(XmlDocument xmlDocument, XmlElement budgetLineElement, Entity budgetLine, string defaultCurrencyCode)
        {
            try
            {
                Money value = budgetLine.GetAttributeValue<Money>("msiati_totalexpenditure");
                if (value != null)
                {
                    // Create value element
                    XmlElement valueElement = XmlUtilities.CreateChildXmlElement(xmlDocument, budgetLineElement, "value");

                    // Create currency attribute (if different from default currency)
                    CommonUtilities.CreateCurrencyAttribute(xmlDocument, valueElement, budgetLine, "Currency.isocurrencycode", true, defaultCurrencyCode);

                    // Create value-date attribute
                    DateTime? valueDate = budgetLine.GetAttributeValue<DateTime?>("msiati_currencyvaluedate");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, valueElement, "value-date", valueDate, Constants.DateFormatDateOnly);

                    // Set value inner text
                    valueElement.InnerText = value.Value.ToString(Constants.DecimalFormatTwoDecimalDigits);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #endregion
    }
}