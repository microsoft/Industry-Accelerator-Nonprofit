﻿using System;
using System.IO;
using System.Xml;

namespace IATIXmlGeneration.Utilities
{
    public static class XmlUtilities
    {
        /// <summary>
        /// Create a blank <see cref="XmlDocument"/> with its declaration (v1.0, UTF-8)
        /// </summary>
        /// <returns></returns>
        public static XmlDocument CreateBaseXmlDocument()
        {
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.AppendChild(xmlDocument.CreateXmlDeclaration("1.0", "UTF-8", null));
            return xmlDocument;
        }

        /// <summary>
        /// Convert an <see cref="XmlDocument"/> to a Base64 string
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <returns></returns>
        public static string XmlDocumentToBase64(XmlDocument xmlDocument)
        {
            using (var memoryStream = new MemoryStream())
            {
                xmlDocument.Save(memoryStream);
                return Convert.ToBase64String(memoryStream.ToArray());
            }
        }

        /// <summary>
        /// Create a child <see cref="XmlElement"/>
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="elementName"></param>
        /// <returns></returns>
        public static XmlElement CreateChildXmlElement(XmlDocument xmlDocument, XmlNode parentElement, string elementName)
        {
            XmlElement element = xmlDocument.CreateElement(elementName);
            parentElement.AppendChild(element);
            return element;
        }

        /// <summary>
        /// Create an <see cref="XmlElement"/> with text
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="elementName"></param>
        /// <param name="innerTextValue"></param>
        public static XmlElement CreateChildXmlElementWithInnerTextIfValueNotNull(XmlDocument xmlDocument, XmlElement parentElement, string elementName, string innerTextValue)
        {
            if (!string.IsNullOrWhiteSpace(innerTextValue))
            {
                XmlElement element = CreateChildXmlElement(xmlDocument, parentElement, elementName);
                element.InnerText = innerTextValue;
                return element;
            }

            return null;
        }

        /// <summary>
        /// Create an <see cref="XmlElement"/> with text
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="elementName"></param>
        /// <param name="innerTextValue"></param>
        /// <param name="format"></param>
        public static XmlElement CreateChildXmlElementWithInnerTextIfValueNotNull(XmlDocument xmlDocument, XmlElement parentElement, string elementName, decimal? innerTextValue, string format)
        {
            if (innerTextValue != null)
            {
                XmlElement element = CreateChildXmlElement(xmlDocument, parentElement, elementName);
                element.InnerText = innerTextValue.Value.ToString(format);
                return element;
            }

            return null;
        }

        /// <summary>
        /// Create an <see cref="XmlAttribute"/> with a value. Only creates the attribute if the value is not empty
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="attributeName"></param>
        /// <param name="attributeValue"></param>
        /// <returns></returns>
        public static XmlAttribute CreateXmlAttributeWithValue(XmlDocument xmlDocument, XmlElement parentElement, string attributeName, string attributeValue)
        {
            XmlAttribute attribute = xmlDocument.CreateAttribute(attributeName);
            parentElement.Attributes.Append(attribute);
            attribute.Value = attributeValue;
            return attribute;
        }

        /// <summary>
        /// Create an <see cref="XmlAttribute"/> with a value. Only creates the attribute if the value is not empty
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="attributeName"></param>
        /// <param name="attributeValue"></param>
        /// <returns></returns>
        public static XmlAttribute CreateXmlAttributeWithValueIfNotNull(XmlDocument xmlDocument, XmlElement parentElement, string attributeName, string attributeValue)
        {
            if (!string.IsNullOrWhiteSpace(attributeValue))
            {
                return CreateXmlAttributeWithValue(xmlDocument, parentElement, attributeName, attributeValue);
            }

            return null;
        }

        /// <summary>
        /// Create an <see cref="XmlAttribute"/> with a value. Only creates the attribute if the value is not empty
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="attributeName"></param>
        /// <param name="attributeValue"></param>
        /// <param name="format"></param>
        /// <returns></returns>
        public static XmlAttribute CreateXmlAttributeWithValueIfNotNull(XmlDocument xmlDocument, XmlElement parentElement, string attributeName, decimal? attributeValue, string format)
        {
            if (attributeValue != null)
            {
                return CreateXmlAttributeWithValue(xmlDocument, parentElement, attributeName, attributeValue.Value.ToString(format));
            }

            return null;
        }

        /// <summary>
        /// Create an <see cref="XmlAttribute"/> with a value. Only creates the attribute if the value is not empty
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="attributeName"></param>
        /// <param name="attributeValue"></param>
        /// <param name="format"></param>
        /// <returns></returns>
        public static XmlAttribute CreateXmlAttributeWithValueIfNotNull(XmlDocument xmlDocument, XmlElement parentElement, string attributeName, DateTime? attributeValue, string format)
        {
            if (attributeValue != null)
            {
                return CreateXmlAttributeWithValue(xmlDocument, parentElement, attributeName, attributeValue.Value.ToString(format));
            }

            return null;
        }

        /// <summary>
        /// Create an <see cref="XmlAttribute"/> with a value. Only creates the attribute if the value is not empty
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="attributeName"></param>
        /// <param name="attributeValue"></param>
        /// <param name="format"></param>
        /// <returns></returns>
        public static XmlAttribute CreateXmlAttributeWithValueIfNotNull(XmlDocument xmlDocument, XmlElement parentElement, string attributeName, int? attributeValue, string format = null)
        {
            if (attributeValue != null)
            {
                string stringValue = string.IsNullOrWhiteSpace(format)
                    ? attributeValue.Value.ToString()
                    : attributeValue.Value.ToString(format);

                return CreateXmlAttributeWithValue(xmlDocument, parentElement, attributeName, stringValue);
            }

            return null;
        }

        /// <summary>
        /// Create an <see cref="XmlAttribute"/> with a value. Only creates the attribute if the value is not empty
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="attributeName"></param>
        /// <param name="attributeValue"></param>
        /// <param name="format"></param>
        /// <returns></returns>
        public static XmlAttribute CreateXmlAttributeWithValueIfNotNull(XmlDocument xmlDocument, XmlElement parentElement, string attributeName, Guid? attributeValue, string format = null)
        {
            if (attributeValue != null)
            {
                string stringValue = string.IsNullOrWhiteSpace(format)
                    ? attributeValue.Value.ToString()
                    : attributeValue.Value.ToString(format);

                return CreateXmlAttributeWithValue(xmlDocument, parentElement, attributeName, stringValue);
            }

            return null;
        }
    }

}
