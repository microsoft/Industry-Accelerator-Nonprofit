﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Xml;
using IATIXmlGeneration.Containers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace IATIXmlGeneration.Utilities
{
    public class ActivityStandard
    {
        #region Member Variables

        private readonly ITracingService _tracingService;
        private readonly IOrganizationService _service;
        private readonly List<ExceptionLogEntry> _exceptionLog;
        private readonly Guid _iatiFileGenerationId;

        #endregion

        #region Constructor

        public ActivityStandard(ITracingService tracingService, IOrganizationService service, Guid iatiFileGenerationId)
        {
            _tracingService = tracingService;
            _service = service;
            _iatiFileGenerationId = iatiFileGenerationId;
            _exceptionLog = new List<ExceptionLogEntry>();
        }

        #endregion

        #region File Generation

        /// <summary>
        /// Generate the Activity Standard XmlDocument
        /// </summary>
        /// <returns></returns>
        public XmlDocument GenerateXmlFile()
        {
            XmlDocument xmlDocument = XmlUtilities.CreateBaseXmlDocument();
            if (CreateIatiActivitiesElement(xmlDocument))
            {
                return xmlDocument;
            }

            return null;
        }

        /// <summary>
        /// Generate the Activity Standard XML and attach it as a Note
        /// </summary>
        public void GenerateAndAttachXmlFile()
        {
            string relatedEntityLogicalName = "msiati_iatifilegeneration";

            try
            {
                _tracingService.Trace("Starting Activity file generation.");

                // Generate XmlDocument
                XmlDocument xmlDocument = GenerateXmlFile();

                if (xmlDocument != null)
                {
                    // Convert XmlDocument to Base64 string
                    string xmlDocumentContent = XmlUtilities.XmlDocumentToBase64(xmlDocument);

                    _tracingService.Trace("Activity file generated. Creating Note with file.");

                    // Create note with XML file
                    CommonUtilities.CreateNoteWithAttachment(_service, relatedEntityLogicalName, _iatiFileGenerationId, "IATI Activity file", Constants.MimeTypeXml,
                        "IATI Activity XML file", "IATI Activity.xml", xmlDocumentContent);

                    _tracingService.Trace("Activity Note created.");
                }
                else
                {
                    _tracingService.Trace("Activity file not generated. No activities found or selected activities have no IATI information.");
                }
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
            }
            finally
            {
                // Create note with Exception log
                CommonUtilities.CreateExceptionLogNote(_exceptionLog, _service, _tracingService, relatedEntityLogicalName, _iatiFileGenerationId,
                    "Activity Standard Exception Log", "Log of exceptions during Activity Standard file generation");
            }
        }

        #endregion

        #region XML Elements

        #region iati-activities

        /// <summary>
        /// Create iati-activities element
        /// </summary>
        /// <param name="xmlDocument"></param>
        private bool CreateIatiActivitiesElement(XmlDocument xmlDocument)
        {
            try
            {
                // Create iati-activities element
                XmlElement iatiActivitiesElement = xmlDocument.CreateElement("iati-activities");

                // Create generated-datetime attribute
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, iatiActivitiesElement, "generated-datetime", DateTime.Now, "o");

                // Create version attribute
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, iatiActivitiesElement, "version", Constants.IatiVersion);

                // Create iati-activity elements
                bool anyChildElement = CreateIatiActivityElements(xmlDocument, iatiActivitiesElement);

                // If any child element, add parent
                if (anyChildElement)
                {
                    xmlDocument.AppendChild(iatiActivitiesElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region iati-activity

        /// <summary>
        /// Create iati-activities/iati-activity element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivitiesElement"></param>
        private bool CreateIatiActivityElements(XmlDocument xmlDocument, XmlElement iatiActivitiesElement)
        {
            try
            {
                var deliveryFrameworkIdsQueryExpression = new QueryExpression("msiati_iatifilegeneration_deliveryframework")
                {
                    ColumnSet = new ColumnSet("msnfp_deliveryframeworkid"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_iatifilegenerationid", ConditionOperator.Equal, _iatiFileGenerationId)
                        }
                    }
                };

                List<Guid> deliveryFrameworkIdList = _service.RetrieveMultiple(deliveryFrameworkIdsQueryExpression).Entities
                    .Select(t => t.GetAttributeValue<Guid>("msnfp_deliveryframeworkid"))
                    .ToList();

                if (!deliveryFrameworkIdList.Any())
                {
                    return false;
                }

                // Build query to fetch data
                // Some link entities were separated (additional queries) due to CRM limit on the amount of link entities per query
                var deliveryFrameworkQueryExpression = new QueryExpression("msnfp_deliveryframework")
                {
                    ColumnSet =
                        new ColumnSet("msnfp_name", "msnfp_description", "modifiedon", "msiati_humanitarianscope", "msiati_herarchylevel", "msiati_iatiactivityid",
                            "msiati_secondaryreporter", "msnfp_status", "msnfp_startdate", "msnfp_enddate", "msnfp_plannedstartdate", "msnfp_plannedenddate", "msiati_capitalspend",
                            "msiati_crsloanrate1", "msiati_crsloanrate2", "msiati_crscommitmentdate", "msiati_crsrepaymentfirstdate", "msiati_crsrepaymentfinaldate",
                            "msiati_crsreportingyear", "msiati_currencyvaluedate", "msiati_crsinterestreceived", "msiati_crsprincipaloutstanding", "msiati_crsprincipalarrears",
                            "msiati_crsinterestarrears", "msiati_fssextractiondate", "msiati_fsspriority", "msiati_fssphaseoutyear"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msnfp_deliveryframeworkid", ConditionOperator.In, deliveryFrameworkIdList)
                        }
                    },
                    LinkEntities =
                    {
                        // Default Language
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "msiati_nonembeddedcodelist",
                            "msiati_defaultlanguageid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("msiati_code"),
                            EntityAlias = "DefaultLanguage"
                        },
                        // Default Currency
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "transactioncurrency",
                            "msiati_defaultcurrencyid",
                            "transactioncurrencyid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("isocurrencycode"),
                            EntityAlias = "DefaultCurrency"
                        },
                        // Budget Not Provided
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "msiati_nonembeddedcodelist",
                            "msiati_budgetnotprovidedid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("msiati_code"),
                            EntityAlias = "BudgetNotProvided"
                        },
                        // Reporting Organization
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "account",
                            "msnfp_account",
                            "accountid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("accountid", "msiati_iatiorganizationidentifier", "name"),
                            EntityAlias = "ReportingOrg",
                            LinkEntities =
                            {
                                // Reporting Organization Type
                                new LinkEntity(
                                    "account",
                                    "msiati_nonembeddedcodelist",
                                    "msiati_organizationtypeid",
                                    "msiati_nonembeddedcodelistid",
                                    JoinOperator.LeftOuter)
                                {
                                    Columns = new ColumnSet("msiati_code"),
                                    EntityAlias = "ReportingOrgType"
                                }
                            }
                        },
                        // Activity Scope
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "msiati_nonembeddedcodelist",
                            "msiati_scopeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("msiati_code"),
                            EntityAlias = "ActivityScope"
                        },
                        // Budget Identifier Vocabulary
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "msiati_nonembeddedcodelistvocabulary",
                            "msiati_budgetidentifiervocabularyid",
                            "msiati_nonembeddedcodelistvocabularyid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("msiati_code"),
                            EntityAlias = "BudgetIdentifierVocabulary"
                        },
                        // Default Flow Type
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "msiati_nonembeddedcodelist",
                            "msiati_defaultflowtypeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("msiati_code"),
                            EntityAlias = "DefaultFlowType"
                        },
                        // Default Finance Type
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "msiati_nonembeddedcodelist",
                            "msiati_defaultfinancetypeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("msiati_code"),
                            EntityAlias = "DefaultFinanceType"
                        },
                        // Default Tied Status
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "msiati_nonembeddedcodelist",
                            "msiati_defaulttiedstatusid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("msiati_code"),
                            EntityAlias = "DefaultTiedStatus"
                        }
                    }
                };

                // Build query to fetch additional data
                // Some link entities were separated (additional queries) due to CRM limit on the amount of link entities per query
                var deliveryFrameworkAdditionalDetailQueryExpression = new QueryExpression("msnfp_deliveryframework")
                {
                    ColumnSet = new ColumnSet(),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msnfp_deliveryframeworkid", ConditionOperator.In, deliveryFrameworkIdList)
                        }
                    },
                    LinkEntities =
                    {
                        // Currency
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "transactioncurrency",
                            "transactioncurrencyid",
                            "transactioncurrencyid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("isocurrencycode"),
                            EntityAlias = "Currency"
                        },
                        // Collaboration Type
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "msiati_nonembeddedcodelist",
                            "msiati_collaborationtypeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("msiati_code"),
                            EntityAlias = "CollaborationType"
                        },
                        // Loan Repayment Type
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "msiati_nonembeddedcodelist",
                            "msiati_crsloanrepaymenttypeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("msiati_code"),
                            EntityAlias = "LoanRepaymentType"
                        },
                        // Loan Repayment Period
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "msiati_nonembeddedcodelist",
                            "msiati_crsloanrepaymentperiodid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("msiati_code"),
                            EntityAlias = "LoanRepaymentPeriod"
                        },
                        // CRS Channel
                        new LinkEntity(
                            "msnfp_deliveryframework",
                            "msiati_nonembeddedcodelist",
                            "msiati_crschannelid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("msiati_code"),
                            EntityAlias = "CRSChannel"
                        }
                    }
                };

                DataCollection<Entity> deliveryFrameworkList = _service.RetrieveMultiple(deliveryFrameworkQueryExpression).Entities;
                DataCollection<Entity> deliveryFrameworkAdditionalDetailList = _service.RetrieveMultiple(deliveryFrameworkAdditionalDetailQueryExpression).Entities;

                bool anyChildElement = false;
                foreach (Entity deliveryFramework in deliveryFrameworkList)
                {
                    // Create iati-activity element
                    anyChildElement =
                        CreateIatiActivityIndividualElement(xmlDocument, iatiActivitiesElement, deliveryFramework, deliveryFrameworkAdditionalDetailList) ||
                        anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivitiesElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <param name="deliveryFrameworkAdditionalDetailList"></param>
        private bool CreateIatiActivityIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivitiesElement, Entity deliveryFramework,
            DataCollection<Entity> deliveryFrameworkAdditionalDetailList)
        {
            try
            {
                Entity deliveryFrameworkAdditionalDetail = deliveryFrameworkAdditionalDetailList.FirstOrDefault(t => t.Id == deliveryFramework.Id);

                // Create iati-activity element
                XmlElement iatiActivityElement = xmlDocument.CreateElement("iati-activity");

                // Create xml:lang attribute
                string defaultLanguage = deliveryFramework.GetAliasedValue<string>("DefaultLanguage.msiati_code");
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, iatiActivityElement, "xml:lang", defaultLanguage);

                // Create default-currency attribute
                string defaultCurrencyCode = deliveryFramework.GetAliasedValue<string>("DefaultCurrency.isocurrencycode");
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, iatiActivityElement, "default-currency", defaultCurrencyCode);

                // Create last-updated-datetime attribute
                DateTime? modifiedOn = deliveryFramework.GetAttributeValue<DateTime?>("modifiedon");
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, iatiActivityElement, "last-updated-datetime", modifiedOn, "o");

                // Create humanitarian attribute
                string humanitarian = deliveryFramework.GetAttributeValue<bool?>("msiati_humanitarianscope") == true ? "1" : "0";
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, iatiActivityElement, "humanitarian", humanitarian);

                // Create hierarchy attribute
                int? hierarchyLevel = deliveryFramework.GetAttributeValue<int?>("msiati_hierarchylevel");
                bool anyChildElement = hierarchyLevel != null;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, iatiActivityElement, "hierarchy", hierarchyLevel);

                // Create budget-not-provided attribute
                string budgetNotProvidedCode = deliveryFramework.GetAliasedValue<string>("BudgetNotProvided.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(budgetNotProvidedCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, iatiActivityElement, "budget-not-provided", budgetNotProvidedCode);

                Guid deliveryFrameworkId = deliveryFramework.Id;

                // Create iati-identifier element
                anyChildElement = CreateIatiIdentifierElement(xmlDocument, iatiActivityElement, deliveryFramework) || anyChildElement;

                // Create reporting-org element
                anyChildElement = CreateReportingOrgElement(xmlDocument, iatiActivityElement, deliveryFramework) || anyChildElement;

                // Create title element
                anyChildElement = CreateTitleElement(xmlDocument, iatiActivityElement, deliveryFramework, deliveryFrameworkId) || anyChildElement;

                // Create description elements
                anyChildElement = CreateDescriptionElements(xmlDocument, iatiActivityElement, deliveryFramework, deliveryFrameworkId) || anyChildElement;

                // Create participating-org elements
                anyChildElement = CreateParticipatingOrgElements(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create other-identifier elements
                anyChildElement = CreateOtherIdentifierElements(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create activity-status element
                anyChildElement = CreateActivityStatusElement(xmlDocument, iatiActivityElement, deliveryFramework) || anyChildElement;

                // Create activity-date elements
                anyChildElement = CreateActivityDateElements(xmlDocument, iatiActivityElement, deliveryFramework) || anyChildElement;

                // Create contact-info elements
                anyChildElement = CreateActivityContactInfoElements(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create activity-scope element
                anyChildElement = CreateActivityScopeElement(xmlDocument, iatiActivityElement, deliveryFramework) || anyChildElement;

                // Create recipient-country elements
                anyChildElement = CreateRecipientCountryElements(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create recipient-region elements
                anyChildElement = CreateRecipientRegionElements(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create location elements
                anyChildElement = CreateLocationElements(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create sector elements
                anyChildElement = CreateSectorElements(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create tag elements
                anyChildElement = CreateTagElements(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create country-budget-items element
                anyChildElement = CreateCountryBudgetItemsElement(xmlDocument, iatiActivityElement, deliveryFramework, deliveryFrameworkId) || anyChildElement;

                // Create humanitarian-scope elements
                anyChildElement = CreateHumanitarianScopeElements(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create policy-marker elements
                anyChildElement = CreatePolicyMarkerElements(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create collaboration-type element
                anyChildElement = CreateCollaborationTypeElement(xmlDocument, iatiActivityElement, deliveryFrameworkAdditionalDetail) || anyChildElement;

                // Create default-flow-type element
                anyChildElement = CreateDefaultFlowTypeElement(xmlDocument, iatiActivityElement, deliveryFramework) || anyChildElement;

                // Create default-finance-type element
                anyChildElement = CreateDefaultFinanceTypeElement(xmlDocument, iatiActivityElement, deliveryFramework) || anyChildElement;

                // Create default-aid-type element
                anyChildElement = CreateDefaultAidTypeElements(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create default-tied-status element
                anyChildElement = CreateDefaultTiedStatusElement(xmlDocument, iatiActivityElement, deliveryFramework) || anyChildElement;

                // Create budget elements
                anyChildElement = CreateBudgetElements(xmlDocument, iatiActivityElement, deliveryFrameworkId, defaultCurrencyCode) || anyChildElement;

                // Create planned-disbursement elements
                anyChildElement = CreatePlannedDisbursementElements(xmlDocument, iatiActivityElement, deliveryFrameworkId, defaultCurrencyCode) || anyChildElement;

                // Create capital-spend element
                anyChildElement = CreateCapitalSpendElement(xmlDocument, iatiActivityElement, deliveryFramework) || anyChildElement;

                // Create transaction elements
                anyChildElement = CreateTransactionElements(xmlDocument, iatiActivityElement, deliveryFrameworkId, defaultCurrencyCode) || anyChildElement;

                // Create document-link elements
                anyChildElement =
                    CommonUtilities.CreateDocumentLinkElements(_service, _tracingService, _exceptionLog, xmlDocument, iatiActivityElement, deliveryFrameworkId,
                        Constants.ConnectionRoleDocumentLinkToDeliveryFramework, false) || anyChildElement;

                // Create related-activity elements
                anyChildElement = CreateRelatedActivityElements(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create conditions element
                anyChildElement = CreateConditionsElement(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create result element
                anyChildElement = CreateResultElements(xmlDocument, iatiActivityElement, deliveryFrameworkId) || anyChildElement;

                // Create crs-add element
                anyChildElement =
                    CreateCrsAddElement(xmlDocument, iatiActivityElement, deliveryFramework, deliveryFrameworkAdditionalDetail, deliveryFrameworkId, defaultCurrencyCode) ||
                    anyChildElement;

                // Create fss element
                anyChildElement = CreateFssElement(xmlDocument, iatiActivityElement, deliveryFramework, deliveryFrameworkId, defaultCurrencyCode) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivitiesElement.AppendChild(iatiActivityElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region iati-identifier

        /// <summary>
        /// Create iati-activities/iati-activity/iati-identifier element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        private bool CreateIatiIdentifierElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework)
        {
            try
            {
                string iatiIdentifier = deliveryFramework.GetAttributeValue<string>("msiati_iatiactivityid");
                if (!string.IsNullOrWhiteSpace(iatiIdentifier))
                {
                    // Create iati-identifier element
                    XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, iatiActivityElement, "iati-identifier", iatiIdentifier);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region reporting-org

        /// <summary>
        /// Create iati-activities/iati-activity/reporting-org element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        private bool CreateReportingOrgElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework)
        {
            try
            {
                if (deliveryFramework.Contains("ReportingOrg.accountid"))
                {
                    // Create reporting-org element
                    XmlElement reportingOrgElement = xmlDocument.CreateElement("reporting-org");

                    // Create ref attribute
                    string @ref = deliveryFramework.GetAliasedValue<string>("ReportingOrg.msiati_iatiorganizationidentifier");
                    bool anyChildElement = !string.IsNullOrWhiteSpace(@ref);
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, reportingOrgElement, "ref", @ref);

                    // Create type attribute
                    string typeCode = deliveryFramework.GetAliasedValue<string>("ReportingOrgType.msiati_code");
                    anyChildElement = !string.IsNullOrWhiteSpace(typeCode) || anyChildElement;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, reportingOrgElement, "type", typeCode);

                    // Create secondary-reporter attribute
                    string secondaryReporter = deliveryFramework.GetAttributeValue<bool?>("msiati_secondaryreporter") == true ? "1" : "0";
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, reportingOrgElement, "secondary-reporter", secondaryReporter);

                    // Create narrative elements
                    Guid accountId = deliveryFramework.GetAliasedValue<Guid>("ReportingOrg.accountid");
                    anyChildElement =
                        CommonUtilities.CreateNarrativeElements(_service, xmlDocument, reportingOrgElement, deliveryFramework, "ReportingOrg.name", true, accountId,
                            NarrativeTranslationEntity.Account, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                    // If any child element, add parent
                    if (anyChildElement)
                    {
                        iatiActivityElement.AppendChild(reportingOrgElement);
                    }

                    return anyChildElement;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region title

        /// <summary>
        /// Create iati-activities/iati-activity/title element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateTitleElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework, Guid deliveryFrameworkId)
        {
            try
            {
                // Create title and narrative elements
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, iatiActivityElement, deliveryFramework, "msnfp_name", false, deliveryFrameworkId,
                    NarrativeTranslationEntity.DeliveryFramework, NarrativeTranslationAttribute.Name, true, "title");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region description

        /// <summary>
        /// Create iati-activities/iati-activity/description elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateDescriptionElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var deliveryFrameworkDescriptionQueryExpression = new QueryExpression("msiati_deliveryframeworkdescription")
                {
                    ColumnSet = new ColumnSet("msiati_description"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Description Type
                        new LinkEntity(
                            "msiati_deliveryframeworkdescription",
                            "msiati_nonembeddedcodelist",
                            "msiati_typeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "DescriptionType",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                // Create description and narrative elements (for main delivery framework)
                bool anyChildElement = CreateDescriptionGeneralElement(xmlDocument, iatiActivityElement, deliveryFramework);

                DataCollection<Entity> deliveryFrameworkDescriptions = _service.RetrieveMultiple(deliveryFrameworkDescriptionQueryExpression).Entities;
                foreach (Entity deliveryFrameworkDescription in deliveryFrameworkDescriptions)
                {
                    // Create description element
                    anyChildElement = CreateDescriptionIndividualElement(xmlDocument, iatiActivityElement, deliveryFrameworkDescription) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create general iati-activities/iati-activity/description element (using the delivery framework's main description)
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        private bool CreateDescriptionGeneralElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework)
        {
            try
            {
                // Create description element
                XmlElement descriptionElement = xmlDocument.CreateElement("description");

                // Create type attribute
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, descriptionElement, "type", Constants.GeneralDescriptionTypeCode);

                // Create narrative elements
                bool anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, descriptionElement, deliveryFramework, "msnfp_description", false, deliveryFramework.Id,
                        NarrativeTranslationEntity.DeliveryFramework, NarrativeTranslationAttribute.Description, false);

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(descriptionElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/description element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkDescription"></param>
        private bool CreateDescriptionIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFrameworkDescription)
        {
            try
            {
                // Create description element
                XmlElement descriptionElement = xmlDocument.CreateElement("description");

                // Create type attribute
                string typeCode = deliveryFrameworkDescription.GetAliasedValue<string>("DescriptionType.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(typeCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, descriptionElement, "type", typeCode);

                // Create narrative elements
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, descriptionElement, deliveryFrameworkDescription, "msiati_description", false,
                        deliveryFrameworkDescription.Id, NarrativeTranslationEntity.DeliveryFrameworkDescription, NarrativeTranslationAttribute.Description, false) ||
                    anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(descriptionElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region participating-org

        /// <summary>
        /// Create iati-activities/iati-activity/participating-org element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateParticipatingOrgElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var participatingOrgQueryExpression = new QueryExpression("msiati_participatingorganization")
                {
                    ColumnSet = new ColumnSet("msiati_participatingorganizationrole", "msiati_participatingorganizationactivity"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Participating Organization Account
                        new LinkEntity(
                            "msiati_participatingorganization",
                            "account",
                            "msiati_accountid",
                            "accountid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "Account",
                            Columns = new ColumnSet("accountid", "msiati_iatiorganizationidentifier", "name"),
                            LinkEntities =
                            {
                                // Reporting Organization Type
                                new LinkEntity(
                                    "account",
                                    "msiati_nonembeddedcodelist",
                                    "msiati_organizationtypeid",
                                    "msiati_nonembeddedcodelistid",
                                    JoinOperator.LeftOuter)
                                {
                                    Columns = new ColumnSet("msiati_code"),
                                    EntityAlias = "ParticipatingOrgType"
                                }
                            }
                        },
                        // CRS Channel
                        new LinkEntity(
                            "msiati_participatingorganization",
                            "msiati_nonembeddedcodelist",
                            "msiati_crschannelid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "CrsChannel",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> participatingOrgs = _service.RetrieveMultiple(participatingOrgQueryExpression).Entities;
                foreach (Entity participatingOrg in participatingOrgs)
                {
                    // Create participating-org element
                    anyChildElement = CreateParticipatingOrgIndividualElement(xmlDocument, iatiActivityElement, participatingOrg) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/participating-org element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="participatingOrg"></param>
        private bool CreateParticipatingOrgIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity participatingOrg)
        {
            try
            {
                // Create participating-org element
                XmlElement participatingOrgElement = xmlDocument.CreateElement("participating-org");

                // Create ref attribute
                string @ref = participatingOrg.GetAliasedValue<string>("Account.msiati_iatiorganizationidentifier");
                bool anyChildElement = !string.IsNullOrWhiteSpace(@ref);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, participatingOrgElement, "ref", @ref);

                // Create type attribute
                string typeCode = participatingOrg.GetAliasedValue<string>("ParticipatingOrgType.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(typeCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, participatingOrgElement, "type", typeCode);

                // Create role attribute
                int? roleId = participatingOrg.GetOptionSetValue("msiati_participatingorganizationrole");
                if (roleId != null)
                {
                    string roleCode = CommonUtilities.GetCodelistCodeByOptionSetId(Constants.OrganizationRoleIdCodeMapping, (OrganizationRole)roleId.Value);
                    anyChildElement = !string.IsNullOrWhiteSpace(roleCode) || anyChildElement;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, participatingOrgElement, "role", roleCode);
                }

                // Create activity-id attribute
                string activityIdentifier = participatingOrg.GetAttributeValue<string>("msiati_participatingorganizationactivity");
                anyChildElement = !string.IsNullOrWhiteSpace(activityIdentifier) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, participatingOrgElement, "activity-id", activityIdentifier);

                // Create crs-channel-code attribute
                string crsChannelCode = participatingOrg.GetAliasedValue<string>("CrsChannel.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(crsChannelCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, participatingOrgElement, "crs-channel-code", crsChannelCode);

                // Create narrative elements
                Guid accountId = participatingOrg.GetAliasedValue<Guid>("Account.accountid");
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, participatingOrgElement, participatingOrg, "Account.name", true, accountId,
                        NarrativeTranslationEntity.Account, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(participatingOrgElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region other-identifier

        /// <summary>
        /// Create iati-activities/iati-activity/other-identifier element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateOtherIdentifierElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var otherIdentifierQueryExpression = new QueryExpression("msiati_identifier")
                {
                    ColumnSet = new ColumnSet("msiati_reference"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Other Identifier Type
                        new LinkEntity(
                            "msiati_identifier",
                            "msiati_nonembeddedcodelist",
                            "msiati_typeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "OtherIdentifierType",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Owner Organization
                        new LinkEntity(
                            "msiati_identifier",
                            "account",
                            "msiati_ownerorganizationid",
                            "accountid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "OwnerOrg",
                            Columns = new ColumnSet("accountid", "name", "msiati_iatiorganizationidentifier")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> otherIdentifiers = _service.RetrieveMultiple(otherIdentifierQueryExpression).Entities;
                foreach (Entity otherIdentifier in otherIdentifiers)
                {
                    // Create other-identifier element
                    anyChildElement = CreateOtherIdentifierIndividualElement(xmlDocument, iatiActivityElement, otherIdentifier) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/other-identifier element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="otherIdentifier"></param>
        private bool CreateOtherIdentifierIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity otherIdentifier)
        {
            try
            {
                // Create other-identifier element
                XmlElement otherIdentifierElement = xmlDocument.CreateElement("other-identifier");

                // Create ref attribute
                string @ref = otherIdentifier.GetAttributeValue<string>("msiati_reference");
                bool anyChildElement = !string.IsNullOrWhiteSpace(@ref);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, otherIdentifierElement, "ref", @ref);

                // Create type attribute
                string typeCode = otherIdentifier.GetAliasedValue<string>("OtherIdentifierType.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(typeCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, otherIdentifierElement, "type", typeCode);

                // Create owner-org element
                anyChildElement = CreateOtherIdentifierOwnerOrgIndividualElement(xmlDocument, otherIdentifierElement, otherIdentifier) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(otherIdentifierElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/other-identifier/owner-org element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="otherIdentifier"></param>
        private bool CreateOtherIdentifierOwnerOrgIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity otherIdentifier)
        {
            try
            {
                bool anyChildElement = false;
                if (otherIdentifier.Contains("OwnerOrg.accountid"))
                {
                    // Create owner-org element
                    XmlElement ownerOrgElement = xmlDocument.CreateElement("owner-org");

                    // Create ref attribute
                    string ownerOrgRef = otherIdentifier.GetAliasedValue<string>("OwnerOrg.msiati_iatiorganizationidentifier");
                    anyChildElement = !string.IsNullOrWhiteSpace(ownerOrgRef);
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, ownerOrgElement, "ref", ownerOrgRef);

                    // Create narrative elements
                    Guid ownerOrgAccountId = otherIdentifier.GetAliasedValue<Guid>("OwnerOrg.accountid");
                    anyChildElement =
                        CommonUtilities.CreateNarrativeElements(_service, xmlDocument, ownerOrgElement, otherIdentifier, "OwnerOrg.name", true, ownerOrgAccountId,
                            NarrativeTranslationEntity.Account, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                    // If any child element, add parent
                    if (anyChildElement)
                    {
                        iatiActivityElement.AppendChild(ownerOrgElement);
                    }
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region activity-status

        /// <summary>
        /// Create iati-activities/iati-activity/activity-status element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        private bool CreateActivityStatusElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework)
        {
            try
            {
                int? activityStatusId = deliveryFramework.GetOptionSetValue("msnfp_status");
                if (activityStatusId != null)
                {
                    string activityStatusCode = CommonUtilities.GetCodelistCodeByOptionSetId(Constants.ActivityStatusIdCodeMapping, (ActivityStatus)activityStatusId.Value);
                    if (!string.IsNullOrWhiteSpace(activityStatusCode))
                    {
                        // Create activity-status element
                        XmlElement activityStatusElement = XmlUtilities.CreateChildXmlElement(xmlDocument, iatiActivityElement, "activity-status");

                        // Create code attribute
                        XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, activityStatusElement, "code", activityStatusCode);

                        return true;
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region activity-date

        /// <summary>
        /// Create iati-activities/iati-activity/activity-date elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        private bool CreateActivityDateElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework)
        {
            try
            {
                // Create planned start date element
                DateTime? plannedStartDate = deliveryFramework.GetAttributeValue<DateTime?>("msnfp_plannedstartdate");
                bool anyChildElement = CreateActivityDateElement(xmlDocument, iatiActivityElement, plannedStartDate, ActivityDateType.PlannedStart);

                // Create actual start date element
                DateTime? actualStartDate = deliveryFramework.GetAttributeValue<DateTime?>("msnfp_startdate");
                anyChildElement = CreateActivityDateElement(xmlDocument, iatiActivityElement, actualStartDate, ActivityDateType.ActualStart) || anyChildElement;

                // Create planned end date element
                DateTime? plannedEndDate = deliveryFramework.GetAttributeValue<DateTime?>("msnfp_plannedenddate");
                anyChildElement = CreateActivityDateElement(xmlDocument, iatiActivityElement, plannedEndDate, ActivityDateType.PlannedEnd) || anyChildElement;

                // Create actual end date element
                DateTime? actualEndDate = deliveryFramework.GetAttributeValue<DateTime?>("msnfp_enddate");
                anyChildElement = CreateActivityDateElement(xmlDocument, iatiActivityElement, actualEndDate, ActivityDateType.ActualEnd) || anyChildElement;

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/activity-date elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="date"></param>
        /// <param name="activityDateType"></param>
        private bool CreateActivityDateElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, DateTime? date, ActivityDateType activityDateType)
        {
            try
            {
                if (date != null)
                {
                    // Create activity-date element
                    XmlElement activityDateElement = XmlUtilities.CreateChildXmlElement(xmlDocument, iatiActivityElement, "activity-date");

                    // Create type attribute
                    string typeCode = CommonUtilities.GetCodelistCodeByOptionSetId(Constants.ActivityDateTypeMapping, activityDateType);
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, activityDateElement, "type", typeCode);

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, activityDateElement, "iso-date", date, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region contact-info

        /// <summary>
        /// Create iati-activities/iati-activity/contact-info elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateActivityContactInfoElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var deliveryFrameworkContactQueryExpression = new QueryExpression("msiati_deliveryframeworkcontact")
                {
                    ColumnSet = new ColumnSet(),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Contact
                        new LinkEntity(
                            "msiati_deliveryframeworkcontact",
                            "contact",
                            "msiati_contactid",
                            "contactid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "Contact",
                            Columns = new ColumnSet(
                                "contactid",
                                "department",
                                "fullname",
                                "jobtitle",
                                "telephone1",
                                "telephone2",
                                "telephone3",
                                "emailaddress1",
                                "emailaddress2",
                                "emailaddress3",
                                "address1_composite",
                                "address2_composite",
                                "address3_composite"),
                            LinkEntities =
                            {
                                // Contact Organization
                                new LinkEntity(
                                    "contact",
                                    "account",
                                    "accountid",
                                    "accountid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "ContactOrganization",
                                    Columns = new ColumnSet("accountid", "name")
                                }
                            }
                        },
                        // Contact Type
                        new LinkEntity(
                            "msiati_deliveryframeworkcontact",
                            "msiati_nonembeddedcodelist",
                            "msiati_contacttypeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "ContactType",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> deliveryFrameworkContacts = _service.RetrieveMultiple(deliveryFrameworkContactQueryExpression).Entities;
                foreach (Entity deliveryFrameworkContact in deliveryFrameworkContacts)
                {
                    // Create contact-info element
                    anyChildElement = CreateActivityContactInfoIndividualElement(xmlDocument, iatiActivityElement, deliveryFrameworkContact) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/contact-info element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkContact"></param>
        private bool CreateActivityContactInfoIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFrameworkContact)
        {
            try
            {
                // Create contact-info element
                XmlElement contactInfoElement = xmlDocument.CreateElement("contact-info");

                // Create type attribute
                string typeCode = deliveryFrameworkContact.GetAliasedValue<string>("ContactType.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(typeCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, contactInfoElement, "type", typeCode);

                Guid contactId = deliveryFrameworkContact.GetAliasedValue<Guid>("Contact.contactid");

                // Create organisation element
                anyChildElement = CreateContactInfoOrganizationElement(xmlDocument, contactInfoElement, deliveryFrameworkContact) || anyChildElement;

                // Create department element
                anyChildElement = CreateContactInfoDepartmentElement(xmlDocument, contactInfoElement, deliveryFrameworkContact, contactId) || anyChildElement;

                // Create person-name element
                anyChildElement = CreateContactInfoPersonNameElement(xmlDocument, contactInfoElement, deliveryFrameworkContact, contactId) || anyChildElement;

                // Create job-title element
                anyChildElement = CreateContactInfoJobTitleElement(xmlDocument, contactInfoElement, deliveryFrameworkContact, contactId) || anyChildElement;

                // Create telephone elements
                anyChildElement = CreateContactInfoTelephoneElements(xmlDocument, contactInfoElement, deliveryFrameworkContact) || anyChildElement;

                // Create email elements
                anyChildElement = CreateContactInfoEmailElements(xmlDocument, contactInfoElement, deliveryFrameworkContact) || anyChildElement;

                // Create website elements
                anyChildElement = CreateContactInfoWebsiteElements(xmlDocument, contactInfoElement, contactId) || anyChildElement;

                // Create mailing-address elements
                anyChildElement = CreateContactInfoMailingAddressElements(xmlDocument, contactInfoElement, deliveryFrameworkContact, contactId) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(contactInfoElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/contact-info/organisation element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="contactInfoElement"></param>
        /// <param name="deliveryFrameworkContact"></param>
        private bool CreateContactInfoOrganizationElement(XmlDocument xmlDocument, XmlElement contactInfoElement, Entity deliveryFrameworkContact)
        {
            try
            {
                if (deliveryFrameworkContact.Contains("ContactOrganization.accountid"))
                {
                    Guid accountId = deliveryFrameworkContact.GetAliasedValue<Guid>("ContactOrganization.accountid");

                    // Create organisation and narrative elements
                    return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, contactInfoElement, deliveryFrameworkContact, "ContactOrganization.name", true, accountId,
                        NarrativeTranslationEntity.Account, NarrativeTranslationAttribute.Name, true, "organisation");
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/contact-info/department element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="contactInfoElement"></param>
        /// <param name="deliveryFrameworkContact"></param>
        /// <param name="contactId"></param>
        private bool CreateContactInfoDepartmentElement(XmlDocument xmlDocument, XmlElement contactInfoElement, Entity deliveryFrameworkContact, Guid contactId)
        {
            try
            {
                // Create department and narrative elements
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, contactInfoElement, deliveryFrameworkContact, "Contact.department", true, contactId,
                    NarrativeTranslationEntity.Contact, NarrativeTranslationAttribute.Department, true, "department");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/contact-info/person-name element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="contactInfoElement"></param>
        /// <param name="deliveryFrameworkContact"></param>
        /// <param name="contactId"></param>
        private bool CreateContactInfoPersonNameElement(XmlDocument xmlDocument, XmlElement contactInfoElement, Entity deliveryFrameworkContact, Guid contactId)
        {
            try
            {
                // Create person-name and narrative elements
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, contactInfoElement, deliveryFrameworkContact, "Contact.fullname", true, contactId,
                    NarrativeTranslationEntity.Contact, NarrativeTranslationAttribute.FullName, true, "person-name");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/contact-info/job-title element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="contactInfoElement"></param>
        /// <param name="deliveryFrameworkContact"></param>
        /// <param name="contactId"></param>
        private bool CreateContactInfoJobTitleElement(XmlDocument xmlDocument, XmlElement contactInfoElement, Entity deliveryFrameworkContact, Guid contactId)
        {
            try
            {
                // Create job-title and narrative elements
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, contactInfoElement, deliveryFrameworkContact, "Contact.jobtitle", true, contactId,
                    NarrativeTranslationEntity.Contact, NarrativeTranslationAttribute.JobTitle, true, "job-title");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/contact-info/telephone elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="contactInfoElement"></param>
        /// <param name="deliveryFrameworkContact"></param>
        private bool CreateContactInfoTelephoneElements(XmlDocument xmlDocument, XmlElement contactInfoElement, Entity deliveryFrameworkContact)
        {
            try
            {
                // Create telephone1 element
                string telephone1 = deliveryFrameworkContact.GetAliasedValue<string>("Contact.telephone1");
                bool anyChildElement = !string.IsNullOrWhiteSpace(telephone1);
                XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, contactInfoElement, "telephone", telephone1);

                // Create telephone2 element
                string telephone2 = deliveryFrameworkContact.GetAliasedValue<string>("Contact.telephone2");
                anyChildElement = !string.IsNullOrWhiteSpace(telephone2) || anyChildElement;
                XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, contactInfoElement, "telephone", telephone2);

                // Create telephone3 element
                string telephone3 = deliveryFrameworkContact.GetAliasedValue<string>("Contact.telephone3");
                anyChildElement = !string.IsNullOrWhiteSpace(telephone3) || anyChildElement;
                XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, contactInfoElement, "telephone", telephone3);

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/contact-info/email elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="contactInfoElement"></param>
        /// <param name="deliveryFrameworkContact"></param>
        private bool CreateContactInfoEmailElements(XmlDocument xmlDocument, XmlElement contactInfoElement, Entity deliveryFrameworkContact)
        {
            try
            {
                // Create emailaddress1 element
                string emailaddress1 = deliveryFrameworkContact.GetAliasedValue<string>("Contact.emailaddress1");
                bool anyChildElement = !string.IsNullOrWhiteSpace(emailaddress1);
                XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, contactInfoElement, "email", emailaddress1);

                // Create emailaddress2 element
                string emailaddress2 = deliveryFrameworkContact.GetAliasedValue<string>("Contact.emailaddress2");
                anyChildElement = !string.IsNullOrWhiteSpace(emailaddress2) || anyChildElement;
                XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, contactInfoElement, "email", emailaddress2);

                // Create emailaddress3 element
                string emailaddress3 = deliveryFrameworkContact.GetAliasedValue<string>("Contact.emailaddress3");
                anyChildElement = !string.IsNullOrWhiteSpace(emailaddress3) || anyChildElement;
                XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, contactInfoElement, "email", emailaddress3);

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/contact-info/website elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="contactInfoElement"></param>
        /// <param name="contactId"></param>
        private bool CreateContactInfoWebsiteElements(XmlDocument xmlDocument, XmlElement contactInfoElement, Guid contactId)
        {
            try
            {
                // Build query to fetch data
                var websiteQueryExpression = new QueryExpression("msiati_website")
                {
                    ColumnSet = new ColumnSet("msiati_url"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_contactid", ConditionOperator.Equal, contactId)
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> websites = _service.RetrieveMultiple(websiteQueryExpression).Entities;
                foreach (Entity website in websites)
                {
                    // Create website element
                    anyChildElement = CreateContactInfoWebsiteIndividualElement(xmlDocument, contactInfoElement, website) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/contact-info/website element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="contactInfoElement"></param>
        /// <param name="website"></param>
        private bool CreateContactInfoWebsiteIndividualElement(XmlDocument xmlDocument, XmlElement contactInfoElement, Entity website)
        {
            try
            {
                // Create website element
                string websiteUrl = website.GetAttributeValue<string>("msiati_url");
                bool anyChildElement = !string.IsNullOrWhiteSpace(websiteUrl);
                XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, contactInfoElement, "website", websiteUrl);

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/contact-info/mailing-address elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="contactInfoElement"></param>
        /// <param name="deliveryFrameworkContact"></param>
        /// <param name="contactId"></param>
        private bool CreateContactInfoMailingAddressElements(XmlDocument xmlDocument, XmlElement contactInfoElement, Entity deliveryFrameworkContact, Guid contactId)
        {
            try
            {
                // Create address1 element
                bool anyChildElement = CommonUtilities.CreateNarrativeElements(_service, xmlDocument, contactInfoElement, deliveryFrameworkContact, "Contact.address1_composite",
                    true, contactId, NarrativeTranslationEntity.Contact, NarrativeTranslationAttribute.Address1, true, "mailing-address");

                // Create address2 element
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, contactInfoElement, deliveryFrameworkContact, "Contact.address2_composite", true, contactId,
                        NarrativeTranslationEntity.Contact, NarrativeTranslationAttribute.Address2, true, "mailing-address") || anyChildElement;

                // Create address3 element
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, contactInfoElement, deliveryFrameworkContact, "Contact.address3_composite", true, contactId,
                        NarrativeTranslationEntity.Contact, NarrativeTranslationAttribute.Address3, true, "mailing-address") || anyChildElement;

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region activity-scope

        /// <summary>
        /// Create iati-activities/iati-activity/activity-scope element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        private bool CreateActivityScopeElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework)
        {
            try
            {
                string activityScope = deliveryFramework.GetAliasedValue<string>("ActivityScope.msiati_code");
                if (!string.IsNullOrWhiteSpace(activityScope))
                {
                    // Create activity-scope element
                    XmlElement activityScopeElement = XmlUtilities.CreateChildXmlElement(xmlDocument, iatiActivityElement, "activity-scope");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, activityScopeElement, "code", activityScope);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region recipient-country

        /// <summary>
        /// Create iati-activities/iati-activity/recipient-country elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateRecipientCountryElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var recipientCountryQueryExpression = new QueryExpression("msiati_recipientcountry")
                {
                    ColumnSet = new ColumnSet("msiati_percentage", "msiati_name"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Country
                        new LinkEntity(
                            "msiati_recipientcountry",
                            "msiati_nonembeddedcodelist",
                            "msiati_countryid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "Country",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> recipientCountries = _service.RetrieveMultiple(recipientCountryQueryExpression).Entities;
                foreach (Entity recipientCountry in recipientCountries)
                {
                    // Create recipient-country element
                    anyChildElement = CreateRecipientCountryIndividualElement(xmlDocument, iatiActivityElement, recipientCountry) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/recipient-country element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="recipientCountry"></param>
        private bool CreateRecipientCountryIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity recipientCountry)
        {
            try
            {
                // Create recipient-country element
                XmlElement recipientCountryElement = xmlDocument.CreateElement("recipient-country");

                // Create code attribute
                string countryCode = recipientCountry.GetAliasedValue<string>("Country.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(countryCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientCountryElement, "code", countryCode);

                // Create percentage attribute
                decimal? percentage = recipientCountry.GetAttributeValue<decimal?>("msiati_percentage");
                anyChildElement = percentage != null || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientCountryElement, "percentage", percentage, Constants.DecimalFormatTwoDecimalDigits);

                // Create narrative elements
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, recipientCountryElement, recipientCountry, "msiati_name", false, recipientCountry.Id,
                        NarrativeTranslationEntity.RecipientCountry, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(recipientCountryElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region recipient-region

        /// <summary>
        /// Create iati-activities/iati-activity/recipient-region elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateRecipientRegionElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var recipientRegionQueryExpression = new QueryExpression("msiati_recipientregion")
                {
                    ColumnSet = new ColumnSet("msiati_percentage", "msiati_name"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Region
                        new LinkEntity(
                            "msiati_recipientregion",
                            "msiati_nonembeddedcodelist",
                            "msiati_regionid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "Region",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Region Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "RegionVocabulary",
                                    Columns = new ColumnSet("msiati_code", "msiati_uri")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> recipientRegions = _service.RetrieveMultiple(recipientRegionQueryExpression).Entities;
                foreach (Entity recipientRegion in recipientRegions)
                {
                    // Create recipient-region element
                    anyChildElement = CreateRecipientRegionIndividualElement(xmlDocument, iatiActivityElement, recipientRegion) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/recipient-region element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="recipientRegion"></param>
        private bool CreateRecipientRegionIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity recipientRegion)
        {
            try
            {
                // Create recipient-region element
                XmlElement recipientRegionElement = xmlDocument.CreateElement("recipient-region");

                // Create code attribute
                string regionCode = recipientRegion.GetAliasedValue<string>("Region.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(regionCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientRegionElement, "code", regionCode);

                // Create vocabulary code attribute
                string vocabularyCode = recipientRegion.GetAliasedValue<string>("RegionVocabulary.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(vocabularyCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientRegionElement, "vocabulary", vocabularyCode);

                // If reporting organization vocabulary, include vocabulary-uri
                if (vocabularyCode == "99")
                {
                    // Create vocabulary-uri attribute
                    string vocabularyUri = recipientRegion.GetAliasedValue<string>("RegionVocabulary.msiati_uri");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientRegionElement, "vocabulary-uri", vocabularyUri);
                }

                // Create percentage attribute
                decimal? percentage = recipientRegion.GetAttributeValue<decimal?>("msiati_percentage");
                anyChildElement = percentage != null || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientRegionElement, "percentage", percentage, Constants.DecimalFormatTwoDecimalDigits);

                // Create narrative elements
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, recipientRegionElement, recipientRegion, "msiati_name", false, recipientRegion.Id,
                        NarrativeTranslationEntity.RecipientRegion, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(recipientRegionElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region location

        /// <summary>
        /// Create iati-activities/iati-activity/location elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateLocationElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var locationQueryExpression = new QueryExpression("msiati_location")
                {
                    ColumnSet = new ColumnSet("msiati_name", "msiati_description", "msiati_activitylocationdescription", "msiati_latitude", "msiati_longitude", "msiati_reference"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId),
                            new ConditionExpression("msiati_type", ConditionOperator.Equal, (int) LocationType.Parent)
                        }
                    },
                    LinkEntities =
                    {
                        // Location Reach
                        new LinkEntity(
                            "msiati_location",
                            "msiati_nonembeddedcodelist",
                            "msiati_reachid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "LocationReach",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Location Exactness
                        new LinkEntity(
                            "msiati_location",
                            "msiati_nonembeddedcodelist",
                            "msiati_exactnessid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "LocationExactness",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Location Class
                        new LinkEntity(
                            "msiati_location",
                            "msiati_nonembeddedcodelist",
                            "msiati_locationclassid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "LocationClass",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Feature Designation
                        new LinkEntity(
                            "msiati_location",
                            "msiati_nonembeddedcodelist",
                            "msiati_featuredesignationid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "FeatureDesignation",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> locations = _service.RetrieveMultiple(locationQueryExpression).Entities;
                foreach (Entity location in locations)
                {
                    // Create location element
                    anyChildElement = CreateLocationIndividualElement(xmlDocument, iatiActivityElement, location) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/location element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="location"></param>
        private bool CreateLocationIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity location)
        {
            try
            {
                Guid locationId = location.Id;

                // Create location element
                XmlElement locationElement = xmlDocument.CreateElement("location");

                // Create ref attribute
                string @ref = location.GetAttributeValue<string>("msiati_reference");
                bool anyChildElement = !string.IsNullOrWhiteSpace(@ref);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, locationElement, "ref", @ref);

                // Create location-reach element
                anyChildElement = CreateLocationReachElement(xmlDocument, locationElement, location) || anyChildElement;

                // Create location-id elements
                anyChildElement = CreateLocationIdElements(xmlDocument, locationElement, locationId) || anyChildElement;

                // Create name element
                anyChildElement = CreateLocationNameElement(xmlDocument, locationElement, location, locationId) || anyChildElement;

                // Create description element
                anyChildElement = CreateLocationDescriptionElement(xmlDocument, locationElement, location, locationId) || anyChildElement;

                // Create activity-description element
                anyChildElement = CreateLocationActivityDescriptionElement(xmlDocument, locationElement, location, locationId) || anyChildElement;

                // Create administrative elements
                anyChildElement = CreateLocationAdministrativeElements(xmlDocument, locationElement, locationId) || anyChildElement;

                // Create point element
                anyChildElement = CreateLocationPointElement(xmlDocument, locationElement, location) || anyChildElement;

                // Create exactness element
                anyChildElement = CreateLocationExactnessElement(xmlDocument, locationElement, location) || anyChildElement;

                // Create location-class element
                anyChildElement = CreateLocationClassElement(xmlDocument, locationElement, location) || anyChildElement;

                // Create feature-designation element
                anyChildElement = CreateLocationFeatureDesignationElement(xmlDocument, locationElement, location) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(locationElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/location/location-reach element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="locationElement"></param>
        /// <param name="location"></param>
        private bool CreateLocationReachElement(XmlDocument xmlDocument, XmlElement locationElement, Entity location)
        {
            try
            {
                // Create location-reach element
                string locationReachCode = location.GetAliasedValue<string>("LocationReach.msiati_code");
                if (!string.IsNullOrWhiteSpace(locationReachCode))
                {
                    XmlElement locationReachElement = XmlUtilities.CreateChildXmlElement(xmlDocument, locationElement, "location-reach");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, locationReachElement, "code", locationReachCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/location/location-id elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="locationElement"></param>
        /// <param name="parentLocationId"></param>
        private bool CreateLocationIdElements(XmlDocument xmlDocument, XmlElement locationElement, Guid parentLocationId)
        {
            try
            {
                // Build query to fetch data
                var childLocationQueryExpression = new QueryExpression("msiati_location")
                {
                    ColumnSet = new ColumnSet(),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_parentlocationid", ConditionOperator.Equal, parentLocationId),
                            new ConditionExpression("msiati_type", ConditionOperator.Equal, (int) LocationType.Child)
                        }
                    },
                    LinkEntities =
                    {
                        // Location Code
                        new LinkEntity(
                            "msiati_location",
                            "msiati_nonembeddedcodelist",
                            "msiati_codeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "LocationCode",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Location Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "LocationVocabulary",
                                    Columns = new ColumnSet("msiati_code")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> childLocations = _service.RetrieveMultiple(childLocationQueryExpression).Entities;
                foreach (Entity childLocation in childLocations)
                {
                    // Create location-id element
                    anyChildElement = CreateLocationIdIndividualElement(xmlDocument, locationElement, childLocation) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/location/location-id element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="locationElement"></param>
        /// <param name="childLocation"></param>
        private bool CreateLocationIdIndividualElement(XmlDocument xmlDocument, XmlElement locationElement, Entity childLocation)
        {
            try
            {
                string locationCode = childLocation.GetAliasedValue<string>("LocationCode.msiati_code");
                if (!string.IsNullOrWhiteSpace(locationCode))
                {
                    // Create location-id element
                    XmlElement locationIdElement = XmlUtilities.CreateChildXmlElement(xmlDocument, locationElement, "location-id");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, locationIdElement, "code", locationCode);

                    // Create vocabulary attribute
                    string vocabularyCode = childLocation.GetAliasedValue<string>("LocationVocabulary.msiati_code");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, locationIdElement, "vocabulary", vocabularyCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/location/name element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="contactInfoElement"></param>
        /// <param name="location"></param>
        /// <param name="locationId"></param>
        private bool CreateLocationNameElement(XmlDocument xmlDocument, XmlElement contactInfoElement, Entity location, Guid locationId)
        {
            try
            {
                // Create name and narrative elements
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, contactInfoElement, location, "msiati_name", false, locationId,
                    NarrativeTranslationEntity.Location, NarrativeTranslationAttribute.Name, true, "name");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/location/description element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="contactInfoElement"></param>
        /// <param name="location"></param>
        /// <param name="locationId"></param>
        private bool CreateLocationDescriptionElement(XmlDocument xmlDocument, XmlElement contactInfoElement, Entity location, Guid locationId)
        {
            try
            {
                // Create description and narrative elements
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, contactInfoElement, location, "msiati_description", false, locationId,
                    NarrativeTranslationEntity.Location, NarrativeTranslationAttribute.Description, true, "description");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/location/activity-description element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="contactInfoElement"></param>
        /// <param name="location"></param>
        /// <param name="locationId"></param>
        private bool CreateLocationActivityDescriptionElement(XmlDocument xmlDocument, XmlElement contactInfoElement, Entity location, Guid locationId)
        {
            try
            {
                // Create activity-description and narrative elements
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, contactInfoElement, location, "msiati_activitylocationdescription", false, locationId,
                    NarrativeTranslationEntity.Location, NarrativeTranslationAttribute.ActivityLocationDescription, true, "activity-description");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/location/administrative elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="locationElement"></param>
        /// <param name="parentLocationId"></param>
        private bool CreateLocationAdministrativeElements(XmlDocument xmlDocument, XmlElement locationElement, Guid parentLocationId)
        {
            try
            {
                // Build query to fetch data
                var childLocationQueryExpression = new QueryExpression("msiati_location")
                {
                    ColumnSet = new ColumnSet("msiati_level"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_parentlocationid", ConditionOperator.Equal, parentLocationId),
                            new ConditionExpression("msiati_type", ConditionOperator.Equal, (int) LocationType.Administrative)
                        }
                    },
                    LinkEntities =
                    {
                        // Location Code
                        new LinkEntity(
                            "msiati_location",
                            "msiati_nonembeddedcodelist",
                            "msiati_codeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "LocationCode",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Location Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "LocationVocabulary",
                                    Columns = new ColumnSet("msiati_code")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> childLocations = _service.RetrieveMultiple(childLocationQueryExpression).Entities;
                foreach (Entity childLocation in childLocations)
                {
                    // Create administrative element
                    anyChildElement = CreateLocationAdministrativeIndividualElement(xmlDocument, locationElement, childLocation) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/location/administrative element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="locationElement"></param>
        /// <param name="childLocation"></param>
        private bool CreateLocationAdministrativeIndividualElement(XmlDocument xmlDocument, XmlElement locationElement, Entity childLocation)
        {
            try
            {
                string locationCode = childLocation.GetAliasedValue<string>("LocationCode.msiati_code");
                if (!string.IsNullOrWhiteSpace(locationCode))
                {
                    // Create administrative element
                    XmlElement administrativeElement = XmlUtilities.CreateChildXmlElement(xmlDocument, locationElement, "administrative");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, administrativeElement, "code", locationCode);

                    // Create vocabulary attribute
                    string vocabularyCode = childLocation.GetAliasedValue<string>("LocationVocabulary.msiati_code");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, administrativeElement, "vocabulary", vocabularyCode);

                    // Create level attribute
                    int? level = childLocation.GetAttributeValue<int?>("msiati_level");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, administrativeElement, "level", level);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/location/point element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="locationElement"></param>
        /// <param name="location"></param>
        private bool CreateLocationPointElement(XmlDocument xmlDocument, XmlElement locationElement, Entity location)
        {
            try
            {
                decimal? latitude = location.GetAttributeValue<decimal?>("msiati_latitude");
                decimal? longitude = location.GetAttributeValue<decimal?>("msiati_longitude");

                if (latitude != null || longitude != null)
                {
                    string latitudeString = latitude == null ? "0" : latitude.Value.ToString("0.########");
                    string longitudeString = longitude == null ? "0" : longitude.Value.ToString("0.########");
                    string pos = $"{latitudeString} {longitudeString}";

                    // Create point element
                    XmlElement pointElement = XmlUtilities.CreateChildXmlElement(xmlDocument, locationElement, "point");

                    // Create srsName attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, pointElement, "srsName", Constants.SrsName);

                    // Create pos element
                    XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, pointElement, "pos", pos);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/location/exactness element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="locationElement"></param>
        /// <param name="location"></param>
        private bool CreateLocationExactnessElement(XmlDocument xmlDocument, XmlElement locationElement, Entity location)
        {
            try
            {
                string exactnessCode = location.GetAliasedValue<string>("LocationExactness.msiati_code");
                if (!string.IsNullOrWhiteSpace(exactnessCode))
                {
                    // Create exactness element
                    XmlElement exactnessElement = XmlUtilities.CreateChildXmlElement(xmlDocument, locationElement, "exactness");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, exactnessElement, "code", exactnessCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/location/location-class element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="locationElement"></param>
        /// <param name="location"></param>
        private bool CreateLocationClassElement(XmlDocument xmlDocument, XmlElement locationElement, Entity location)
        {
            try
            {
                string locationClassCode = location.GetAliasedValue<string>("LocationClass.msiati_code");
                if (!string.IsNullOrWhiteSpace(locationClassCode))
                {
                    // Create location-class element
                    XmlElement locationClassElement = XmlUtilities.CreateChildXmlElement(xmlDocument, locationElement, "location-class");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, locationClassElement, "code", locationClassCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/location/feature-designation element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="locationElement"></param>
        /// <param name="location"></param>
        private bool CreateLocationFeatureDesignationElement(XmlDocument xmlDocument, XmlElement locationElement, Entity location)
        {
            try
            {
                string featureDesignationCode = location.GetAliasedValue<string>("FeatureDesignation.msiati_code");
                if (!string.IsNullOrWhiteSpace(featureDesignationCode))
                {
                    // Create feature-designation element
                    XmlElement featureDesignationElement = XmlUtilities.CreateChildXmlElement(xmlDocument, locationElement, "feature-designation");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, featureDesignationElement, "code", featureDesignationCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region sector

        /// <summary>
        /// Create iati-activities/iati-activity/sector elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateSectorElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var sectorQueryExpression = new QueryExpression("msiati_sector")
                {
                    ColumnSet = new ColumnSet("msiati_name", "msiati_percentage"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Sector Code
                        new LinkEntity(
                            "msiati_sector",
                            "msiati_nonembeddedcodelist",
                            "msiati_codeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "SectorCode",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Sector Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "SectorVocabulary",
                                    Columns = new ColumnSet("msiati_code", "msiati_uri")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> sectors = _service.RetrieveMultiple(sectorQueryExpression).Entities;
                foreach (Entity sector in sectors)
                {
                    // Create sector element
                    anyChildElement = CreateSectorIndividualElement(xmlDocument, iatiActivityElement, sector) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/sector element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="sector"></param>
        private bool CreateSectorIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity sector)
        {
            try
            {
                // Create sector element
                XmlElement sectorElement = xmlDocument.CreateElement("sector");

                // Create vocabulary attribute
                string sectorVocabularyCode = sector.GetAliasedValue<string>("SectorVocabulary.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(sectorVocabularyCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, sectorElement, "vocabulary", sectorVocabularyCode);

                // Create vocabulary-uri attribute
                if (sectorVocabularyCode == "98" || sectorVocabularyCode == "99")
                {
                    string sectorVocabularyUri = sector.GetAliasedValue<string>("SectorVocabulary.msiati_uri");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, sectorElement, "vocabulary-uri", sectorVocabularyUri);
                }

                // Create code attribute
                string sectorCode = sector.GetAliasedValue<string>("SectorCode.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(sectorCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, sectorElement, "code", sectorCode);

                // Create percentage attribute
                decimal? percentage = sector.GetAttributeValue<decimal?>("msiati_percentage");
                anyChildElement = percentage != null || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, sectorElement, "percentage", percentage, Constants.DecimalFormatTwoDecimalDigits);

                // Create narrative elements
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, sectorElement, sector, "msiati_name", false, sector.Id, NarrativeTranslationEntity.Sector,
                        NarrativeTranslationAttribute.Name, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(sectorElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region tag

        /// <summary>
        /// Create iati-activities/iati-activity/tag elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateTagElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var tagQueryExpression = new QueryExpression("msiati_tag")
                {
                    ColumnSet = new ColumnSet("msiati_name"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Tag Code
                        new LinkEntity(
                            "msiati_tag",
                            "msiati_nonembeddedcodelist",
                            "msiati_codeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "TagCode",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Tag Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "TagVocabulary",
                                    Columns = new ColumnSet("msiati_code", "msiati_uri")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> tags = _service.RetrieveMultiple(tagQueryExpression).Entities;
                foreach (Entity tag in tags)
                {
                    // Create tag element
                    anyChildElement = CreateTagIndividualElement(xmlDocument, iatiActivityElement, tag) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/tag element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="tag"></param>
        private bool CreateTagIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity tag)
        {
            try
            {
                // Create tag element
                XmlElement tagElement = xmlDocument.CreateElement("tag");

                // Create code attribute
                string tagCode = tag.GetAliasedValue<string>("TagCode.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(tagCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, tagElement, "code", tagCode);

                // Create vocabulary attribute
                string tagVocabularyCode = tag.GetAliasedValue<string>("TagVocabulary.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(tagVocabularyCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, tagElement, "vocabulary", tagVocabularyCode);

                // Create vocabulary-uri attribute
                if (tagVocabularyCode == "99")
                {
                    string tagVocabularyUri = tag.GetAliasedValue<string>("TagVocabulary.msiati_uri");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, tagElement, "vocabulary-uri", tagVocabularyUri);
                }

                // Create narrative elements
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, tagElement, tag, "msiati_name", false, tag.Id, NarrativeTranslationEntity.Tag,
                        NarrativeTranslationAttribute.Name, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(tagElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region country-budget-items

        /// <summary>
        /// Create iati-activities/iati-activity/country-budget-items element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <param name="deliveryFrameworkId"></param>
        /// <returns></returns>
        private bool CreateCountryBudgetItemsElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var budgetQueryExpression = new QueryExpression("msnfp_budget")
                {
                    ColumnSet = new ColumnSet("msiati_percentage", "msnfp_description"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msnfp_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId),
                            new ConditionExpression("msiati_budgettype", ConditionOperator.Equal, (int) OrganizationBudgetType.RecipientCountryBudget)
                        }
                    },
                    LinkEntities =
                    {
                        // Budget Identifier
                        new LinkEntity(
                            "msnfp_budget",
                            "msiati_nonembeddedcodelist",
                            "msiati_budgetidentifierid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "BudgetIdentifier",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                DataCollection<Entity> budgets = _service.RetrieveMultiple(budgetQueryExpression).Entities;

                // Create country-budget-items element
                XmlElement countryBudgetItemsElement = xmlDocument.CreateElement("country-budget-items");

                // Create vocabulary attribute
                string vocabularyCode = deliveryFramework.GetAliasedValue<string>("BudgetIdentifierVocabulary.msiati_code");
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, countryBudgetItemsElement, "vocabulary", vocabularyCode);

                bool anyChildElement = false;
                foreach (Entity budget in budgets)
                {
                    // Create budget-item elements
                    anyChildElement = CreateCountryBudgetItemsBudgetItemIndividualElement(xmlDocument, countryBudgetItemsElement, budget) || anyChildElement;
                }

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(countryBudgetItemsElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/country-budget-items/budget-item element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="countryBudgetItemsElement"></param>
        /// <param name="budget"></param>
        private bool CreateCountryBudgetItemsBudgetItemIndividualElement(XmlDocument xmlDocument, XmlElement countryBudgetItemsElement, Entity budget)
        {
            try
            {
                // Create budget-item element
                XmlElement budgetItemElement = xmlDocument.CreateElement("budget-item");

                // Create code attribute
                string code = budget.GetAliasedValue<string>("BudgetIdentifier.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(code);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, budgetItemElement, "code", code);

                // Create percentage attribute
                decimal? percentage = budget.GetAttributeValue<decimal?>("msiati_percentage");
                anyChildElement = percentage != null || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, budgetItemElement, "percentage", percentage, Constants.DecimalFormatTwoDecimalDigits);

                Guid budgetId = budget.Id;

                // Create description element
                CreateCountryBudgetItemsBudgetItemDescriptionElement(xmlDocument, budgetItemElement, budget, budgetId);

                // If any child element, add parent
                if (anyChildElement)
                {
                    countryBudgetItemsElement.AppendChild(budgetItemElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/country-budget-items/budget-item/description element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="documentLinkElement"></param>
        /// <param name="budget"></param>
        /// <param name="budgetId"></param>
        private void CreateCountryBudgetItemsBudgetItemDescriptionElement(XmlDocument xmlDocument, XmlElement documentLinkElement, Entity budget, Guid budgetId)
        {
            try
            {
                // Create description narrative elements
                CommonUtilities.CreateNarrativeElements(_service, xmlDocument, documentLinkElement, budget, "msnfp_description", false, budgetId, NarrativeTranslationEntity.Budget,
                    NarrativeTranslationAttribute.Description, true, "description");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
            }
        }

        #endregion

        #region humanitarian-scope

        /// <summary>
        /// Create iati-activities/iati-activity/humanitarian-scope elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateHumanitarianScopeElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var humanitarianScopeQueryExpression = new QueryExpression("msiati_humanitarianscope")
                {
                    ColumnSet = new ColumnSet("msiati_name"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId),
                        }
                    },
                    LinkEntities =
                    {
                        // Humanitarian Scope Type
                        new LinkEntity(
                            "msiati_humanitarianscope",
                            "msiati_nonembeddedcodelist",
                            "msiati_typeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "HumanitarianScopeType",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Humanitarian Scope Code
                        new LinkEntity(
                            "msiati_humanitarianscope",
                            "msiati_nonembeddedcodelist",
                            "msiati_codeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "HumanitarianScopeCode",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Humanitarian Scope Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "HumanitarianScopeVocabulary",
                                    Columns = new ColumnSet("msiati_code", "msiati_uri")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> humanitarianScopes = _service.RetrieveMultiple(humanitarianScopeQueryExpression).Entities;
                foreach (Entity humanitarianScope in humanitarianScopes)
                {
                    // Create humanitarian-scope element
                    anyChildElement = CreateHumanitarianScopeIndividualElement(xmlDocument, iatiActivityElement, humanitarianScope) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/humanitarian-scope element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="humanitarianScope"></param>
        private bool CreateHumanitarianScopeIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity humanitarianScope)
        {
            try
            {
                // Create humanitarian-scope element
                XmlElement humanitarianScopeElement = xmlDocument.CreateElement("humanitarian-scope");

                // Create type attribute
                string typeCode = humanitarianScope.GetAliasedValue<string>("HumanitarianScopeType.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(typeCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, humanitarianScopeElement, "type", typeCode);

                // Create vocabulary attribute
                string humanitarianScopeVocabularyCode = humanitarianScope.GetAliasedValue<string>("HumanitarianScopeVocabulary.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(humanitarianScopeVocabularyCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, humanitarianScopeElement, "vocabulary", humanitarianScopeVocabularyCode);

                // Create vocabulary-uri attribute
                if (humanitarianScopeVocabularyCode == "99")
                {
                    string humanitarianScopeVocabularyUri = humanitarianScope.GetAliasedValue<string>("HumanitarianScopeVocabulary.msiati_uri");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, humanitarianScopeElement, "vocabulary-uri", humanitarianScopeVocabularyUri);
                }

                // Create code attribute
                string humanitarianScopeCode = humanitarianScope.GetAliasedValue<string>("HumanitarianScopeCode.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(humanitarianScopeCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, humanitarianScopeElement, "code", humanitarianScopeCode);

                // Create narrative elements
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, humanitarianScopeElement, humanitarianScope, "msiati_name", false, humanitarianScope.Id,
                        NarrativeTranslationEntity.HumanitarianScope, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(humanitarianScopeElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region policy-marker

        /// <summary>
        /// Create iati-activities/iati-activity/policy-marker elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreatePolicyMarkerElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var policyMarkerQueryExpression = new QueryExpression("msiati_policymarker")
                {
                    ColumnSet = new ColumnSet("msiati_name"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Policy Marker Code
                        new LinkEntity(
                            "msiati_policymarker",
                            "msiati_nonembeddedcodelist",
                            "msiati_codeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "PolicyMarkerCode",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Policy Marker Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "PolicyMarkerVocabulary",
                                    Columns = new ColumnSet("msiati_code", "msiati_uri")
                                }
                            }
                        },
                        // Policy Marker Code
                        new LinkEntity(
                            "msiati_policymarker",
                            "msiati_nonembeddedcodelist",
                            "msiati_significanceid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "PolicySignificance",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> policyMarkers = _service.RetrieveMultiple(policyMarkerQueryExpression).Entities;
                foreach (Entity policyMarker in policyMarkers)
                {
                    // Create policy-marker element
                    anyChildElement = CreatePolicyMarkerIndividualElement(xmlDocument, iatiActivityElement, policyMarker) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/policy-marker element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="policyMarker"></param>
        private bool CreatePolicyMarkerIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity policyMarker)
        {
            try
            {
                // Create policy-marker element
                XmlElement policyMarkerElement = xmlDocument.CreateElement("policy-marker");

                // Create vocabulary attribute
                string policyMarkerVocabularyCode = policyMarker.GetAliasedValue<string>("PolicyMarkerVocabulary.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(policyMarkerVocabularyCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, policyMarkerElement, "vocabulary", policyMarkerVocabularyCode);

                // Create vocabulary-uri attribute
                if (policyMarkerVocabularyCode == "99")
                {
                    string policyMarkerVocabularyUri = policyMarker.GetAliasedValue<string>("PolicyMarkerVocabulary.msiati_uri");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, policyMarkerElement, "vocabulary-uri", policyMarkerVocabularyUri);
                }

                // Create code attribute
                string policyMarkerCode = policyMarker.GetAliasedValue<string>("PolicyMarkerCode.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(policyMarkerCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, policyMarkerElement, "code", policyMarkerCode);

                // Create significance attribute
                string policySignificanceCode = policyMarker.GetAliasedValue<string>("PolicySignificance.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(policySignificanceCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, policyMarkerElement, "significance", policySignificanceCode);

                // Create narrative elements
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, policyMarkerElement, policyMarker, "msiati_name", false, policyMarker.Id,
                        NarrativeTranslationEntity.PolicyMarker, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(policyMarkerElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region collaboration-type

        /// <summary>
        /// Create iati-activities/iati-activity/collaboration-type element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkAdditionalDetail"></param>
        private bool CreateCollaborationTypeElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFrameworkAdditionalDetail)
        {
            try
            {
                string code = deliveryFrameworkAdditionalDetail?.GetAliasedValue<string>("CollaborationType.msiati_code");
                if (!string.IsNullOrWhiteSpace(code))
                {
                    // Create activity-status element
                    XmlElement collaborationTypeElement = XmlUtilities.CreateChildXmlElement(xmlDocument, iatiActivityElement, "collaboration-type");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, collaborationTypeElement, "code", code);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region default-flow-type

        /// <summary>
        /// Create iati-activities/iati-activity/default-flow-type element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        private bool CreateDefaultFlowTypeElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework)
        {
            try
            {
                string defaultFlowTypeCode = deliveryFramework.GetAliasedValue<string>("DefaultFlowType.msiati_code");
                if (!string.IsNullOrWhiteSpace(defaultFlowTypeCode))
                {
                    // Create default-flow-type element
                    XmlElement defaultFlowTypeElement = XmlUtilities.CreateChildXmlElement(xmlDocument, iatiActivityElement, "default-flow-type");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, defaultFlowTypeElement, "code", defaultFlowTypeCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region default-finance-type

        /// <summary>
        /// Create iati-activities/iati-activity/default-finance-type element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        private bool CreateDefaultFinanceTypeElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework)
        {
            try
            {
                string defaultFinanceTypeCode = deliveryFramework.GetAliasedValue<string>("DefaultFinanceType.msiati_code");
                if (!string.IsNullOrWhiteSpace(defaultFinanceTypeCode))
                {
                    // Create default-finance-type element
                    XmlElement defaultFinanceTypeElement = XmlUtilities.CreateChildXmlElement(xmlDocument, iatiActivityElement, "default-finance-type");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, defaultFinanceTypeElement, "code", defaultFinanceTypeCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region default-aid-type

        /// <summary>
        /// Create iati-activities/iati-activity/default-aid-type elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateDefaultAidTypeElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var aidTypeQueryExpression = new QueryExpression("msiati_aidtype")
                {
                    ColumnSet = new ColumnSet(),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Aid Type Code
                        new LinkEntity(
                            "msiati_aidtype",
                            "msiati_nonembeddedcodelist",
                            "msiati_typeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "AidTypeCode",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Sector Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "AidTypeVocabulary",
                                    Columns = new ColumnSet("msiati_code", "msiati_uri")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> aidTypes = _service.RetrieveMultiple(aidTypeQueryExpression).Entities;
                foreach (Entity aidType in aidTypes)
                {
                    // Create default-aid-type element
                    anyChildElement = CreateDefaultAidTypeIndividualElement(xmlDocument, iatiActivityElement, aidType) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/default-aid-type element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="aidType"></param>
        private bool CreateDefaultAidTypeIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity aidType)
        {
            try
            {
                // Create default-aid-type element
                XmlElement defaultAidTypeElement = xmlDocument.CreateElement("default-aid-type");

                // Create code attribute
                string code = aidType.GetAliasedValue<string>("AidTypeCode.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(code);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, defaultAidTypeElement, "code", code);

                // Create vocabulary attribute
                string vocabularyCode = aidType.GetAliasedValue<string>("AidTypeVocabulary.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(vocabularyCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, defaultAidTypeElement, "vocabulary", vocabularyCode);

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(defaultAidTypeElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region default-tied-status

        /// <summary>
        /// Create iati-activities/iati-activity/default-tied-status element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        private bool CreateDefaultTiedStatusElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework)
        {
            try
            {
                string defaultTiedStatusCode = deliveryFramework.GetAliasedValue<string>("DefaultTiedStatus.msiati_code");
                if (!string.IsNullOrWhiteSpace(defaultTiedStatusCode))
                {
                    // Create default-finance-type element
                    XmlElement defaultTiedStatusElement = XmlUtilities.CreateChildXmlElement(xmlDocument, iatiActivityElement, "default-tied-status");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, defaultTiedStatusElement, "code", defaultTiedStatusCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region budget

        /// <summary>
        /// Create iati-activities/iati-activity/budget elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateBudgetElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId, string defaultCurrencyCode)
        {
            try
            {
                // Build query to fetch data
                var budgetQueryExpression = new QueryExpression("msnfp_budget")
                {
                    ColumnSet =
                        new ColumnSet("msnfp_description", "msiati_type", "msiati_budgetstatus", "msnfp_startdate", "msnfp_enddate", "msnfp_totalbudget", "msiati_currencyvaluedate"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msnfp_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId),
                            new ConditionExpression("msiati_budgettype", ConditionOperator.Equal, (int) OrganizationBudgetType.Total)
                        }
                    },
                    LinkEntities =
                    {
                        // Currency
                        new LinkEntity(
                            "msnfp_budget",
                            "transactioncurrency",
                            "transactioncurrencyid",
                            "transactioncurrencyid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "Currency",
                            Columns = new ColumnSet("isocurrencycode")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> budgets = _service.RetrieveMultiple(budgetQueryExpression).Entities;
                foreach (Entity budget in budgets)
                {
                    // Create budget element
                    anyChildElement = CreateBudgetIndividualElement(xmlDocument, iatiActivityElement, budget, defaultCurrencyCode) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/budget element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="budget"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateBudgetIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity budget, string defaultCurrencyCode)
        {
            try
            {
                // Create budget element
                XmlElement budgetElement = xmlDocument.CreateElement("budget");

                bool anyChildElement = false;
                // Create type attribute
                int? typeId = budget.GetOptionSetValue("msiati_type");
                if (typeId != null)
                {
                    string typeCode = CommonUtilities.GetCodelistCodeByOptionSetId(Constants.BudgetTypeIdCodeMapping, (BudgetType)typeId.Value);
                    anyChildElement = !string.IsNullOrWhiteSpace(typeCode);
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, budgetElement, "type", typeCode);
                }

                // Create status attribute
                int? statusId = budget.GetOptionSetValue("msiati_budgetstatus");
                if (statusId != null)
                {
                    string statusCode = CommonUtilities.GetCodelistCodeByOptionSetId(Constants.BudgetStatusIdCodeMapping, (BudgetStatus)statusId.Value);
                    anyChildElement = !string.IsNullOrWhiteSpace(statusCode) || anyChildElement;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, budgetElement, "status", statusCode);
                }

                // Create period-start element
                anyChildElement = CreateBudgetPeriodStartElement(xmlDocument, budgetElement, budget) || anyChildElement;

                // Create period-end element
                anyChildElement = CreateBudgetPeriodEndElement(xmlDocument, budgetElement, budget) || anyChildElement;

                // Create value element
                anyChildElement = CreateBudgetValueElement(xmlDocument, budgetElement, budget, defaultCurrencyCode) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(budgetElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/budget/period-start element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetElement"></param>
        /// <param name="budget"></param>
        private bool CreateBudgetPeriodStartElement(XmlDocument xmlDocument, XmlElement budgetElement, Entity budget)
        {
            try
            {
                DateTime? periodStart = budget.GetAttributeValue<DateTime?>("msnfp_startdate");
                if (periodStart != null)
                {
                    // Create period-start element
                    XmlElement periodStartElement = XmlUtilities.CreateChildXmlElement(xmlDocument, budgetElement, "period-start");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, periodStartElement, "iso-date", periodStart, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/budget/period-end element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetElement"></param>
        /// <param name="budget"></param>
        private bool CreateBudgetPeriodEndElement(XmlDocument xmlDocument, XmlElement budgetElement, Entity budget)
        {
            try
            {
                DateTime? periodEnd = budget.GetAttributeValue<DateTime?>("msnfp_enddate");
                if (periodEnd != null)
                {
                    // Create period-end element
                    XmlElement periodStartElement = XmlUtilities.CreateChildXmlElement(xmlDocument, budgetElement, "period-end");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, periodStartElement, "iso-date", periodEnd, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/budget/value element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="budgetElement"></param>
        /// <param name="budget"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateBudgetValueElement(XmlDocument xmlDocument, XmlElement budgetElement, Entity budget, string defaultCurrencyCode)
        {
            try
            {
                Money value = budget.GetAttributeValue<Money>("msnfp_totalbudget");
                if (value != null)
                {
                    // Create value element
                    XmlElement valueElement = XmlUtilities.CreateChildXmlElement(xmlDocument, budgetElement, "value");

                    // Create currency attribute (if different from default currency)
                    CommonUtilities.CreateCurrencyAttribute(xmlDocument, valueElement, budget, "Currency.isocurrencycode", true, defaultCurrencyCode);

                    // Create value-date attribute
                    DateTime? valueDate = budget.GetAttributeValue<DateTime?>("msiati_currencyvaluedate");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, valueElement, "value-date", valueDate, Constants.DateFormatDateOnly);

                    // Set value inner text
                    valueElement.InnerText = value.Value.ToString(Constants.DecimalFormatTwoDecimalDigits);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region planned-disbursement

        /// <summary>
        /// Create iati-activities/iati-activity/planned-disbursement elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreatePlannedDisbursementElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId, string defaultCurrencyCode)
        {
            try
            {
                // Build query to fetch data
                var plannedDisbursementQueryExpression = new QueryExpression("msnfp_budget")
                {
                    ColumnSet =
                        new ColumnSet("msnfp_description", "msiati_type", "msnfp_startdate", "msnfp_enddate", "msnfp_totalbudget", "msiati_currencyvaluedate",
                            "msiati_provideractivityidentifier", "msiati_recipientactivityidentifier"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msnfp_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId),
                            new ConditionExpression("msiati_budgettype", ConditionOperator.Equal, (int) OrganizationBudgetType.PlannedDisbursement)
                        }
                    },
                    LinkEntities =
                    {
                        // Currency
                        new LinkEntity(
                            "msnfp_budget",
                            "transactioncurrency",
                            "transactioncurrencyid",
                            "transactioncurrencyid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "Currency",
                            Columns = new ColumnSet("isocurrencycode")
                        },
                        // Provider Organization
                        new LinkEntity(
                            "msnfp_budget",
                            "account",
                            "msiati_providerorganizationid",
                            "accountid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "ProviderOrganization",
                            Columns = new ColumnSet("accountid", "name", "msiati_iatiorganizationidentifier"),
                            LinkEntities =
                            {
                                // Provider Organization Type
                                new LinkEntity(
                                    "account",
                                    "msiati_nonembeddedcodelist",
                                    "msiati_organizationtypeid",
                                    "msiati_nonembeddedcodelistid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "ProviderOrganizationType",
                                    Columns = new ColumnSet("msiati_code")
                                }
                            }
                        },
                        // Recipient Organization
                        new LinkEntity(
                            "msnfp_budget",
                            "account",
                            "msiati_recipientorganizationid",
                            "accountid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "RecipientOrganization",
                            Columns = new ColumnSet("accountid", "name", "msiati_iatiorganizationidentifier"),
                            LinkEntities =
                            {
                                // Recipient Organization Type
                                new LinkEntity(
                                    "account",
                                    "msiati_nonembeddedcodelist",
                                    "msiati_organizationtypeid",
                                    "msiati_nonembeddedcodelistid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "RecipientOrganizationType",
                                    Columns = new ColumnSet("msiati_code")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> plannedDisbursements = _service.RetrieveMultiple(plannedDisbursementQueryExpression).Entities;
                foreach (Entity plannedDisbursement in plannedDisbursements)
                {
                    // Create planned-disbursement element
                    anyChildElement = CreatePlannedDisbursementIndividualElement(xmlDocument, iatiActivityElement, plannedDisbursement, defaultCurrencyCode) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/planned-disbursement element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="plannedDisbursement"></param>
        /// <param name="defaultCurrencyCode"></param>
        /// <returns></returns>
        private bool CreatePlannedDisbursementIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity plannedDisbursement, string defaultCurrencyCode)
        {
            try
            {
                // Create planned-disbursement element
                XmlElement plannedDisbursementElement = xmlDocument.CreateElement("planned-disbursement");

                bool anyChildElement = false;

                // Create type attribute
                int? typeId = plannedDisbursement.GetOptionSetValue("msiati_type");
                if (typeId != null)
                {
                    string typeCode = CommonUtilities.GetCodelistCodeByOptionSetId(Constants.BudgetTypeIdCodeMapping, (BudgetType)typeId.Value);
                    anyChildElement = !string.IsNullOrWhiteSpace(typeCode);
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, plannedDisbursementElement, "type", typeCode);
                }

                // Create period-start element
                anyChildElement = CreatePlannedDisbursementPeriodStartElement(xmlDocument, plannedDisbursementElement, plannedDisbursement) || anyChildElement;

                // Create period-end element
                anyChildElement = CreatePlannedDisbursementPeriodEndElement(xmlDocument, plannedDisbursementElement, plannedDisbursement) || anyChildElement;

                // Create value element
                anyChildElement = CreatePlannedDisbursementValueElement(xmlDocument, plannedDisbursementElement, plannedDisbursement, defaultCurrencyCode) || anyChildElement;

                // Create provider-org element
                anyChildElement = CreatePlannedDisbursementProviderOrgElement(xmlDocument, plannedDisbursementElement, plannedDisbursement) || anyChildElement;

                // Create receiver-org element
                anyChildElement = CreatePlannedDisbursementReceiverOrgElement(xmlDocument, plannedDisbursementElement, plannedDisbursement) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(plannedDisbursementElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/planned-disbursement/period-start element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="plannedDisbursementElement"></param>
        /// <param name="plannedDisbursement"></param>
        private bool CreatePlannedDisbursementPeriodStartElement(XmlDocument xmlDocument, XmlElement plannedDisbursementElement, Entity plannedDisbursement)
        {
            try
            {
                DateTime? periodStart = plannedDisbursement.GetAttributeValue<DateTime?>("msnfp_startdate");
                if (periodStart != null)
                {
                    // Create period-start element
                    XmlElement periodStartElement = XmlUtilities.CreateChildXmlElement(xmlDocument, plannedDisbursementElement, "period-start");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, periodStartElement, "iso-date", periodStart, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/planned-disbursement/period-end element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="plannedDisbursementElement"></param>
        /// <param name="plannedDisbursement"></param>
        private bool CreatePlannedDisbursementPeriodEndElement(XmlDocument xmlDocument, XmlElement plannedDisbursementElement, Entity plannedDisbursement)
        {
            try
            {
                DateTime? periodEnd = plannedDisbursement.GetAttributeValue<DateTime?>("msnfp_enddate");
                if (periodEnd != null)
                {
                    // Create period-end element
                    XmlElement periodStartElement = XmlUtilities.CreateChildXmlElement(xmlDocument, plannedDisbursementElement, "period-end");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, periodStartElement, "iso-date", periodEnd, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/planned-disbursement/value element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="plannedDisbursementElement"></param>
        /// <param name="plannedDisbursement"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreatePlannedDisbursementValueElement(XmlDocument xmlDocument, XmlElement plannedDisbursementElement, Entity plannedDisbursement, string defaultCurrencyCode)
        {
            try
            {
                Money value = plannedDisbursement.GetAttributeValue<Money>("msnfp_totalbudget");
                if (value != null)
                {
                    // Create value element
                    XmlElement valueElement = XmlUtilities.CreateChildXmlElement(xmlDocument, plannedDisbursementElement, "value");

                    // Create currency attribute (if different from default currency)
                    CommonUtilities.CreateCurrencyAttribute(xmlDocument, valueElement, plannedDisbursement, "Currency.isocurrencycode", true, defaultCurrencyCode);

                    // Create value-date attribute
                    DateTime? valueDate = plannedDisbursement.GetAttributeValue<DateTime?>("msiati_currencyvaluedate");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, valueElement, "value-date", valueDate, Constants.DateFormatDateOnly);

                    // Set value inner text
                    valueElement.InnerText = value.Value.ToString(Constants.DecimalFormatTwoDecimalDigits);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/planned-disbursement/provider-org element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="plannedDisbursementElement"></param>
        /// <param name="plannedDisbursement"></param>
        private bool CreatePlannedDisbursementProviderOrgElement(XmlDocument xmlDocument, XmlElement plannedDisbursementElement, Entity plannedDisbursement)
        {
            try
            {
                bool anyChildElement = false;
                Guid? providerOrganizationAccountId = plannedDisbursement.GetAliasedValue<Guid?>("ProviderOrganization.accountid");
                if (providerOrganizationAccountId != null)
                {
                    // Create provider-org element
                    XmlElement providerOrgElement = xmlDocument.CreateElement("provider-org");

                    // Create ref attribute
                    string @ref = plannedDisbursement.GetAliasedValue<string>("ProviderOrganization.msiati_iatiorganizationidentifier");
                    anyChildElement = !string.IsNullOrWhiteSpace(@ref);
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, providerOrgElement, "ref", @ref);

                    // Create provider-activity-id attribute
                    string providerActivityId = plannedDisbursement.GetAttributeValue<string>("msiati_provideractivityidentifier");
                    anyChildElement = !string.IsNullOrWhiteSpace(providerActivityId) || anyChildElement;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, providerOrgElement, "provider-activity-id", providerActivityId);

                    // Create type attribute
                    string typeCode = plannedDisbursement.GetAliasedValue<string>("ProviderOrganizationType.msiati_code");
                    anyChildElement = !string.IsNullOrWhiteSpace(typeCode) || anyChildElement;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, providerOrgElement, "type", typeCode);

                    // Create narrative elements
                    anyChildElement =
                        CommonUtilities.CreateNarrativeElements(_service, xmlDocument, providerOrgElement, plannedDisbursement, "ProviderOrganization.name", true,
                            providerOrganizationAccountId.Value, NarrativeTranslationEntity.Account, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                    // If any child element, add parent
                    if (anyChildElement)
                    {
                        plannedDisbursementElement.AppendChild(providerOrgElement);
                    }
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/planned-disbursement/receiver-org element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="plannedDisbursementElement"></param>
        /// <param name="plannedDisbursement"></param>
        private bool CreatePlannedDisbursementReceiverOrgElement(XmlDocument xmlDocument, XmlElement plannedDisbursementElement, Entity plannedDisbursement)
        {
            try
            {
                bool anyChildElement = false;
                Guid? recipientOrganizationAccountId = plannedDisbursement.GetAliasedValue<Guid?>("RecipientOrganization.accountid");
                if (recipientOrganizationAccountId != null)
                {
                    // Create receiver-org element
                    XmlElement receiverOrgElement = xmlDocument.CreateElement("receiver-org");

                    // Create ref attribute
                    string @ref = plannedDisbursement.GetAliasedValue<string>("RecipientOrganization.msiati_iatiorganizationidentifier");
                    anyChildElement = !string.IsNullOrWhiteSpace(@ref);
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, receiverOrgElement, "ref", @ref);

                    // Create receiver-activity-id attribute
                    string receiverActivityId = plannedDisbursement.GetAttributeValue<string>("msiati_recipientactivityidentifier");
                    anyChildElement = !string.IsNullOrWhiteSpace(receiverActivityId) || anyChildElement;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, receiverOrgElement, "receiver-activity-id", receiverActivityId);

                    // Create type attribute
                    string typeCode = plannedDisbursement.GetAliasedValue<string>("RecipientOrganizationType.msiati_code");
                    anyChildElement = !string.IsNullOrWhiteSpace(typeCode) || anyChildElement;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, receiverOrgElement, "type", typeCode);

                    // Create narrative elements
                    anyChildElement =
                        CommonUtilities.CreateNarrativeElements(_service, xmlDocument, receiverOrgElement, plannedDisbursement, "RecipientOrganization.name", true,
                            recipientOrganizationAccountId.Value, NarrativeTranslationEntity.Account, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                    // If any child element, add parent
                    if (anyChildElement)
                    {
                        plannedDisbursementElement.AppendChild(receiverOrgElement);
                    }
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region capital-spend

        /// <summary>
        /// Create iati-activities/iati-activity/capital-spend element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        private bool CreateCapitalSpendElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework)
        {
            try
            {
                decimal? percentage = deliveryFramework.GetAttributeValue<decimal?>("msiati_capitalspend");
                if (percentage != null)
                {
                    // Create capital-spend element
                    XmlElement capitalSpendElement = XmlUtilities.CreateChildXmlElement(xmlDocument, iatiActivityElement, "capital-spend");

                    // Create percentage attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, capitalSpendElement, "percentage", percentage, Constants.DecimalFormatTwoDecimalDigits);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region transaction

        /// <summary>
        /// Create iati-activities/iati-activity/transaction elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        /// <param name="defaultCurrencyCode"></param>
        /// <returns></returns>
        private bool CreateTransactionElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId, string defaultCurrencyCode)
        {
            try
            {
                bool anyChildElement = false;
                List<Transaction> transactions = new List<Transaction>();
                transactions.AddRange(GetTransactionsFromExpenditureEntity(deliveryFrameworkId));
                transactions.AddRange(GetTransactionsFromDisbursementEntity(deliveryFrameworkId));
                transactions.AddRange(GetTransactionsFromDonorCommitmentEntity(deliveryFrameworkId));
                transactions.AddRange(GetTransactionsFromTransactionEntity(deliveryFrameworkId));

                List<Guid> alreadyReportedTransactions = new List<Guid>();

                foreach (Transaction transaction in transactions.OrderBy(t => t.TransactionTypeCode).ThenBy(t => t.Date))
                {
                    if (alreadyReportedTransactions.Contains(transaction.Id))
                    {
                        continue;
                    }

                    alreadyReportedTransactions.Add(transaction.Id);

                    // Create transaction element
                    anyChildElement = CreateTransactionIndividualElement(xmlDocument, iatiActivityElement, transaction, defaultCurrencyCode) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/transaction element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="transaction"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateTransactionIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Transaction transaction, string defaultCurrencyCode)
        {
            try
            {
                // Create transaction element
                XmlElement transactionElement = xmlDocument.CreateElement("transaction");

                // Create ref attribute (need to create fields in CDM)
                string @ref = transaction.Reference;
                bool anyChildElement = !string.IsNullOrWhiteSpace(@ref);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, transactionElement, "ref", @ref);

                // Create humanitarian attribute
                string humanitarian = transaction.Humanitarian == true ? "1" : "0";
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, transactionElement, "humanitarian", humanitarian);

                // Create transaction-type element
                anyChildElement = CreateTransactionTransactionTypeElement(xmlDocument, transactionElement, transaction) || anyChildElement;

                // Create transaction-date element
                anyChildElement = CreateTransactionTransactionDateElement(xmlDocument, transactionElement, transaction) || anyChildElement;

                // Create value element
                anyChildElement = CreateTransactionValueElement(xmlDocument, transactionElement, transaction, defaultCurrencyCode) || anyChildElement;

                // Create description element
                anyChildElement = CreateTransactionDescriptionElement(xmlDocument, transactionElement, transaction) || anyChildElement;

                // Create provider-org element
                anyChildElement = CreateTransactionProviderOrgElement(xmlDocument, transactionElement, transaction) || anyChildElement;

                // Create receiver-org element
                anyChildElement = CreateTransactionReceiverOrgElement(xmlDocument, transactionElement, transaction) || anyChildElement;

                // Create disbursement-channel element
                anyChildElement = CreateTransactionDisbursementChannelElement(xmlDocument, transactionElement, transaction) || anyChildElement;

                // Create sector elements
                anyChildElement = CreateTransactionSectorElements(xmlDocument, transactionElement, transaction) || anyChildElement;

                // Create recipient-country element
                anyChildElement = CreateTransactionRecipientCountryElement(xmlDocument, transactionElement, transaction) || anyChildElement;

                // Create recipient-region element
                anyChildElement = CreateTransactionRecipientRegionElement(xmlDocument, transactionElement, transaction) || anyChildElement;

                // Create flow-type element
                anyChildElement = CreateTransactionFlowTypeElement(xmlDocument, transactionElement, transaction) || anyChildElement;

                // Create finance-type element
                anyChildElement = CreateTransactionFinanceTypeElement(xmlDocument, transactionElement, transaction) || anyChildElement;

                // Create aid-type elements
                anyChildElement = CreateTransactionAidTypeElements(xmlDocument, transactionElement, transaction) || anyChildElement;

                // Create tied-status element
                anyChildElement = CreateTransactionTiedStatusElement(xmlDocument, transactionElement, transaction) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(transactionElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/transaction-type element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        private bool CreateTransactionTransactionTypeElement(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(transaction.TransactionTypeCode))
                {
                    // Create transaction-type element
                    XmlElement transactionTypeElement = XmlUtilities.CreateChildXmlElement(xmlDocument, transactionElement, "transaction-type");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, transactionTypeElement, "code", transaction.TransactionTypeCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/transaction-date element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        private bool CreateTransactionTransactionDateElement(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction)
        {
            try
            {
                if (transaction.Date != null)
                {
                    // Create transaction-date element
                    XmlElement transactionDateElement = XmlUtilities.CreateChildXmlElement(xmlDocument, transactionElement, "transaction-date");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, transactionDateElement, "iso-date", transaction.Date, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/value element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateTransactionValueElement(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction, string defaultCurrencyCode)
        {
            try
            {
                Money value = transaction.Amount;
                if (value != null)
                {
                    // Create value element
                    XmlElement valueElement = XmlUtilities.CreateChildXmlElement(xmlDocument, transactionElement, "value");

                    // Create currency attribute (if different from default currency)
                    CommonUtilities.CreateCurrencyAttribute(xmlDocument, valueElement, transaction.CurrencyCode, defaultCurrencyCode);

                    // Create value-date attribute
                    DateTime? valueDate = transaction.CurrencyValueDate;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, valueElement, "value-date", valueDate, Constants.DateFormatDateOnly);

                    // Set value inner text
                    valueElement.InnerText = value.Value.ToString(Constants.DecimalFormatTwoDecimalDigits);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/description element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        private bool CreateTransactionDescriptionElement(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction)
        {
            try
            {
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, transactionElement, transaction.Description, transaction.Id,
                    NarrativeTranslationEntity.Expenditure, NarrativeTranslationAttribute.Description, true, "description");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/provider-org element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        private bool CreateTransactionProviderOrgElement(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction)
        {
            try
            {
                bool anyChildElement = false;
                if (transaction.ProviderOrganizationId != null)
                {
                    // Create provider-org element
                    XmlElement providerOrgElement = xmlDocument.CreateElement("provider-org");

                    // Create ref attribute
                    string @ref = transaction.ProviderOrganizationIatiIdentifier;
                    anyChildElement = !string.IsNullOrWhiteSpace(@ref);
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, providerOrgElement, "ref", @ref);

                    // Create provider-activity-id attribute
                    string providerActivityId = transaction.ProviderActivityIdentifier;
                    anyChildElement = !string.IsNullOrWhiteSpace(providerActivityId) || anyChildElement;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, providerOrgElement, "provider-activity-id", providerActivityId);

                    // Create type attribute
                    string typeCode = transaction.ProviderOrganizationTypeCode;
                    anyChildElement = !string.IsNullOrWhiteSpace(typeCode) || anyChildElement;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, providerOrgElement, "type", typeCode);

                    // Create narrative elements
                    anyChildElement =
                        CommonUtilities.CreateNarrativeElements(_service, xmlDocument, providerOrgElement, transaction.ProviderOrganizationName,
                            transaction.ProviderOrganizationId.Value, NarrativeTranslationEntity.Account, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                    // If any child element, add parent
                    if (anyChildElement)
                    {
                        transactionElement.AppendChild(providerOrgElement);
                    }
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/receiver-org element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        private bool CreateTransactionReceiverOrgElement(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction)
        {
            try
            {
                bool anyChildElement = false;
                if (transaction.RecipientOrganizationId != null)
                {
                    // Create receiver-org element
                    XmlElement receiverOrgElement = xmlDocument.CreateElement("receiver-org");

                    // Create ref attribute
                    string @ref = transaction.RecipientOrganizationIatiIdentifier;
                    anyChildElement = !string.IsNullOrWhiteSpace(@ref);
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, receiverOrgElement, "ref", @ref);

                    // Create receiver-activity-id attribute
                    string receiverActivityId = transaction.RecipientActivityIdentifier;
                    anyChildElement = !string.IsNullOrWhiteSpace(receiverActivityId) || anyChildElement;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, receiverOrgElement, "receiver-activity-id", receiverActivityId);

                    // Create type attribute
                    string typeCode = transaction.RecipientOrganizationTypeCode;
                    anyChildElement = !string.IsNullOrWhiteSpace(typeCode) || anyChildElement;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, receiverOrgElement, "type", typeCode);

                    // Create narrative elements
                    anyChildElement =
                        CommonUtilities.CreateNarrativeElements(_service, xmlDocument, receiverOrgElement, transaction.RecipientOrganizationName,
                            transaction.RecipientOrganizationId.Value, NarrativeTranslationEntity.Account, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                    // If any child element, add parent
                    if (anyChildElement)
                    {
                        transactionElement.AppendChild(receiverOrgElement);
                    }
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/disbursement-channel element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        private bool CreateTransactionDisbursementChannelElement(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction)
        {
            try
            {
                string code = transaction.DisbursementChannelCode;
                if (!string.IsNullOrWhiteSpace(code))
                {
                    // Create disbursement-channel element
                    XmlElement disbursementChannelElement = XmlUtilities.CreateChildXmlElement(xmlDocument, transactionElement, "disbursement-channel");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, disbursementChannelElement, "code", code);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/sector elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        private bool CreateTransactionSectorElements(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction)
        {
            try
            {
                // Build query to fetch data
                var sectorQueryExpression = new QueryExpression("msiati_sector")
                {
                    ColumnSet = new ColumnSet("msiati_name", "msiati_percentage"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression(Constants.SectorTransactionLookupMapping[transaction.TransactionEntity], ConditionOperator.Equal, transaction.Id)
                        }
                    },
                    LinkEntities =
                    {
                        // Sector Code
                        new LinkEntity(
                            "msiati_sector",
                            "msiati_nonembeddedcodelist",
                            "msiati_codeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "SectorCode",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Sector Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "SectorVocabulary",
                                    Columns = new ColumnSet("msiati_code", "msiati_uri")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> sectors = _service.RetrieveMultiple(sectorQueryExpression).Entities;
                foreach (Entity sector in sectors)
                {
                    // Create sector element
                    anyChildElement = CreateTransactionSectorIndividualElement(xmlDocument, transactionElement, sector) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/transaction/sector element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="sector"></param>
        /// <returns></returns>
        private bool CreateTransactionSectorIndividualElement(XmlDocument xmlDocument, XmlElement transactionElement, Entity sector)
        {
            try
            {
                // Create sector element
                XmlElement sectorElement = xmlDocument.CreateElement("sector");

                // Create vocabulary attribute
                string vocabularyCode = sector.GetAliasedValue<string>("SectorVocabulary.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(vocabularyCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, sectorElement, "vocabulary", vocabularyCode);

                // Create vocabulary-uri attribute
                if (vocabularyCode == "98" || vocabularyCode == "99")
                {
                    string vocabularyUri = sector.GetAliasedValue<string>("SectorVocabulary.msiati_uri");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, sectorElement, "vocabulary-uri", vocabularyUri);
                }

                // Create code attribute
                string code = sector.GetAliasedValue<string>("SectorCode.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(code) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, sectorElement, "code", code);

                // Create narrative elements
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, sectorElement, sector, "msiati_name", false, sector.Id, NarrativeTranslationEntity.Sector,
                        NarrativeTranslationAttribute.Name, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    transactionElement.AppendChild(sectorElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/recipient-country element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        private bool CreateTransactionRecipientCountryElement(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction)
        {
            try
            {
                // Create recipient-country element
                XmlElement recipientCountryElement = xmlDocument.CreateElement("recipient-country");

                // Create code attribute
                string code = transaction.RecipientCountryCode;
                bool anyChildElement = !string.IsNullOrWhiteSpace(code);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientCountryElement, "code", code);

                // Create narrative elements
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, recipientCountryElement, transaction.RecipientCountryDescription, transaction.Id,
                        Constants.TransactionEntityNarrativeTranslationEntityMapping[transaction.TransactionEntity], NarrativeTranslationAttribute.RecipientCountryDescription,
                        false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    transactionElement.AppendChild(recipientCountryElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/recipient-region element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        private bool CreateTransactionRecipientRegionElement(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction)
        {
            try
            {
                // Create recipient-region element
                XmlElement recipientRegionElement = xmlDocument.CreateElement("recipient-region");

                // Create code attribute
                string code = transaction.RecipientRegionCode;
                bool anyChildElement = !string.IsNullOrWhiteSpace(code);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientRegionElement, "code", code);

                // Create vocabulary attribute
                string vocabularyCode = transaction.RecipientRegionVocabularyCode;
                anyChildElement = !string.IsNullOrWhiteSpace(vocabularyCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientRegionElement, "vocabulary", vocabularyCode);

                // If reporting organization vocabulary, include vocabulary-uri
                if (vocabularyCode == "99")
                {
                    // Create vocabulary-uri attribute
                    string vocabularyUri = transaction.RecipientRegionVocabularyUri;
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientRegionElement, "vocabulary-uri", vocabularyUri);
                }

                // Create narrative elements
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, recipientRegionElement, transaction.RecipientRegionDescription, transaction.Id,
                        Constants.TransactionEntityNarrativeTranslationEntityMapping[transaction.TransactionEntity], NarrativeTranslationAttribute.RecipientRegionDescription, false) ||
                    anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    transactionElement.AppendChild(recipientRegionElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/flow-type element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        private bool CreateTransactionFlowTypeElement(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction)
        {
            try
            {
                string code = transaction.FlowTypeCode;
                if (!string.IsNullOrWhiteSpace(code))
                {
                    // Create flow-type element
                    XmlElement flowTypeElement = XmlUtilities.CreateChildXmlElement(xmlDocument, transactionElement, "flow-type");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, flowTypeElement, "code", code);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/finance-type element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        private bool CreateTransactionFinanceTypeElement(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction)
        {
            try
            {
                string code = transaction.FinanceTypeCode;
                if (!string.IsNullOrWhiteSpace(code))
                {
                    // Create finance-type element
                    XmlElement financeTypeElement = XmlUtilities.CreateChildXmlElement(xmlDocument, transactionElement, "finance-type");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, financeTypeElement, "code", code);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/aid-type elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        private bool CreateTransactionAidTypeElements(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction)
        {
            try
            {
                // Build query to fetch data
                var aidTypeQueryExpression = new QueryExpression("msiati_aidtype")
                {
                    ColumnSet = new ColumnSet(),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression(Constants.AidTypeTransactionLookupMapping[transaction.TransactionEntity], ConditionOperator.Equal, transaction.Id)
                        }
                    },
                    LinkEntities =
                    {
                        // Aid Type Code
                        new LinkEntity(
                            "msiati_aidtype",
                            "msiati_nonembeddedcodelist",
                            "msiati_typeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "AidTypeCode",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Sector Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "AidTypeVocabulary",
                                    Columns = new ColumnSet("msiati_code", "msiati_uri")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> aidTypes = _service.RetrieveMultiple(aidTypeQueryExpression).Entities;
                foreach (Entity aidType in aidTypes)
                {
                    // Create aid-type element
                    anyChildElement = CreateTransactionAidTypeElement(xmlDocument, transactionElement, aidType) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/aid-type elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="aidType"></param>
        private bool CreateTransactionAidTypeElement(XmlDocument xmlDocument, XmlElement transactionElement, Entity aidType)
        {
            try
            {
                string code = aidType.GetAliasedValue<string>("AidTypeCode.msiati_code");
                if (!string.IsNullOrWhiteSpace(code))
                {
                    // Create aid-type element
                    XmlElement aidTypeElement = XmlUtilities.CreateChildXmlElement(xmlDocument, transactionElement, "aid-type");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, aidTypeElement, "code", code);

                    // Create vocabulary attribute
                    string vocabularyCode = aidType.GetAliasedValue<string>("AidTypeVocabulary.msiati_code");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, aidTypeElement, "vocabulary", vocabularyCode);

                    return true;
                }

                return false;

            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/transaction/tied-status element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="transactionElement"></param>
        /// <param name="transaction"></param>
        private bool CreateTransactionTiedStatusElement(XmlDocument xmlDocument, XmlElement transactionElement, Transaction transaction)
        {
            try
            {
                string code = transaction.TiedStatusCode;
                if (!string.IsNullOrWhiteSpace(code))
                {
                    // Create tied-status element
                    XmlElement tiedStatusTypeElement = XmlUtilities.CreateChildXmlElement(xmlDocument, transactionElement, "tied-status");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, tiedStatusTypeElement, "code", code);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Get list of expenditures to report
        /// </summary>
        /// <param name="deliveryFrameworkId"></param>
        /// <returns></returns>
        private List<Transaction> GetTransactionsFromExpenditureEntity(Guid deliveryFrameworkId)
        {
            try
            {
                var expenditureCondition = new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId);

                // Build query to fetch expenditures
                var expenditureQueryExpression = new QueryExpression("msiati_expenditure")
                {
                    ColumnSet =
                        new ColumnSet("msiati_description", "msiati_humanitarian", "msiati_reference", "msiati_transactiontype", "msiati_startdate", "msiati_totalexpenditure",
                            "msiati_currencyvaluedate", "msiati_provideractivityidentifier", "msiati_recipientactivityidentifier", "msiati_recipientcountrydescription",
                            "msiati_recipientregiondescription"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            expenditureCondition
                        }
                    },
                    LinkEntities =
                    {
                        // Currency
                        new LinkEntity(
                            "msiati_expenditure",
                            "transactioncurrency",
                            "transactioncurrencyid",
                            "transactioncurrencyid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "Currency",
                            Columns = new ColumnSet("isocurrencycode")
                        },
                        // Provider Organization
                        new LinkEntity(
                            "msiati_expenditure",
                            "account",
                            "msiati_providerorganizationid",
                            "accountid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "ProviderOrganization",
                            Columns = new ColumnSet("accountid", "name", "msiati_iatiorganizationidentifier"),
                            LinkEntities =
                            {
                                // Provider Organization Type
                                new LinkEntity(
                                    "account",
                                    "msiati_nonembeddedcodelist",
                                    "msiati_organizationtypeid",
                                    "msiati_nonembeddedcodelistid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "ProviderOrganizationType",
                                    Columns = new ColumnSet("msiati_code")
                                }
                            }
                        },
                        // Recipient Organization
                        new LinkEntity(
                            "msiati_expenditure",
                            "account",
                            "msiati_recipientorganizationid",
                            "accountid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "RecipientOrganization",
                            Columns = new ColumnSet("accountid", "name", "msiati_iatiorganizationidentifier"),
                            LinkEntities =
                            {
                                // Recipient Organization Type
                                new LinkEntity(
                                    "account",
                                    "msiati_nonembeddedcodelist",
                                    "msiati_organizationtypeid",
                                    "msiati_nonembeddedcodelistid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "RecipientOrganizationType",
                                    Columns = new ColumnSet("msiati_code")
                                }
                            }
                        },
                        // Disbursement Channel
                        new LinkEntity(
                            "msiati_expenditure",
                            "msiati_nonembeddedcodelist",
                            "msiati_disbursementchannelid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "DisbursementChannel",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Recipient Country
                        new LinkEntity(
                            "msiati_expenditure",
                            "msiati_nonembeddedcodelist",
                            "msiati_recipientcountryid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "RecipientCountry",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Recipient Region
                        new LinkEntity(
                            "msiati_expenditure",
                            "msiati_nonembeddedcodelist",
                            "msiati_recipientregionid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "RecipientRegion",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Recipient Region Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "RecipientRegionVocabulary",
                                    Columns = new ColumnSet("msiati_code", "msiati_uri")
                                }
                            }
                        }
                    }
                };

                // Build query to fetch additional details (due to limitation in the amount of Link Entities per query)
                var additionalDataQueryExpression = new QueryExpression("msiati_expenditure")
                {
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            expenditureCondition
                        }
                    },
                    LinkEntities =
                    {
                        // Flow Type
                        new LinkEntity(
                            "msiati_expenditure",
                            "msiati_nonembeddedcodelist",
                            "msiati_flowtypeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "FlowType",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Finance Type
                        new LinkEntity(
                            "msiati_expenditure",
                            "msiati_nonembeddedcodelist",
                            "msiati_financetypeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "FinanceType",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Tied Status
                        new LinkEntity(
                            "msiati_expenditure",
                            "msiati_nonembeddedcodelist",
                            "msiati_tiedstatusid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "TiedStatus",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                DataCollection<Entity> expenditures = _service.RetrieveMultiple(expenditureQueryExpression).Entities;
                DataCollection<Entity> expendituresAdditionalData = _service.RetrieveMultiple(additionalDataQueryExpression).Entities;
                List<Transaction> expenditureTransactions = new List<Transaction>();
                foreach (Entity expenditure in expenditures)
                {
                    Entity expenditureAdditionalDetail = expendituresAdditionalData.First(t => t.Id == expenditure.Id);

                    var expenditureTransaction = new Transaction(TransactionEntity.Expenditure)
                    {
                        Id = expenditure.Id,
                        Description = expenditure.GetAttributeValue<string>("msiati_description"),
                        Reference = expenditure.GetAttributeValue<string>("msiati_reference"),
                        Humanitarian = expenditure.GetAttributeValue<bool?>("msiati_humanitarian"),
                        Date = expenditure.GetAttributeValue<DateTime?>("msiati_startdate"),
                        Amount = expenditure.GetAttributeValue<Money>("msiati_totalexpenditure"),
                        CurrencyCode = expenditure.GetAliasedValue<string>("Currency.isocurrencycode"),
                        CurrencyValueDate = expenditure.GetAttributeValue<DateTime?>("msiati_currencyvaluedate"),
                        ProviderOrganizationId = expenditure.GetAliasedValue<Guid?>("ProviderOrganization.accountid"),
                        ProviderOrganizationIatiIdentifier = expenditure.GetAliasedValue<string>("ProviderOrganization.msiati_iatiorganizationidentifier"),
                        ProviderOrganizationName = expenditure.GetAliasedValue<string>("ProviderOrganization.name"),
                        ProviderOrganizationTypeCode = expenditure.GetAliasedValue<string>("ProviderOrganizationType.msiati_code"),
                        ProviderActivityIdentifier = expenditure.GetAttributeValue<string>("msiati_provideractivityidentifier"),
                        RecipientOrganizationId = expenditure.GetAliasedValue<Guid?>("RecipientOrganization.accountid"),
                        RecipientOrganizationIatiIdentifier = expenditure.GetAliasedValue<string>("RecipientOrganization.msiati_iatiorganizationidentifier"),
                        RecipientOrganizationName = expenditure.GetAliasedValue<string>("RecipientOrganization.name"),
                        RecipientOrganizationTypeCode = expenditure.GetAliasedValue<string>("RecipientOrganizationType.msiati_code"),
                        RecipientActivityIdentifier = expenditure.GetAttributeValue<string>("msiati_recipientactivityidentifier"),
                        DisbursementChannelCode = expenditure.GetAliasedValue<string>("DisbursementChannel.msiati_code"),
                        RecipientCountryCode = expenditure.GetAliasedValue<string>("RecipientCountry.msiati_code"),
                        RecipientCountryDescription = expenditure.GetAttributeValue<string>("msiati_recipientcountrydescription"),
                        RecipientRegionCode = expenditure.GetAliasedValue<string>("RecipientRegion.msiati_code"),
                        RecipientRegionVocabularyCode = expenditure.GetAliasedValue<string>("RecipientRegionVocabulary.msiati_code"),
                        RecipientRegionVocabularyUri = expenditure.GetAliasedValue<string>("RecipientRegionVocabulary.msiati_uri"),
                        RecipientRegionDescription = expenditure.GetAttributeValue<string>("msiati_recipientregiondescription"),
                        FlowTypeCode = expenditureAdditionalDetail?.GetAliasedValue<string>("FlowType.msiati_code"),
                        FinanceTypeCode = expenditureAdditionalDetail?.GetAliasedValue<string>("FinanceType.msiati_code"),
                        TiedStatusCode = expenditureAdditionalDetail?.GetAliasedValue<string>("TiedStatus.msiati_code")
                    };

                    int? transactionTypeId = expenditure.GetOptionSetValue("msiati_transactiontype");
                    if (transactionTypeId != null)
                    {
                        expenditureTransaction.TransactionTypeCode = CommonUtilities.GetCodelistCodeByOptionSetId(Constants.ExpenditureTransactionTypeTypeIdCodeMapping,
                            (ExpenditureTransactionType)transactionTypeId);
                    }

                    expenditureTransactions.Add(expenditureTransaction);
                }

                return expenditureTransactions;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return new List<Transaction>();
            }
        }

        /// <summary>
        /// Get list of disbursements to report
        /// </summary>
        /// <param name="deliveryFrameworkId"></param>
        /// <returns></returns>
        private List<Transaction> GetTransactionsFromDisbursementEntity(Guid deliveryFrameworkId)
        {
            try
            {
                LinkEntity filteringLinkEntity = new LinkEntity(
                    "msnfp_disbursement",
                    "msnfp_disbursementdistribution",
                    "msnfp_adjustsoriginaltransactionid",
                    "msnfp_disbursementdistributionid",
                    JoinOperator.Inner)
                {
                    EntityAlias = "DisbursementDistribution",
                    LinkCriteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msnfp_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    }
                };

                // Build query to fetch Disbursements
                var disbursementQueryExpression = new QueryExpression("msnfp_disbursement")
                {
                    ColumnSet =
                        new ColumnSet("msnfp_description", "msiati_humanitarian", "msiati_reference", "msiati_transactiontype", "msnfp_sentdate", "msnfp_scheduleddisbursementdate",
                            "msnfp_amount", "msiati_currencyvaluedate", "msiati_provideractivityidentifier", "msiati_recipientactivityidentifier",
                            "msiati_recipientcountrydescription", "msiati_recipientregiondescription"),
                    LinkEntities =
                    {
                        // Filtering
                        filteringLinkEntity,
                        // Currency
                        new LinkEntity(
                            "msnfp_disbursement",
                            "transactioncurrency",
                            "transactioncurrencyid",
                            "transactioncurrencyid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "Currency",
                            Columns = new ColumnSet("isocurrencycode")
                        },
                        // Provider Organization
                        new LinkEntity(
                            "msnfp_disbursement",
                            "account",
                            "msiati_providerorganizationid",
                            "accountid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "ProviderOrganization",
                            Columns = new ColumnSet("accountid", "name", "msiati_iatiorganizationidentifier"),
                            LinkEntities =
                            {
                                // Provider Organization Type
                                new LinkEntity(
                                    "account",
                                    "msiati_nonembeddedcodelist",
                                    "msiati_organizationtypeid",
                                    "msiati_nonembeddedcodelistid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "ProviderOrganizationType",
                                    Columns = new ColumnSet("msiati_code")
                                }
                            }
                        },
                        // Recipient Organization
                        new LinkEntity(
                            "msnfp_disbursement",
                            "account",
                            "msiati_recipientorganizationid",
                            "accountid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "RecipientOrganization",
                            Columns = new ColumnSet("accountid", "name", "msiati_iatiorganizationidentifier"),
                            LinkEntities =
                            {
                                // Recipient Organization Type
                                new LinkEntity(
                                    "account",
                                    "msiati_nonembeddedcodelist",
                                    "msiati_organizationtypeid",
                                    "msiati_nonembeddedcodelistid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "RecipientOrganizationType",
                                    Columns = new ColumnSet("msiati_code")
                                }
                            }
                        },
                        // Disbursement Channel
                        new LinkEntity(
                            "msnfp_disbursement",
                            "msiati_nonembeddedcodelist",
                            "msiati_disbursementchannelid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "DisbursementChannel",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Recipient Country
                        new LinkEntity(
                            "msnfp_disbursement",
                            "msiati_nonembeddedcodelist",
                            "msiati_recipientcountryid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "RecipientCountry",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Recipient Region
                        new LinkEntity(
                            "msnfp_disbursement",
                            "msiati_nonembeddedcodelist",
                            "msiati_recipientregionid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "RecipientRegion",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Recipient Region Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "RecipientRegionVocabulary",
                                    Columns = new ColumnSet("msiati_code", "msiati_uri")
                                }
                            }
                        }
                    }
                };

                // Build query to fetch additional details (due to limitation in the amount of Link Entities per query)
                var additionalDataQueryExpression = new QueryExpression("msnfp_disbursement")
                {
                    LinkEntities =
                    {
                        // Filtering
                        filteringLinkEntity,
                        // Flow Type
                        new LinkEntity(
                            "msnfp_disbursement",
                            "msiati_nonembeddedcodelist",
                            "msiati_flowtypeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "FlowType",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Finance Type
                        new LinkEntity(
                            "msnfp_disbursement",
                            "msiati_nonembeddedcodelist",
                            "msiati_financetypeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "FinanceType",
                            Columns = new ColumnSet("msiati_code")
                        },
                        // Tied Status
                        new LinkEntity(
                            "msnfp_disbursement",
                            "msiati_nonembeddedcodelist",
                            "msiati_tiedstatusid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "TiedStatus",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                DataCollection<Entity> disbursements = _service.RetrieveMultiple(disbursementQueryExpression).Entities;
                DataCollection<Entity> disbursementsAdditionalData = _service.RetrieveMultiple(additionalDataQueryExpression).Entities;
                List<Transaction> disbursementTransactions = new List<Transaction>();
                foreach (Entity disbursement in disbursements)
                {
                    Entity disbursementAdditionalDetail = disbursementsAdditionalData.First(t => t.Id == disbursement.Id);

                    var disbursementTransaction = new Transaction(TransactionEntity.Disbursement)
                    {
                        Id = disbursement.Id,
                        Description = disbursement.GetAttributeValue<string>("msnfp_description"),
                        Humanitarian = disbursement.GetAttributeValue<bool?>("msiati_humanitarian"),
                        Reference = disbursement.GetAttributeValue<string>("msiati_reference"),
                        Amount = disbursement.GetAttributeValue<Money>("msnfp_amount"),
                        CurrencyCode = disbursement.GetAliasedValue<string>("Currency.isocurrencycode"),
                        CurrencyValueDate = disbursement.GetAttributeValue<DateTime?>("msiati_currencyvaluedate"),
                        ProviderOrganizationId = disbursement.GetAliasedValue<Guid?>("ProviderOrganization.accountid"),
                        ProviderOrganizationIatiIdentifier = disbursement.GetAliasedValue<string>("ProviderOrganization.msiati_iatiorganizationidentifier"),
                        ProviderOrganizationName = disbursement.GetAliasedValue<string>("ProviderOrganization.name"),
                        ProviderOrganizationTypeCode = disbursement.GetAliasedValue<string>("ProviderOrganizationType.msiati_code"),
                        ProviderActivityIdentifier = disbursement.GetAttributeValue<string>("msiati_provideractivityidentifier"),
                        RecipientOrganizationId = disbursement.GetAliasedValue<Guid?>("RecipientOrganization.accountid"),
                        RecipientOrganizationIatiIdentifier = disbursement.GetAliasedValue<string>("RecipientOrganization.msiati_iatiorganizationidentifier"),
                        RecipientOrganizationName = disbursement.GetAliasedValue<string>("RecipientOrganization.name"),
                        RecipientOrganizationTypeCode = disbursement.GetAliasedValue<string>("RecipientOrganizationType.msiati_code"),
                        RecipientActivityIdentifier = disbursement.GetAttributeValue<string>("msiati_recipientactivityidentifier"),
                        DisbursementChannelCode = disbursement.GetAliasedValue<string>("DisbursementChannel.msiati_code"),
                        RecipientCountryCode = disbursement.GetAliasedValue<string>("RecipientCountry.msiati_code"),
                        RecipientCountryDescription = disbursement.GetAttributeValue<string>("msiati_recipientcountrydescription"),
                        RecipientRegionCode = disbursement.GetAliasedValue<string>("RecipientRegion.msiati_code"),
                        RecipientRegionVocabularyCode = disbursement.GetAliasedValue<string>("RecipientRegionVocabulary.msiati_code"),
                        RecipientRegionVocabularyUri = disbursement.GetAliasedValue<string>("RecipientRegionVocabulary.msiati_uri"),
                        RecipientRegionDescription = disbursement.GetAttributeValue<string>("msiati_recipientregiondescription"),
                        FlowTypeCode = disbursementAdditionalDetail?.GetAliasedValue<string>("FlowType.msiati_code"),
                        FinanceTypeCode = disbursementAdditionalDetail?.GetAliasedValue<string>("FinanceType.msiati_code"),
                        TiedStatusCode = disbursementAdditionalDetail?.GetAliasedValue<string>("TiedStatus.msiati_code")
                    };

                    int? transactionTypeId = disbursement.GetOptionSetValue("msiati_transactiontype");
                    if (transactionTypeId != null)
                    {
                        disbursementTransaction.TransactionTypeCode = CommonUtilities.GetCodelistCodeByOptionSetId(Constants.DisbursementTransactionTypeTypeIdCodeMapping,
                            (DisbursementTransactionType)transactionTypeId);
                    }

                    switch (transactionTypeId)
                    {
                        case (int)DisbursementTransactionType.OutgoingCommitment:
                        case (int)DisbursementTransactionType.OutgoingPledge:
                            disbursementTransaction.Date = disbursement.GetAttributeValue<DateTime?>("msnfp_scheduleddisbursementdate");
                            break;

                        default:
                            disbursementTransaction.Date = disbursement.GetAttributeValue<DateTime?>("msnfp_sentdate");
                            break;
                    }

                    disbursementTransactions.Add(disbursementTransaction);
                }

                return disbursementTransactions;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return new List<Transaction>();
            }
        }

        /// <summary>
        /// Get list of disbursements to report
        /// </summary>
        /// <param name="deliveryFrameworkId"></param>
        /// <returns></returns>
        private List<Transaction> GetTransactionsFromDonorCommitmentEntity(Guid deliveryFrameworkId)
        {
            try
            {
                List<Transaction> donorCommitmentTransactions = new List<Transaction>();

                // Build query to fetch list of Donor Commitment Id's
                var donorCommitmentIdQueryExpression = new QueryExpression("msnfp_donorcommitment")
                {
                    LinkEntities =
                    {
                        // Designation Plan
                        new LinkEntity(
                            "msnfp_donorcommitment",
                            "msnfp_designationplan",
                            "msnfp_donorcommitmentid",
                            "msnfp_designationplan_donorcommitmentid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "DesignationPlan",
                            LinkEntities =
                            {
                                // Designation
                                new LinkEntity(
                                    "msnfp_designationplan",
                                    "msnfp_designation",
                                    "msnfp_designationplan_designationid",
                                    "msnfp_designationid",
                                    JoinOperator.Inner)
                                {
                                    EntityAlias = "Designation",
                                    LinkEntities =
                                    {
                                        // Connection
                                        new LinkEntity(
                                            "msnfp_designation",
                                            "connection",
                                            "msnfp_designationid",
                                            "record1id",
                                            JoinOperator.Inner)
                                        {
                                            EntityAlias = "Connection",
                                            LinkCriteria = new FilterExpression
                                            {
                                                Conditions =
                                                {
                                                    new ConditionExpression("record2id", ConditionOperator.Equal, deliveryFrameworkId)
                                                }
                                            },
                                            LinkEntities =
                                            {
                                                // Connection Role
                                                new LinkEntity(
                                                    "connection",
                                                    "connectionrole",
                                                    "record1roleid",
                                                    "connectionroleid",
                                                    JoinOperator.Inner)
                                                {
                                                    EntityAlias = "ConnectionRole",
                                                    Columns = new ColumnSet("name"),
                                                    LinkCriteria = new FilterExpression
                                                    {
                                                        Conditions =
                                                        {
                                                            new ConditionExpression("name", ConditionOperator.Equal, Constants.ConnectionRoleDesignationToDeliveryFramework)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                };

                // Retrieve list of Donor Commitment ID's
                List<Guid> donorCommitmentIdList = _service.RetrieveMultiple(donorCommitmentIdQueryExpression).Entities.Select(t => t.Id).Distinct().ToList();
                if (donorCommitmentIdList.Any())
                {
                    // Build query to fetch Donor Commitments
                    var donorCommitmentQueryExpression = new QueryExpression("msnfp_donorcommitment")
                    {
                        ColumnSet =
                            new ColumnSet("msiati_description", "msiati_humanitarian", "msiati_reference", "msiati_transactiontype", "msnfp_commitmentdate", "msnfp_totalamount",
                                "msiati_currencyvaluedate", "msiati_provideractivityidentifier", "msiati_recipientactivityidentifier", "msiati_recipientcountrydescription",
                                "msiati_recipientregiondescription"),
                        Criteria = new FilterExpression
                        {
                            Conditions =
                            {
                                new ConditionExpression("msnfp_donorcommitmentid", ConditionOperator.In, donorCommitmentIdList)
                            }
                        },
                        LinkEntities =
                        {
                            // Currency
                            new LinkEntity(
                                "msnfp_donorcommitment",
                                "transactioncurrency",
                                "transactioncurrencyid",
                                "transactioncurrencyid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "Currency",
                                Columns = new ColumnSet("isocurrencycode")
                            },
                            // Provider Organization
                            new LinkEntity(
                                "msnfp_donorcommitment",
                                "account",
                                "msiati_providerorganizationid",
                                "accountid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "ProviderOrganization",
                                Columns = new ColumnSet("accountid", "name", "msiati_iatiorganizationidentifier"),
                                LinkEntities =
                                {
                                    // Provider Organization Type
                                    new LinkEntity(
                                        "account",
                                        "msiati_nonembeddedcodelist",
                                        "msiati_organizationtypeid",
                                        "msiati_nonembeddedcodelistid",
                                        JoinOperator.LeftOuter)
                                    {
                                        EntityAlias = "ProviderOrganizationType",
                                        Columns = new ColumnSet("msiati_code")
                                    }
                                }
                            },
                            // Recipient Organization
                            new LinkEntity(
                                "msnfp_donorcommitment",
                                "account",
                                "msiati_recipientorganizationid",
                                "accountid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "RecipientOrganization",
                                Columns = new ColumnSet("accountid", "name", "msiati_iatiorganizationidentifier"),
                                LinkEntities =
                                {
                                    // Recipient Organization Type
                                    new LinkEntity(
                                        "account",
                                        "msiati_nonembeddedcodelist",
                                        "msiati_organizationtypeid",
                                        "msiati_nonembeddedcodelistid",
                                        JoinOperator.LeftOuter)
                                    {
                                        EntityAlias = "RecipientOrganizationType",
                                        Columns = new ColumnSet("msiati_code")
                                    }
                                }
                            },
                            // Disbursement Channel
                            new LinkEntity(
                                "msnfp_donorcommitment",
                                "msiati_nonembeddedcodelist",
                                "msiati_disbursementchannelid",
                                "msiati_nonembeddedcodelistid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "DisbursementChannel",
                                Columns = new ColumnSet("msiati_code")
                            }
                        }
                    };

                    // Build query to fetch additional details (due to limitation in the amount of Link Entities per query)
                    var additionalDataQueryExpression = new QueryExpression("msnfp_donorcommitment")
                    {
                        Criteria = new FilterExpression
                        {
                            Conditions =
                            {
                                new ConditionExpression("msnfp_donorcommitmentid", ConditionOperator.In, donorCommitmentIdList)
                            }
                        },
                        LinkEntities =
                        {
                            // Recipient Country
                            new LinkEntity(
                                "msnfp_donorcommitment",
                                "msiati_nonembeddedcodelist",
                                "msiati_recipientcountryid",
                                "msiati_nonembeddedcodelistid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "RecipientCountry",
                                Columns = new ColumnSet("msiati_code")
                            },
                            // Recipient Region
                            new LinkEntity(
                                "msnfp_donorcommitment",
                                "msiati_nonembeddedcodelist",
                                "msiati_recipientregionid",
                                "msiati_nonembeddedcodelistid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "RecipientRegion",
                                Columns = new ColumnSet("msiati_code"),
                                LinkEntities =
                                {
                                    // Recipient Region Vocabulary
                                    new LinkEntity(
                                        "msiati_nonembeddedcodelist",
                                        "msiati_nonembeddedcodelistvocabulary",
                                        "msiati_nonembeddedcodelistvocabularyid",
                                        "msiati_nonembeddedcodelistvocabularyid",
                                        JoinOperator.LeftOuter)
                                    {
                                        EntityAlias = "RecipientRegionVocabulary",
                                        Columns = new ColumnSet("msiati_code", "msiati_uri")
                                    }
                                }
                            },
                            // Flow Type
                            new LinkEntity(
                                "msnfp_donorcommitment",
                                "msiati_nonembeddedcodelist",
                                "msiati_flowtypeid",
                                "msiati_nonembeddedcodelistid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "FlowType",
                                Columns = new ColumnSet("msiati_code")
                            },
                            // Finance Type
                            new LinkEntity(
                                "msnfp_donorcommitment",
                                "msiati_nonembeddedcodelist",
                                "msiati_financetypeid",
                                "msiati_nonembeddedcodelistid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "FinanceType",
                                Columns = new ColumnSet("msiati_code")
                            },
                            // Tied Status
                            new LinkEntity(
                                "msnfp_donorcommitment",
                                "msiati_nonembeddedcodelist",
                                "msiati_tiedstatusid",
                                "msiati_nonembeddedcodelistid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "TiedStatus",
                                Columns = new ColumnSet("msiati_code")
                            }
                        }
                    };

                    DataCollection<Entity> donorCommitments = _service.RetrieveMultiple(donorCommitmentQueryExpression).Entities;
                    DataCollection<Entity> donorCommitmentsAdditionalData = _service.RetrieveMultiple(additionalDataQueryExpression).Entities;
                    foreach (Entity donorCommitment in donorCommitments)
                    {
                        Entity donorCommitmetAdditionalDetail = donorCommitmentsAdditionalData.First(t => t.Id == donorCommitment.Id);

                        var donorCommitmentTransaction = new Transaction(TransactionEntity.DonorCommitment)
                        {
                            Id = donorCommitment.Id,
                            Description = donorCommitment.GetAttributeValue<string>("msiati_description"),
                            Humanitarian = donorCommitment.GetAttributeValue<bool?>("msiati_humanitarian"),
                            Reference = donorCommitment.GetAttributeValue<string>("msiati_reference"),
                            Date = donorCommitment.GetAttributeValue<DateTime?>("msnfp_commitmentdate"),
                            Amount = donorCommitment.GetAttributeValue<Money>("msnfp_totalamount"),
                            CurrencyCode = donorCommitment.GetAliasedValue<string>("Currency.isocurrencycode"),
                            CurrencyValueDate = donorCommitment.GetAttributeValue<DateTime?>("msiati_currencyvaluedate"),
                            ProviderOrganizationId = donorCommitment.GetAliasedValue<Guid?>("ProviderOrganization.accountid"),
                            ProviderOrganizationIatiIdentifier = donorCommitment.GetAliasedValue<string>("ProviderOrganization.msiati_iatiorganizationidentifier"),
                            ProviderOrganizationName = donorCommitment.GetAliasedValue<string>("ProviderOrganization.name"),
                            ProviderOrganizationTypeCode = donorCommitment.GetAliasedValue<string>("ProviderOrganizationType.msiati_code"),
                            ProviderActivityIdentifier = donorCommitment.GetAttributeValue<string>("msiati_provideractivityidentifier"),
                            RecipientOrganizationId = donorCommitment.GetAliasedValue<Guid?>("RecipientOrganization.accountid"),
                            RecipientOrganizationIatiIdentifier = donorCommitment.GetAliasedValue<string>("RecipientOrganization.msiati_iatiorganizationidentifier"),
                            RecipientOrganizationName = donorCommitment.GetAliasedValue<string>("RecipientOrganization.name"),
                            RecipientOrganizationTypeCode = donorCommitment.GetAliasedValue<string>("RecipientOrganizationType.msiati_code"),
                            RecipientActivityIdentifier = donorCommitment.GetAttributeValue<string>("msiati_recipientactivityidentifier"),
                            DisbursementChannelCode = donorCommitment.GetAliasedValue<string>("DisbursementChannel.msiati_code"),
                            RecipientCountryCode = donorCommitmetAdditionalDetail?.GetAliasedValue<string>("RecipientCountry.msiati_code"),
                            RecipientCountryDescription = donorCommitment.GetAttributeValue<string>("msiati_recipientcountrydescription"),
                            RecipientRegionCode = donorCommitmetAdditionalDetail?.GetAliasedValue<string>("RecipientRegion.msiati_code"),
                            RecipientRegionVocabularyCode = donorCommitmetAdditionalDetail?.GetAliasedValue<string>("RecipientRegionVocabulary.msiati_code"),
                            RecipientRegionVocabularyUri = donorCommitmetAdditionalDetail?.GetAliasedValue<string>("RecipientRegionVocabulary.msiati_uri"),
                            RecipientRegionDescription = donorCommitment.GetAttributeValue<string>("msiati_recipientregiondescription"),
                            FlowTypeCode = donorCommitmetAdditionalDetail?.GetAliasedValue<string>("FlowType.msiati_code"),
                            FinanceTypeCode = donorCommitmetAdditionalDetail?.GetAliasedValue<string>("FinanceType.msiati_code"),
                            TiedStatusCode = donorCommitmetAdditionalDetail?.GetAliasedValue<string>("TiedStatus.msiati_code")
                        };

                        int? transactionTypeId = donorCommitment.GetOptionSetValue("msiati_transactiontype");
                        if (transactionTypeId != null)
                        {
                            donorCommitmentTransaction.TransactionTypeCode = CommonUtilities.GetCodelistCodeByOptionSetId(Constants.DonorCommitmentTransactionTypeTypeIdCodeMapping,
                                (DonorCommitmentTransactionType)transactionTypeId);
                        }

                        donorCommitmentTransactions.Add(donorCommitmentTransaction);
                    }
                }

                return donorCommitmentTransactions;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return new List<Transaction>();
            }
        }

        /// <summary>
        /// Get list of disbursements to report
        /// </summary>
        /// <param name="deliveryFrameworkId"></param>
        /// <returns></returns>
        private List<Transaction> GetTransactionsFromTransactionEntity(Guid deliveryFrameworkId)
        {
            try
            {
                List<Transaction> transactionList = new List<Transaction>();

                // Build query to fetch list of Donor Commitment Id's
                var transactionIdQueryExpression = new QueryExpression("msnfp_transaction")
                {
                    LinkEntities =
                    {
                        // Payment Schedule
                        new LinkEntity(
                            "msnfp_transaction",
                            "msnfp_paymentschedule",
                            "msnfp_transaction_paymentscheduleid",
                            "msnfp_paymentscheduleid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "PaymentSchedule",
                            LinkEntities =
                            {
                                // Donor Commitment
                                new LinkEntity(
                                    "msnfp_paymentschedule",
                                    "msnfp_donorcommitment",
                                    "msnfp_paymentschedule_donorcommitmentid",
                                    "msnfp_donorcommitmentid",
                                    JoinOperator.Inner)
                                {
                                    EntityAlias = "DonorCommitment",
                                    LinkEntities =
                                    {
                                        // Designation Plan
                                        new LinkEntity(
                                            "msnfp_donorcommitment",
                                            "msnfp_designationplan",
                                            "msnfp_donorcommitmentid",
                                            "msnfp_designationplan_donorcommitmentid",
                                            JoinOperator.Inner)
                                        {
                                            EntityAlias = "DesignationPlan",
                                            LinkEntities =
                                            {
                                                // Designation
                                                new LinkEntity(
                                                    "msnfp_designationplan",
                                                    "msnfp_designation",
                                                    "msnfp_designationplan_designationid",
                                                    "msnfp_designationid",
                                                    JoinOperator.Inner)
                                                {
                                                    EntityAlias = "Designation",
                                                    LinkEntities =
                                                    {
                                                        // Connection
                                                        new LinkEntity(
                                                            "msnfp_designation",
                                                            "connection",
                                                            "msnfp_designationid",
                                                            "record1id",
                                                            JoinOperator.Inner)
                                                        {
                                                            EntityAlias = "Connection",
                                                            LinkCriteria = new FilterExpression
                                                            {
                                                                Conditions =
                                                                {
                                                                    new ConditionExpression("record2id", ConditionOperator.Equal, deliveryFrameworkId)
                                                                }
                                                            },
                                                            LinkEntities =
                                                            {
                                                                // Connection Role
                                                                new LinkEntity(
                                                                    "connection",
                                                                    "connectionrole",
                                                                    "record1roleid",
                                                                    "connectionroleid",
                                                                    JoinOperator.Inner)
                                                                {
                                                                    EntityAlias = "ConnectionRole",
                                                                    Columns = new ColumnSet("name"),
                                                                    LinkCriteria = new FilterExpression
                                                                    {
                                                                        Conditions =
                                                                        {
                                                                            new ConditionExpression("name", ConditionOperator.Equal,
                                                                                Constants.ConnectionRoleDesignationToDeliveryFramework)
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                };

                // Retrieve list of Transaction ID's
                List<Guid> transactionIdList = _service.RetrieveMultiple(transactionIdQueryExpression).Entities.Select(t => t.Id).Distinct().ToList();
                if (transactionIdList.Any())
                {
                    // Build query to fetch Donor Commitments
                    var transactionQueryExpression = new QueryExpression("msnfp_transaction")
                    {
                        ColumnSet =
                            new ColumnSet("msiati_description", "msiati_humanitarian", "msiati_reference", "msnfp_receiveddate", "msnfp_amount", "msiati_currencyvaluedate",
                                "msiati_provideractivityidentifier", "msiati_recipientactivityidentifier", "msiati_recipientcountrydescription", "msiati_recipientregiondescription"),
                        Criteria = new FilterExpression
                        {
                            Conditions =
                            {
                                new ConditionExpression("msnfp_transactionid", ConditionOperator.In, transactionIdList)
                            }
                        },
                        LinkEntities =
                        {
                            // Currency
                            new LinkEntity(
                                "msnfp_transaction",
                                "transactioncurrency",
                                "transactioncurrencyid",
                                "transactioncurrencyid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "Currency",
                                Columns = new ColumnSet("isocurrencycode")
                            },
                            // Provider Organization
                            new LinkEntity(
                                "msnfp_transaction",
                                "account",
                                "msiati_provideriorganizationid",
                                "accountid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "ProviderOrganization",
                                Columns = new ColumnSet("accountid", "name", "msiati_iatiorganizationidentifier"),
                                LinkEntities =
                                {
                                    // Provider Organization Type
                                    new LinkEntity(
                                        "account",
                                        "msiati_nonembeddedcodelist",
                                        "msiati_organizationtypeid",
                                        "msiati_nonembeddedcodelistid",
                                        JoinOperator.LeftOuter)
                                    {
                                        EntityAlias = "ProviderOrganizationType",
                                        Columns = new ColumnSet("msiati_code")
                                    }
                                }
                            },
                            // Recipient Organization
                            new LinkEntity(
                                "msnfp_transaction",
                                "account",
                                "msiati_recipientorganizationid",
                                "accountid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "RecipientOrganization",
                                Columns = new ColumnSet("accountid", "name", "msiati_iatiorganizationidentifier"),
                                LinkEntities =
                                {
                                    // Recipient Organization Type
                                    new LinkEntity(
                                        "account",
                                        "msiati_nonembeddedcodelist",
                                        "msiati_organizationtypeid",
                                        "msiati_nonembeddedcodelistid",
                                        JoinOperator.LeftOuter)
                                    {
                                        EntityAlias = "RecipientOrganizationType",
                                        Columns = new ColumnSet("msiati_code")
                                    }
                                }
                            },
                            // Disbursement Channel
                            new LinkEntity(
                                "msnfp_transaction",
                                "msiati_nonembeddedcodelist",
                                "msiati_disbursementchannelid",
                                "msiati_nonembeddedcodelistid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "DisbursementChannel",
                                Columns = new ColumnSet("msiati_code")
                            }
                        }
                    };

                    // Build query to fetch additional details (due to limitation in the amount of Link Entities per query)
                    var additionalDataQueryExpression = new QueryExpression("msnfp_transaction")
                    {
                        Criteria = new FilterExpression
                        {
                            Conditions =
                            {
                                new ConditionExpression("msnfp_transactionid", ConditionOperator.In, transactionIdList)
                            }
                        },
                        LinkEntities =
                        {
                            // Recipient Country
                            new LinkEntity(
                                "msnfp_transaction",
                                "msiati_nonembeddedcodelist",
                                "msiati_recipientcountryid",
                                "msiati_nonembeddedcodelistid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "RecipientCountry",
                                Columns = new ColumnSet("msiati_code")
                            },
                            // Recipient Region
                            new LinkEntity(
                                "msnfp_transaction",
                                "msiati_nonembeddedcodelist",
                                "msiati_recipientregionid",
                                "msiati_nonembeddedcodelistid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "RecipientRegion",
                                Columns = new ColumnSet("msiati_code"),
                                LinkEntities =
                                {
                                    // Recipient Region Vocabulary
                                    new LinkEntity(
                                        "msiati_nonembeddedcodelist",
                                        "msiati_nonembeddedcodelistvocabulary",
                                        "msiati_nonembeddedcodelistvocabularyid",
                                        "msiati_nonembeddedcodelistvocabularyid",
                                        JoinOperator.LeftOuter)
                                    {
                                        EntityAlias = "RecipientRegionVocabulary",
                                        Columns = new ColumnSet("msiati_code", "msiati_uri")
                                    }
                                }
                            },
                            // Flow Type
                            new LinkEntity(
                                "msnfp_transaction",
                                "msiati_nonembeddedcodelist",
                                "msiati_flowtypeid",
                                "msiati_nonembeddedcodelistid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "FlowType",
                                Columns = new ColumnSet("msiati_code")
                            },
                            // Finance Type
                            new LinkEntity(
                                "msnfp_transaction",
                                "msiati_nonembeddedcodelist",
                                "msiati_financetypeid",
                                "msiati_nonembeddedcodelistid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "FinanceType",
                                Columns = new ColumnSet("msiati_code")
                            },
                            // Tied Status
                            new LinkEntity(
                                "msnfp_transaction",
                                "msiati_nonembeddedcodelist",
                                "msiati_tiedstatusid",
                                "msiati_nonembeddedcodelistid",
                                JoinOperator.LeftOuter)
                            {
                                EntityAlias = "TiedStatus",
                                Columns = new ColumnSet("msiati_code")
                            }
                        }
                    };

                    DataCollection<Entity> fetchedTransactions = _service.RetrieveMultiple(transactionQueryExpression).Entities;
                    DataCollection<Entity> fetchedTransactionsAdditionalData = _service.RetrieveMultiple(additionalDataQueryExpression).Entities;
                    foreach (Entity fetchedTransaction in fetchedTransactions)
                    {
                        Entity fetchedTransactionAdditionalDetail = fetchedTransactionsAdditionalData.First(t => t.Id == fetchedTransaction.Id);

                        var transaction = new Transaction(TransactionEntity.Transaction)
                        {
                            Id = fetchedTransaction.Id,
                            TransactionTypeCode = Constants.CrmTransactionTransactionTypeCode,
                            Description = fetchedTransaction.GetAttributeValue<string>("msiati_description"),
                            Humanitarian = fetchedTransaction.GetAttributeValue<bool?>("msiati_humanitarian"),
                            Reference = fetchedTransaction.GetAttributeValue<string>("msiati_reference"),
                            Date = fetchedTransaction.GetAttributeValue<DateTime?>("msnfp_receiveddate"),
                            Amount = fetchedTransaction.GetAttributeValue<Money>("msnfp_amount"),
                            CurrencyCode = fetchedTransaction.GetAliasedValue<string>("Currency.isocurrencycode"),
                            CurrencyValueDate = fetchedTransaction.GetAttributeValue<DateTime?>("msiati_currencyvaluedate"),
                            ProviderOrganizationId = fetchedTransaction.GetAliasedValue<Guid?>("ProviderOrganization.accountid"),
                            ProviderOrganizationIatiIdentifier = fetchedTransaction.GetAliasedValue<string>("ProviderOrganization.msiati_iatiorganizationidentifier"),
                            ProviderOrganizationName = fetchedTransaction.GetAliasedValue<string>("ProviderOrganization.name"),
                            ProviderOrganizationTypeCode = fetchedTransaction.GetAliasedValue<string>("ProviderOrganizationType.msiati_code"),
                            ProviderActivityIdentifier = fetchedTransaction.GetAttributeValue<string>("msiati_provideractivityidentifier"),
                            RecipientOrganizationId = fetchedTransaction.GetAliasedValue<Guid?>("RecipientOrganization.accountid"),
                            RecipientOrganizationIatiIdentifier = fetchedTransaction.GetAliasedValue<string>("RecipientOrganization.msiati_iatiorganizationidentifier"),
                            RecipientOrganizationName = fetchedTransaction.GetAliasedValue<string>("RecipientOrganization.name"),
                            RecipientOrganizationTypeCode = fetchedTransaction.GetAliasedValue<string>("RecipientOrganizationType.msiati_code"),
                            RecipientActivityIdentifier = fetchedTransaction.GetAttributeValue<string>("msiati_recipientactivityidentifier"),
                            DisbursementChannelCode = fetchedTransaction.GetAliasedValue<string>("DisbursementChannel.msiati_code"),
                            RecipientCountryCode = fetchedTransactionAdditionalDetail?.GetAliasedValue<string>("RecipientCountry.msiati_code"),
                            RecipientCountryDescription = fetchedTransaction.GetAttributeValue<string>("msiati_recipientcountrydescription"),
                            RecipientRegionCode = fetchedTransactionAdditionalDetail?.GetAliasedValue<string>("RecipientRegion.msiati_code"),
                            RecipientRegionVocabularyCode = fetchedTransactionAdditionalDetail?.GetAliasedValue<string>("RecipientRegionVocabulary.msiati_code"),
                            RecipientRegionVocabularyUri = fetchedTransactionAdditionalDetail?.GetAliasedValue<string>("RecipientRegionVocabulary.msiati_uri"),
                            RecipientRegionDescription = fetchedTransaction.GetAttributeValue<string>("msiati_recipientregiondescription"),
                            FlowTypeCode = fetchedTransactionAdditionalDetail?.GetAliasedValue<string>("FlowType.msiati_code"),
                            FinanceTypeCode = fetchedTransactionAdditionalDetail?.GetAliasedValue<string>("FinanceType.msiati_code"),
                            TiedStatusCode = fetchedTransactionAdditionalDetail?.GetAliasedValue<string>("TiedStatus.msiati_code")
                        };

                        transactionList.Add(transaction);
                    }
                }

                return transactionList;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return new List<Transaction>();
            }
        }

        #endregion

        #region related-activity

        /// <summary>
        /// Create iati-activities/iati-activity/related-activity elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateRelatedActivityElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var connectionQueryExpression = new QueryExpression("connection")
                {
                    ColumnSet = new ColumnSet(),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("record1id", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Connection Role 1 (Record1)
                        new LinkEntity(
                            "connection",
                            "connectionrole",
                            "record1roleid",
                            "connectionroleid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "ConnectionRole1",
                            Columns = new ColumnSet("name"),
                            LinkCriteria = new FilterExpression
                            {
                                Conditions =
                                {
                                    new ConditionExpression(
                                        "name",
                                        ConditionOperator.In,
                                        Constants.ConnectionRoleParentDeliveryFramework,
                                        Constants.ConnectionRoleChildDeliveryFramework,
                                        Constants.ConnectionRoleSiblingDeliveryFramework,
                                        Constants.ConnectionRoleCoFundedDeliveryFramework,
                                        Constants.ConnectionRoleThirdPartyDeliveryFramework)
                                }
                            }
                        },
                        // Delivery Framework
                        new LinkEntity(
                            "connection",
                            "msnfp_deliveryframework",
                            "record2id",
                            "msnfp_deliveryframeworkid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "DeliveryFramework",
                            Columns = new ColumnSet("msiati_iatiactivityid")
                        },
                        // Connection Role 2 (Record2)
                        new LinkEntity(
                            "connection",
                            "connectionrole",
                            "record2roleid",
                            "connectionroleid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "ConnectionRole2",
                            Columns = new ColumnSet("name")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> relatedDeliveryFrameworkConnections = _service.RetrieveMultiple(connectionQueryExpression).Entities;
                foreach (Entity relatedDeliveryFrameworkConnection in relatedDeliveryFrameworkConnections)
                {
                    // Create related-activity element
                    anyChildElement = CreateRelatedActivityIndividualElement(xmlDocument, iatiActivityElement, relatedDeliveryFrameworkConnection) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/related-activity element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="relatedDeliveryFrameworkConnection"></param>
        private bool CreateRelatedActivityIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity relatedDeliveryFrameworkConnection)
        {
            try
            {
                string @ref = relatedDeliveryFrameworkConnection.GetAliasedValue<string>("DeliveryFramework.msiati_iatiactivityid");
                if (!string.IsNullOrWhiteSpace(@ref))
                {
                    // Create related-activity element
                    XmlElement relatedActivityElement = XmlUtilities.CreateChildXmlElement(xmlDocument, iatiActivityElement, "related-activity");

                    // Create ref attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, relatedActivityElement, "ref", @ref);

                    string connectionRoleName = relatedDeliveryFrameworkConnection.GetAliasedValue<string>("ConnectionRole2.name");
                    string typeCode = CommonUtilities.GetRelatedActivityTypeCodeByConnectionRoleName(connectionRoleName);
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, relatedActivityElement, "type", typeCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region conditions

        /// <summary>
        /// Create iati-activities/iati-activity/conditions element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateConditionsElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var conditionQueryExpression = new QueryExpression("msiati_condition")
                {
                    ColumnSet = new ColumnSet("msiati_name"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Condition Type
                        new LinkEntity(
                            "msiati_condition",
                            "msiati_nonembeddedcodelist",
                            "msiati_typeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "ConditionType",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                // Create conditions element
                XmlElement conditionsElement = XmlUtilities.CreateChildXmlElement(xmlDocument, iatiActivityElement, "conditions");

                DataCollection<Entity> conditions = _service.RetrieveMultiple(conditionQueryExpression).Entities;

                // Create attached attribute
                string attached = conditions.Any() ? "1" : "0";
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, conditionsElement, "attached", attached);

                bool anyChildElement = false;
                foreach (Entity condition in conditions)
                {
                    // Create condition element
                    anyChildElement = CreateConditionsConditionIndividualElement(xmlDocument, conditionsElement, condition) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/conditions/condition element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="conditionsElement"></param>
        /// <param name="condition"></param>
        private bool CreateConditionsConditionIndividualElement(XmlDocument xmlDocument, XmlElement conditionsElement, Entity condition)
        {
            try
            {
                // Create condition element
                XmlElement conditionElement = xmlDocument.CreateElement("condition");

                // Create type attribute
                string typeCode = condition.GetAliasedValue<string>("ConditionType.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(typeCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, conditionElement, "type", typeCode);

                // Create narrative elements
                anyChildElement =
                    CommonUtilities.CreateNarrativeElements(_service, xmlDocument, conditionElement, condition, "msiati_name", false, condition.Id,
                        NarrativeTranslationEntity.Condition, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    conditionsElement.AppendChild(conditionElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region result

        /// <summary>
        /// Create iati-activities/iati-activity/result elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateResultElements(XmlDocument xmlDocument, XmlElement iatiActivityElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var resultQueryExpression = new QueryExpression("msnfp_result")
                {
                    ColumnSet = new ColumnSet("msnfp_aggregationstatus", "msnfp_name", "msnfp_description"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msnfp_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Result Type
                        new LinkEntity(
                            "msnfp_result",
                            "msiati_nonembeddedcodelist",
                            "msiati_resulttypeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "ResultType",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> results = _service.RetrieveMultiple(resultQueryExpression).Entities;
                foreach (Entity result in results)
                {
                    // Create result element
                    anyChildElement = CreateResultIndividualElement(xmlDocument, iatiActivityElement, result) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/result element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="result"></param>
        private bool CreateResultIndividualElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity result)
        {
            try
            {
                Guid resultId = result.Id;

                // Create location element
                XmlElement resultElement = xmlDocument.CreateElement("result");

                // Create type attribute
                string typeCode = result.GetAliasedValue<string>("ResultType.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(typeCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, resultElement, "type", typeCode);

                // Create aggregation-status attribute
                string aggregationStatus = result.GetAttributeValue<bool?>("msnfp_aggregationstatus") == true ? "1" : "0";
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, resultElement, "aggregation-status", aggregationStatus);

                // Create title element
                anyChildElement = CreateResultTitleElement(xmlDocument, resultElement, result, resultId) || anyChildElement;

                // Create description element
                anyChildElement = CreateResultDescriptionElement(xmlDocument, resultElement, result, resultId) || anyChildElement;

                // Create document-link elements
                anyChildElement =
                    CommonUtilities.CreateDocumentLinkElements(_service, _tracingService, _exceptionLog, xmlDocument, resultElement, resultId,
                        Constants.ConnectionRoleDocumentLinkToResult, false) || anyChildElement;

                // Create reference elements
                anyChildElement = CreateResultReferenceElements(xmlDocument, resultElement, resultId) || anyChildElement;

                // Create indicator elements
                anyChildElement = CreateResultIndicatorElements(xmlDocument, resultElement, resultId) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(resultElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/result/title element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="resultElement"></param>
        /// <param name="result"></param>
        /// <param name="resultId"></param>
        private bool CreateResultTitleElement(XmlDocument xmlDocument, XmlElement resultElement, Entity result, Guid resultId)
        {
            try
            {
                // Create title and narrative elements
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, resultElement, result, "msnfp_name", false, resultId, NarrativeTranslationEntity.Result,
                    NarrativeTranslationAttribute.Name, true, "title");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/result/title element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="resultElement"></param>
        /// <param name="result"></param>
        /// <param name="resultId"></param>
        private bool CreateResultDescriptionElement(XmlDocument xmlDocument, XmlElement resultElement, Entity result, Guid resultId)
        {
            try
            {
                // Create description and narrative elements
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, resultElement, result, "msnfp_description", false, resultId, NarrativeTranslationEntity.Result,
                    NarrativeTranslationAttribute.Description, true, "description");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/result/reference elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="resultElement"></param>
        /// <param name="resultId"></param>
        private bool CreateResultReferenceElements(XmlDocument xmlDocument, XmlElement resultElement, Guid resultId)
        {
            try
            {
                // Build query to fetch data
                var resultReferenceQueryExpression = new QueryExpression("msiati_resultreference")
                {
                    ColumnSet = new ColumnSet(),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_resultid", ConditionOperator.Equal, resultId)
                        }
                    },
                    LinkEntities =
                    {
                        // Result Code
                        new LinkEntity(
                            "msiati_resultreference",
                            "msiati_nonembeddedcodelist",
                            "msiati_resultcodeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "ResultCode",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Result Code Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "ResultCodeVocabulary",
                                    Columns = new ColumnSet("msiati_code", "msiati_uri")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> resultReferences = _service.RetrieveMultiple(resultReferenceQueryExpression).Entities;
                foreach (Entity resultReference in resultReferences)
                {
                    // Create reference element
                    anyChildElement = CreateResultReferenceIndividualElement(xmlDocument, resultElement, resultReference) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/result/reference element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="resultElement"></param>
        /// <param name="resultReference"></param>
        private bool CreateResultReferenceIndividualElement(XmlDocument xmlDocument, XmlElement resultElement, Entity resultReference)
        {
            try
            {
                // Create reference element
                XmlElement referenceElement = xmlDocument.CreateElement("reference");

                // Create code attribute
                string code = resultReference.GetAliasedValue<string>("ResultCode.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(code);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, referenceElement, "code", code);

                // Create vocabulary attribute
                string vocabularyCode = resultReference.GetAliasedValue<string>("ResultCodeVocabulary.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(vocabularyCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, referenceElement, "vocabulary", vocabularyCode);

                // Create vocabulary-uri attribute
                if (vocabularyCode == "99")
                {
                    string vocabularyUri = resultReference.GetAliasedValue<string>("ResultCodeVocabulary.msiati_uri");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, referenceElement, "vocabulary-uri", vocabularyUri);
                }

                // If any child element, add parent
                if (anyChildElement)
                {
                    resultElement.AppendChild(referenceElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/result/indicator elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="resultElement"></param>
        /// <param name="resultId"></param>
        private bool CreateResultIndicatorElements(XmlDocument xmlDocument, XmlElement resultElement, Guid resultId)
        {
            try
            {
                // Build query to fetch data
                var resultReferenceQueryExpression = new QueryExpression("msnfp_indicator")
                {
                    ColumnSet = new ColumnSet("msnfp_ascending", "msnfp_aggregationstatus", "msnfp_name", "msnfp_description"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msnfp_resultid", ConditionOperator.Equal, resultId)
                        }
                    },
                    LinkEntities =
                    {
                        // Measure
                        new LinkEntity(
                            "msnfp_indicator",
                            "msiati_nonembeddedcodelist",
                            "msiati_indicatormeasureid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "Measure",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> indicators = _service.RetrieveMultiple(resultReferenceQueryExpression).Entities;
                foreach (Entity indicator in indicators)
                {
                    // Create indicator element
                    anyChildElement = CreateResultIndicatorIndividualElement(xmlDocument, resultElement, indicator) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/result/indicator element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="resultElement"></param>
        /// <param name="indicator"></param>
        private bool CreateResultIndicatorIndividualElement(XmlDocument xmlDocument, XmlElement resultElement, Entity indicator)
        {
            try
            {
                Guid indicatorId = indicator.Id;

                // Create indicator element
                XmlElement indicatorElement = xmlDocument.CreateElement("indicator");

                // Create measure attribute
                string code = indicator.GetAliasedValue<string>("Measure.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(code);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, indicatorElement, "measure", code);

                // Create ascending attribute
                string ascending = indicator.GetAttributeValue<bool?>("msnfp_ascending") == true ? "1" : "0";
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, indicatorElement, "ascending", ascending);

                // Create aggregation-status attribute
                string aggregationStatus = indicator.GetAttributeValue<bool?>("msnfp_aggregationstatus") == true ? "1" : "0";
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, indicatorElement, "aggregation-status", aggregationStatus);

                // Create title element
                anyChildElement = CreateResultIndicatorTitleElement(xmlDocument, indicatorElement, indicator, indicatorId) || anyChildElement;

                // Create description element
                anyChildElement = CreateResultIndicatorDescriptionElement(xmlDocument, indicatorElement, indicator, indicatorId) || anyChildElement;

                // Create document-link elements
                anyChildElement =
                    CommonUtilities.CreateDocumentLinkElements(_service, _tracingService, _exceptionLog, xmlDocument, indicatorElement, indicatorId,
                        Constants.ConnectionRoleDocumentLinkToIndicator, false) || anyChildElement;

                // Create reference elements
                anyChildElement = CreateResultIndicatorReferenceElements(xmlDocument, indicatorElement, indicatorId) || anyChildElement;

                // Get indicator values
                DataCollection<Entity> indicatorValues = GetIndicatorValues(indicatorId);
                if (indicatorValues != null)
                {
                    // Create baseline elements
                    anyChildElement = CreateResultIndicatorBaselineElements(xmlDocument, indicatorElement, indicatorValues) || anyChildElement;

                    // Create period elements
                    anyChildElement = CreateResultIndicatorPeriodElements(xmlDocument, indicatorElement, indicatorValues) || anyChildElement;
                }

                // If any child element, add parent
                if (anyChildElement)
                {
                    resultElement.AppendChild(indicatorElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Get an Indicator's Indicator Values
        /// </summary>
        /// <param name="indicatorId"></param>
        /// <returns></returns>
        private DataCollection<Entity> GetIndicatorValues(Guid indicatorId)
        {
            try
            {
                // Build query to fetch indicator value data
                var indicatorValueQueryExpression = new QueryExpression("msnfp_indicatorvalue")
                {
                    ColumnSet = new ColumnSet("msnfp_description", "msnfp_amount", "msnfp_number", "msnfp_percentage", "msnfp_startdate", "msnfp_enddate", "msiati_year", "msnfp_valuetype"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msnfp_indicatorid", ConditionOperator.Equal, indicatorId)
                        }
                    }
                };

                return _service.RetrieveMultiple(indicatorValueQueryExpression).Entities;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return null;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/result/indicator/title element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="resultElement"></param>
        /// <param name="indicator"></param>
        /// <param name="indicatorId"></param>
        private bool CreateResultIndicatorTitleElement(XmlDocument xmlDocument, XmlElement resultElement, Entity indicator, Guid indicatorId)
        {
            try
            {
                // Create title and narrative elements
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, resultElement, indicator, "msnfp_name", false, indicatorId,
                    NarrativeTranslationEntity.Indicator, NarrativeTranslationAttribute.Name, true, "title");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/result/indicator/description element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="resultElement"></param>
        /// <param name="indicator"></param>
        /// <param name="indicatorId"></param>
        private bool CreateResultIndicatorDescriptionElement(XmlDocument xmlDocument, XmlElement resultElement, Entity indicator, Guid indicatorId)
        {
            try
            {
                // Create title and narrative elements
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, resultElement, indicator, "msnfp_description", false, indicatorId,
                    NarrativeTranslationEntity.Indicator, NarrativeTranslationAttribute.Description, true, "description");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/result/indicator/reference elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="indicatorElement"></param>
        /// <param name="indicatorId"></param>
        private bool CreateResultIndicatorReferenceElements(XmlDocument xmlDocument, XmlElement indicatorElement, Guid indicatorId)
        {
            try
            {
                // Build query to fetch data
                var indicatorReferenceQueryExpression = new QueryExpression("msiati_indicatorreference")
                {
                    ColumnSet = new ColumnSet(),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_indicatorid", ConditionOperator.Equal, indicatorId)
                        }
                    },
                    LinkEntities =
                    {
                        // Indicator Code
                        new LinkEntity(
                            "msiati_indicatorreference",
                            "msiati_nonembeddedcodelist",
                            "msiati_indicatorcodeid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "IndicatorCode",
                            Columns = new ColumnSet("msiati_code"),
                            LinkEntities =
                            {
                                // Indicator Code Vocabulary
                                new LinkEntity(
                                    "msiati_nonembeddedcodelist",
                                    "msiati_nonembeddedcodelistvocabulary",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    "msiati_nonembeddedcodelistvocabularyid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "IndicatorCodeVocabulary",
                                    Columns = new ColumnSet("msiati_code", "msiati_uri")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> indicatorReferences = _service.RetrieveMultiple(indicatorReferenceQueryExpression).Entities;
                foreach (Entity indicatorReference in indicatorReferences)
                {
                    // Create reference element
                    anyChildElement = CreateResultIndicatorReferenceIndividualElement(xmlDocument, indicatorElement, indicatorReference) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/result/indicator/reference element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="indicatorElement"></param>
        /// <param name="indicatorReference"></param>
        private bool CreateResultIndicatorReferenceIndividualElement(XmlDocument xmlDocument, XmlElement indicatorElement, Entity indicatorReference)
        {
            try
            {
                // Create reference element
                XmlElement referenceElement = xmlDocument.CreateElement("reference");

                // Create vocabulary attribute
                string vocabularyCode = indicatorReference.GetAliasedValue<string>("IndicatorCodeVocabulary.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(vocabularyCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, referenceElement, "vocabulary", vocabularyCode);

                // Create indicator-uri attribute
                if (vocabularyCode == "99")
                {
                    string vocabularyUri = indicatorReference.GetAliasedValue<string>("IndicatorCodeVocabulary.msiati_uri");
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, referenceElement, "indicator-uri", vocabularyUri);
                }

                // Create code attribute
                string code = indicatorReference.GetAliasedValue<string>("IndicatorCode.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(code) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, referenceElement, "code", code);

                // If any child element, add parent
                if (anyChildElement)
                {
                    indicatorElement.AppendChild(referenceElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/result/indicator/baseline elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="indicatorElement"></param>
        /// <param name="indicatorValues"></param>
        private bool CreateResultIndicatorBaselineElements(XmlDocument xmlDocument, XmlElement indicatorElement, DataCollection<Entity> indicatorValues)
        {
            try
            {
                bool anyChildElement = false;
                List<Entity> baselineValues = indicatorValues.Where(t => t.GetOptionSetValue("msnfp_valuetype") == (int)IndicatorValueType.Baseline).ToList();
                foreach (Entity baselineValue in baselineValues)
                {
                    // Create baseline element
                    anyChildElement = CreateResultIndicatorBaselineIndividualElement(xmlDocument, indicatorElement, baselineValue) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/result/indicator/baseline element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="indicatorElement"></param>
        /// <param name="baselineValue"></param>
        private bool CreateResultIndicatorBaselineIndividualElement(XmlDocument xmlDocument, XmlElement indicatorElement, Entity baselineValue)
        {
            try
            {
                Guid indicatorValueId = baselineValue.Id;

                // Create baseline element
                XmlElement baselineElement = xmlDocument.CreateElement("baseline");
                bool anyChildElement = false;

                DateTime? startDate = baselineValue.GetAttributeValue<DateTime?>("msnfp_startdate");
                DateTime? endDate = baselineValue.GetAttributeValue<DateTime?>("msnfp_enddate");
                DateTime? date = startDate ?? endDate;
                if (date != null)
                {
                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, baselineElement, "iso-date", date.Value, Constants.DateFormatDateOnly);
                    anyChildElement = true;
                }

                // Create year attribute
                int? year = baselineValue.GetAttributeValue<int?>("msiati_year");
                anyChildElement = year != null || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, baselineElement, "year", year);

                // Create value attribute
                Money amount = baselineValue.GetAttributeValue<Money>("msnfp_amount");
                decimal? percentage = baselineValue.GetAttributeValue<decimal?>("msnfp_percentage");
                int? number = baselineValue.GetAttributeValue<int?>("msnfp_number");
                if (amount != null)
                {
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, baselineElement, "value", amount.Value, Constants.DecimalFormatTwoDecimalDigits);
                    anyChildElement = true;
                }
                else if (percentage != null)
                {
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, baselineElement, "value", percentage.Value, Constants.DecimalFormatFiveDecimalDigits);
                    anyChildElement = true;
                }
                else if (number != null)
                {
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, baselineElement, "value", number.Value);
                    anyChildElement = true;
                }

                // Create location elements
                anyChildElement = CreateIndicatorValueLocationElements(xmlDocument, baselineElement, indicatorValueId) || anyChildElement;

                // Create dimension elements
                anyChildElement = CreateIndicatorValueDimensionElements(xmlDocument, baselineElement, indicatorValueId) || anyChildElement;

                // Create document-link elements
                anyChildElement =
                    CommonUtilities.CreateDocumentLinkElements(_service, _tracingService, _exceptionLog, xmlDocument, baselineElement, indicatorValueId,
                        Constants.ConnectionRoleDocumentLinkToIndicatorValue, false) || anyChildElement;

                // Create comment element
                anyChildElement = CreateIndicatorValueCommentElement(xmlDocument, baselineElement, baselineValue, indicatorValueId) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    indicatorElement.AppendChild(baselineElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/result/indicator/period elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="indicatorElement"></param>
        /// <param name="indicatorValues"></param>
        private bool CreateResultIndicatorPeriodElements(XmlDocument xmlDocument, XmlElement indicatorElement, DataCollection<Entity> indicatorValues)
        {
            try
            {
                List<Entity> targetAndActualValues = indicatorValues
                    .Where(
                        t => t.GetOptionSetValue("msnfp_valuetype") == (int)IndicatorValueType.Actual ||
                             t.GetOptionSetValue("msnfp_valuetype") == (int)IndicatorValueType.Target)
                    .ToList();

                List<Period> periods = targetAndActualValues
                    .Select(t => new { StartDate = t.GetAttributeValue<DateTime?>("msnfp_startdate"), EndDate = t.GetAttributeValue<DateTime?>("msnfp_enddate") })
                    .Distinct()
                    .Select(t => new Period { StartDate = t.StartDate, EndDate = t.EndDate })
                    .ToList();

                bool anyChildElement = false;
                foreach (Period period in periods)
                {
                    // Create period element
                    anyChildElement = CreateResultIndicatorPeriodIndividualElement(xmlDocument, indicatorElement, period, targetAndActualValues) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/result/indicator/period element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="indicatorElement"></param>
        /// <param name="period"></param>
        /// <param name="targetAndActualValues"></param>
        private bool CreateResultIndicatorPeriodIndividualElement(XmlDocument xmlDocument, XmlElement indicatorElement, Period period, List<Entity> targetAndActualValues)
        {
            try
            {
                // Create period element
                XmlElement periodElement = xmlDocument.CreateElement("period");

                // Create period-start element
                bool anyChildElement = CreateResultIndicatorPeriodPeriodStartElement(xmlDocument, periodElement, period);

                // Create period-end element
                anyChildElement = CreateResultIndicatorPeriodPeriodEndElement(xmlDocument, periodElement, period) || anyChildElement;

                // Create target elements
                anyChildElement = CreateResultIndicatorPeriodTargetElements(xmlDocument, periodElement, period, targetAndActualValues) || anyChildElement;

                // Create actual elements
                anyChildElement = CreateResultIndicatorPeriodActualElements(xmlDocument, periodElement, period, targetAndActualValues) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    indicatorElement.AppendChild(periodElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/result/indicator/period/period-start element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="periodElement"></param>
        /// <param name="period"></param>
        private bool CreateResultIndicatorPeriodPeriodStartElement(XmlDocument xmlDocument, XmlElement periodElement, Period period)
        {
            try
            {
                if (period.StartDate != null)
                {
                    // Create period-start element
                    XmlElement periodStartElement = XmlUtilities.CreateChildXmlElement(xmlDocument, periodElement, "period-start");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, periodStartElement, "iso-date", period.StartDate, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/result/indicator/period/period-start element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="periodElement"></param>
        /// <param name="period"></param>
        private bool CreateResultIndicatorPeriodPeriodEndElement(XmlDocument xmlDocument, XmlElement periodElement, Period period)
        {
            try
            {
                if (period.EndDate != null)
                {
                    // Create period-end element
                    XmlElement periodEndElement = XmlUtilities.CreateChildXmlElement(xmlDocument, periodElement, "period-end");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, periodEndElement, "iso-date", period.EndDate, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/result/indicator/period/target elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="periodElement"></param>
        /// <param name="period"></param>
        /// <param name="targetAndActualValues"></param>
        private bool CreateResultIndicatorPeriodTargetElements(XmlDocument xmlDocument, XmlElement periodElement, Period period, List<Entity> targetAndActualValues)
        {
            try
            {
                List<Entity> targetValues = targetAndActualValues
                    .Where(
                        t =>
                            t.GetAttributeValue<DateTime?>("msnfp_startdate") == period.StartDate &&
                            t.GetAttributeValue<DateTime?>("msnfp_enddate") == period.EndDate &&
                            t.GetOptionSetValue("msnfp_valuetype") == (int)IndicatorValueType.Target)
                    .ToList();

                bool anyChildElement = false;
                foreach (Entity targetValue in targetValues)
                {
                    // Create target element
                    anyChildElement = CreateResultIndicatorPeriodTargetIndividualElement(xmlDocument, periodElement, targetValue) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/result/indicator/period/target element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="periodElement"></param>
        /// <param name="targetValue"></param>
        private bool CreateResultIndicatorPeriodTargetIndividualElement(XmlDocument xmlDocument, XmlElement periodElement, Entity targetValue)
        {
            try
            {
                Guid indicatorValueId = targetValue.Id;

                // Create target element
                XmlElement baselineElement = xmlDocument.CreateElement("target");

                bool anyChildElement = false;

                // Create value attribute
                Money amount = targetValue.GetAttributeValue<Money>("msnfp_amount");
                decimal? percentage = targetValue.GetAttributeValue<decimal?>("msnfp_percentage");
                int? number = targetValue.GetAttributeValue<int?>("msnfp_number");
                if (amount != null)
                {
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, baselineElement, "value", amount.Value, Constants.DecimalFormatTwoDecimalDigits);
                    anyChildElement = true;
                }
                else if (percentage != null)
                {
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, baselineElement, "value", percentage.Value, Constants.DecimalFormatFiveDecimalDigits);
                    anyChildElement = true;
                }
                else if (number != null)
                {
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, baselineElement, "value", number.Value);
                    anyChildElement = true;
                }

                // Create location elements
                anyChildElement = CreateIndicatorValueLocationElements(xmlDocument, baselineElement, indicatorValueId) || anyChildElement;

                // Create dimension elements
                anyChildElement = CreateIndicatorValueDimensionElements(xmlDocument, baselineElement, indicatorValueId) || anyChildElement;

                // Create comment element
                anyChildElement = CreateIndicatorValueCommentElement(xmlDocument, baselineElement, targetValue, indicatorValueId) || anyChildElement;

                // Create document-link elements
                anyChildElement =
                    CommonUtilities.CreateDocumentLinkElements(_service, _tracingService, _exceptionLog, xmlDocument, baselineElement, indicatorValueId,
                        Constants.ConnectionRoleDocumentLinkToIndicatorValue, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    periodElement.AppendChild(baselineElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/result/indicator/period/actual elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="periodElement"></param>
        /// <param name="period"></param>
        /// <param name="targetAndActualValues"></param>
        private bool CreateResultIndicatorPeriodActualElements(XmlDocument xmlDocument, XmlElement periodElement, Period period, List<Entity> targetAndActualValues)
        {
            try
            {
                List<Entity> actualValues = targetAndActualValues
                    .Where(
                        t =>
                            t.GetAttributeValue<DateTime?>("msnfp_startdate") == period.StartDate &&
                            t.GetAttributeValue<DateTime?>("msnfp_enddate") == period.EndDate &&
                            t.GetOptionSetValue("msnfp_valuetype") == (int)IndicatorValueType.Actual)
                    .ToList();

                bool anyChildElement = false;
                foreach (Entity actualValue in actualValues)
                {
                    // Create actual element
                    anyChildElement = CreateResultIndicatorPeriodActualIndividualElement(xmlDocument, periodElement, actualValue) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/result/indicator/period/actual element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="periodElement"></param>
        /// <param name="actualValue"></param>
        private bool CreateResultIndicatorPeriodActualIndividualElement(XmlDocument xmlDocument, XmlElement periodElement, Entity actualValue)
        {
            try
            {
                Guid indicatorValueId = actualValue.Id;

                // Create actual element
                XmlElement actualElement = xmlDocument.CreateElement("actual");

                bool anyChildElement = false;

                // Create value attribute
                Money amount = actualValue.GetAttributeValue<Money>("msnfp_amount");
                decimal? percentage = actualValue.GetAttributeValue<decimal?>("msnfp_percentage");
                int? number = actualValue.GetAttributeValue<int?>("msnfp_number");
                if (amount != null)
                {
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, actualElement, "value", amount.Value, Constants.DecimalFormatTwoDecimalDigits);
                    anyChildElement = true;
                }
                else if (percentage != null)
                {
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, actualElement, "value", percentage.Value, Constants.DecimalFormatFiveDecimalDigits);
                    anyChildElement = true;
                }
                else if (number != null)
                {
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, actualElement, "value", number.Value);
                    anyChildElement = true;
                }

                // Create location elements
                anyChildElement = CreateIndicatorValueLocationElements(xmlDocument, actualElement, indicatorValueId) || anyChildElement;

                // Create dimension elements
                anyChildElement = CreateIndicatorValueDimensionElements(xmlDocument, actualElement, indicatorValueId) || anyChildElement;

                // Create comment element
                anyChildElement = CreateIndicatorValueCommentElement(xmlDocument, actualElement, actualValue, indicatorValueId) || anyChildElement;

                // Create document-link elements
                anyChildElement =
                    CommonUtilities.CreateDocumentLinkElements(_service, _tracingService, _exceptionLog, xmlDocument, actualElement, indicatorValueId,
                        Constants.ConnectionRoleDocumentLinkToIndicatorValue, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    periodElement.AppendChild(actualElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create indicator value location elements (for baseline, target and actual elements)
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="indicatorValueId"></param>
        private bool CreateIndicatorValueLocationElements(XmlDocument xmlDocument, XmlElement parentElement, Guid indicatorValueId)
        {
            try
            {
                // Build query to fetch data
                var indicatorValueLocationQueryExpression = new QueryExpression("msiati_indicatorvaluelocation")
                {
                    ColumnSet = new ColumnSet(),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_indicatorvalueid", ConditionOperator.Equal, indicatorValueId)
                        }
                    },
                    LinkEntities =
                    {
                        // Indicator Code
                        new LinkEntity(
                            "msiati_indicatorvaluelocation",
                            "msiati_location",
                            "msiati_locationid",
                            "msiati_locationid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "Location",
                            Columns = new ColumnSet("msiati_reference")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> indicatorValueLocations = _service.RetrieveMultiple(indicatorValueLocationQueryExpression).Entities;
                foreach (Entity indicatorValueLocation in indicatorValueLocations)
                {
                    // Create location element
                    anyChildElement = CreateIndicatorValueLocationIndividualElement(xmlDocument, parentElement, indicatorValueLocation) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual indicator value location element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="indicatorValueLocation"></param>
        private bool CreateIndicatorValueLocationIndividualElement(XmlDocument xmlDocument, XmlElement parentElement, Entity indicatorValueLocation)
        {
            try
            {
                string @ref = indicatorValueLocation.GetAliasedValue<string>("Location.msiati_reference");
                if (!string.IsNullOrWhiteSpace(@ref))
                {
                    // Create location element
                    XmlElement locationElement = XmlUtilities.CreateChildXmlElement(xmlDocument, parentElement, "location");

                    // Create ref attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, locationElement, "ref", @ref);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create indicator value comment element (for baseline, target and actual elements)
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="indicatorValue"></param>
        /// <param name="indicatorValueId"></param>
        private bool CreateIndicatorValueCommentElement(XmlDocument xmlDocument, XmlElement parentElement, Entity indicatorValue, Guid indicatorValueId)
        {
            try
            {
                // Create comment and narrative elements
                return CommonUtilities.CreateNarrativeElements(_service, xmlDocument, parentElement, indicatorValue, "msnfp_description", false, indicatorValueId,
                    NarrativeTranslationEntity.IndicatorValue, NarrativeTranslationAttribute.Description, true, "comment");
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create indicator value dimension elements (for baseline, target and actual elements)
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="indicatorValueId"></param>
        private bool CreateIndicatorValueDimensionElements(XmlDocument xmlDocument, XmlElement parentElement, Guid indicatorValueId)
        {
            try
            {
                // Build query to fetch data
                var indicatorValueDimensionQueryExpression = new QueryExpression("msiati_dimension")
                {
                    ColumnSet = new ColumnSet("msiati_name", "msiati_value"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_indicatorvalueid", ConditionOperator.Equal, indicatorValueId)
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> indicatorValueDimensions = _service.RetrieveMultiple(indicatorValueDimensionQueryExpression).Entities;
                foreach (Entity indicatorValueDimension in indicatorValueDimensions)
                {
                    // Create dimension element
                    anyChildElement = CreateIndicatorValueDimensionIndividualElement(xmlDocument, parentElement, indicatorValueDimension) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual indicator value dimension element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="indicatorValueDimension"></param>
        private bool CreateIndicatorValueDimensionIndividualElement(XmlDocument xmlDocument, XmlElement parentElement, Entity indicatorValueDimension)
        {
            try
            {
                // Create dimension element
                XmlElement dimensionElement = xmlDocument.CreateElement("dimension");

                // Create name attribute
                string name = indicatorValueDimension.GetAttributeValue<string>("msiati_name");
                bool anyChildElement = !string.IsNullOrWhiteSpace(name);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, dimensionElement, "name", name);

                // Create value attribute
                string value = indicatorValueDimension.GetAttributeValue<string>("msiati_value");
                anyChildElement = !string.IsNullOrWhiteSpace(value) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, dimensionElement, "value", value);

                // If any child element, add parent
                if (anyChildElement)
                {
                    parentElement.AppendChild(dimensionElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region crs-add

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <param name="deliveryFrameworkAdditionalDetail"></param>
        /// <param name="deliveryFrameworkId"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateCrsAddElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework, Entity deliveryFrameworkAdditionalDetail,
            Guid deliveryFrameworkId, string defaultCurrencyCode)
        {
            try
            {
                // Create crs-add element
                XmlElement crsAddElement = xmlDocument.CreateElement("crs-add");

                // Create other-flags elements
                bool anyChildElement = CreateCrsAddOtherFlagsElements(xmlDocument, crsAddElement, deliveryFrameworkId);

                // Create loan-terms elements
                anyChildElement = CreateCrsAddLoanTermsElement(xmlDocument, crsAddElement, deliveryFramework, deliveryFrameworkAdditionalDetail) || anyChildElement;

                // Create loan-status elements
                anyChildElement =
                    CreateCrsAddLoanStatusElement(xmlDocument, crsAddElement, deliveryFramework, deliveryFrameworkAdditionalDetail, defaultCurrencyCode) || anyChildElement;

                // Create channel-code element
                anyChildElement = CreateCrsAddChannelCodeElement(xmlDocument, crsAddElement, deliveryFrameworkAdditionalDetail) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(crsAddElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add/other-flags elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="crsAddElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        private bool CreateCrsAddOtherFlagsElements(XmlDocument xmlDocument, XmlElement crsAddElement, Guid deliveryFrameworkId)
        {
            try
            {
                // Build query to fetch data
                var crsAdditionalOtherFlagQueryExpression = new QueryExpression("msiati_crsotherflag")
                {
                    ColumnSet = new ColumnSet(),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId),
                            new ConditionExpression("msiati_flagapplies", ConditionOperator.Equal, true)
                        }
                    },
                    LinkEntities =
                    {
                        // CRS Additional Other Flags
                        new LinkEntity(
                            "msiati_crsotherflag",
                            "msiati_nonembeddedcodelist",
                            "msiati_crsadditionalotherflagsid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "CRSAddOtherFlags",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> crsOtherFlags = _service.RetrieveMultiple(crsAdditionalOtherFlagQueryExpression).Entities;
                foreach (Entity crsOtherFlag in crsOtherFlags)
                {
                    // Create other-flags element
                    anyChildElement = CreateCrsAddOtherFlagsIndividualElement(xmlDocument, crsAddElement, crsOtherFlag) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/crs-add/other-flags element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="crsAddElement"></param>
        /// <param name="crsOtherFlag"></param>
        private bool CreateCrsAddOtherFlagsIndividualElement(XmlDocument xmlDocument, XmlElement crsAddElement, Entity crsOtherFlag)
        {
            try
            {
                string code = crsOtherFlag.GetAliasedValue<string>("CRSAddOtherFlags.msiati_code");
                if (!string.IsNullOrWhiteSpace(code))
                {
                    // Create other-flags element
                    XmlElement otherFlagsElement = XmlUtilities.CreateChildXmlElement(xmlDocument, crsAddElement, "other-flags");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, otherFlagsElement, "code", code);

                    // Create significance attribute
                    // Always 1 since flags that don't apply shouldn't be reported
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, otherFlagsElement, "significance", "1");

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add/loan-terms element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="crsAddElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <param name="deliveryFrameworkAdditionalDetail"></param>
        /// <returns></returns>
        private bool CreateCrsAddLoanTermsElement(XmlDocument xmlDocument, XmlElement crsAddElement, Entity deliveryFramework, Entity deliveryFrameworkAdditionalDetail)
        {
            try
            {
                // Create loan-terms element
                XmlElement loanTermsElement = xmlDocument.CreateElement("loan-terms");

                // Create rate-1 attribute
                decimal? rate1 = deliveryFramework.GetAttributeValue<decimal?>("msiati_crsloanrate1");
                bool anyChildElement = rate1 != null;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, loanTermsElement, "rate-1", rate1, Constants.DecimalFormatTwoDecimalDigits);

                // Create rate-2 attribute
                decimal? rate2 = deliveryFramework.GetAttributeValue<decimal?>("msiati_crsloanrate2");
                anyChildElement = rate2 != null || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, loanTermsElement, "rate-2", rate2, Constants.DecimalFormatTwoDecimalDigits);

                // Create repayment-type element
                anyChildElement = CreateCrsAddLoanTermsRepaymentTypeElement(xmlDocument, loanTermsElement, deliveryFrameworkAdditionalDetail) || anyChildElement;

                // Create repayment-plan element
                anyChildElement = CreateCrsAddLoanTermsRepaymentPlanElement(xmlDocument, loanTermsElement, deliveryFrameworkAdditionalDetail) || anyChildElement;

                // Create commitment-date element
                anyChildElement = CreateCrsAddLoanTermsCommitmentDateElement(xmlDocument, loanTermsElement, deliveryFramework) || anyChildElement;

                // Create repayment-first-date element
                anyChildElement = CreateCrsAddLoanTermsRepaymentFirstDateElement(xmlDocument, loanTermsElement, deliveryFramework) || anyChildElement;

                // Create repayment-final-date element
                anyChildElement = CreateCrsAddLoanTermsRepaymentFinalDateElement(xmlDocument, loanTermsElement, deliveryFramework) || anyChildElement;

                // If there are any child elements, add the parent
                if (anyChildElement)
                {
                    crsAddElement.AppendChild(loanTermsElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add/loan-terms/repayment-type element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="loanTermsElement"></param>
        /// <param name="deliveryFrameworkAdditionalDetail"></param>
        /// <returns></returns>
        private bool CreateCrsAddLoanTermsRepaymentTypeElement(XmlDocument xmlDocument, XmlElement loanTermsElement, Entity deliveryFrameworkAdditionalDetail)
        {
            try
            {
                string loanRepaymentTypeCode = deliveryFrameworkAdditionalDetail?.GetAliasedValue<string>("LoanRepaymentType.msiati_code");
                if (!string.IsNullOrWhiteSpace(loanRepaymentTypeCode))
                {
                    // Create repayment-type element
                    XmlElement repaymentTypeElement = XmlUtilities.CreateChildXmlElement(xmlDocument, loanTermsElement, "repayment-type");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, repaymentTypeElement, "code", loanRepaymentTypeCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add/loan-terms/repayment-plan element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="loanTermsElement"></param>
        /// <param name="deliveryFrameworkAdditionalDetail"></param>
        /// <returns></returns>
        private bool CreateCrsAddLoanTermsRepaymentPlanElement(XmlDocument xmlDocument, XmlElement loanTermsElement, Entity deliveryFrameworkAdditionalDetail)
        {
            try
            {
                string loanRepaymentPeriodCode = deliveryFrameworkAdditionalDetail?.GetAliasedValue<string>("LoanRepaymentPeriod.msiati_code");
                if (!string.IsNullOrWhiteSpace(loanRepaymentPeriodCode))
                {
                    // Create repayment-plan element
                    XmlElement repaymentPlanElement = XmlUtilities.CreateChildXmlElement(xmlDocument, loanTermsElement, "repayment-plan");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, repaymentPlanElement, "code", loanRepaymentPeriodCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add/loan-terms/commitment-date element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="loanTermsElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <returns></returns>
        private bool CreateCrsAddLoanTermsCommitmentDateElement(XmlDocument xmlDocument, XmlElement loanTermsElement, Entity deliveryFramework)
        {
            try
            {
                DateTime? commitmentDate = deliveryFramework.GetAttributeValue<DateTime?>("msiati_crscommitmentdate");
                if (commitmentDate != null)
                {
                    // Create commitment-date element
                    XmlElement commitmentDateElement = XmlUtilities.CreateChildXmlElement(xmlDocument, loanTermsElement, "commitment-date");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, commitmentDateElement, "iso-date", commitmentDate, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add/loan-terms/repayment-first-date element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="loanTermsElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <returns></returns>
        private bool CreateCrsAddLoanTermsRepaymentFirstDateElement(XmlDocument xmlDocument, XmlElement loanTermsElement, Entity deliveryFramework)
        {
            try
            {
                DateTime? repaymentFirstDate = deliveryFramework.GetAttributeValue<DateTime?>("msiati_crsrepaymentfirstdate");
                if (repaymentFirstDate != null)
                {
                    // Create repayment-first-date element
                    XmlElement commitmentDateElement = XmlUtilities.CreateChildXmlElement(xmlDocument, loanTermsElement, "repayment-first-date");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, commitmentDateElement, "iso-date", repaymentFirstDate, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add/loan-terms/repayment-final-date element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="loanTermsElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <returns></returns>
        private bool CreateCrsAddLoanTermsRepaymentFinalDateElement(XmlDocument xmlDocument, XmlElement loanTermsElement, Entity deliveryFramework)
        {
            try
            {
                DateTime? repaymentFinalDate = deliveryFramework.GetAttributeValue<DateTime?>("msiati_crsrepaymentfinaldate");
                if (repaymentFinalDate != null)
                {
                    // Create repayment-final-date element
                    XmlElement commitmentDateElement = XmlUtilities.CreateChildXmlElement(xmlDocument, loanTermsElement, "repayment-final-date");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, commitmentDateElement, "iso-date", repaymentFinalDate, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add/loan-status element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="crsAddElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <param name="deliveryFrameworkAdditionalDetail"></param>
        /// <param name="defaultCurrencyCode"></param>
        /// <returns></returns>
        private bool CreateCrsAddLoanStatusElement(XmlDocument xmlDocument, XmlElement crsAddElement, Entity deliveryFramework, Entity deliveryFrameworkAdditionalDetail,
            string defaultCurrencyCode)
        {
            try
            {
                // Create loan-status element
                XmlElement loanStatusElement = xmlDocument.CreateElement("loan-status");

                // Create year attribute
                int? year = deliveryFramework.GetAttributeValue<int?>("msiati_crsreportingyear");
                bool anyChildElement = year != null;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, loanStatusElement, "year", year);

                // Create currency attribute (if different from default currency)
                CommonUtilities.CreateCurrencyAttribute(xmlDocument, loanStatusElement, deliveryFrameworkAdditionalDetail, "Currency.isocurrencycode", true, defaultCurrencyCode);

                // Create value-date attribute
                DateTime? valueDate = deliveryFramework.GetAttributeValue<DateTime?>("msiati_currencyvaluedate");
                anyChildElement = valueDate != null || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, loanStatusElement, "value-date", valueDate, Constants.DateFormatDateOnly);

                // Create interest-received element
                anyChildElement = CreateCrsAddLoanStatusInterestReceivedElement(xmlDocument, loanStatusElement, deliveryFramework) || anyChildElement;

                // Create principal-outstanding element
                anyChildElement = CreateCrsAddLoanStatusPrincipalOutstandingElement(xmlDocument, loanStatusElement, deliveryFramework) || anyChildElement;

                // Create principal-arrears element
                anyChildElement = CreateCrsAddLoanStatusPrincipalArrearsElement(xmlDocument, loanStatusElement, deliveryFramework) || anyChildElement;

                // Create interest-arrears element
                anyChildElement = CreateCrsAddLoanStatusInterestArrearsElement(xmlDocument, loanStatusElement, deliveryFramework) || anyChildElement;

                // If there are any child elements, add the parent
                if (anyChildElement)
                {
                    crsAddElement.AppendChild(loanStatusElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add/loan-terms/interest-received element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="loanStatusElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <returns></returns>
        private bool CreateCrsAddLoanStatusInterestReceivedElement(XmlDocument xmlDocument, XmlElement loanStatusElement, Entity deliveryFramework)
        {
            try
            {
                Money interesetReceived = deliveryFramework.GetAttributeValue<Money>("msiati_crsinterestreceived");
                if (interesetReceived != null)
                {
                    // Create interest-received element
                    XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, loanStatusElement, "interest-received", interesetReceived.Value,
                        Constants.DecimalFormatTwoDecimalDigits);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add/loan-terms/principal-outstanding element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="loanStatusElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <returns></returns>
        private bool CreateCrsAddLoanStatusPrincipalOutstandingElement(XmlDocument xmlDocument, XmlElement loanStatusElement, Entity deliveryFramework)
        {
            try
            {
                Money principalOutstanding = deliveryFramework.GetAttributeValue<Money>("msiati_crsprincipaloutstanding");
                if (principalOutstanding != null)
                {
                    // Create principal-outstanding element
                    XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, loanStatusElement, "principal-outstanding", principalOutstanding.Value,
                        Constants.DecimalFormatTwoDecimalDigits);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add/loan-terms/principal-arrears element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="loanStatusElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <returns></returns>
        private bool CreateCrsAddLoanStatusPrincipalArrearsElement(XmlDocument xmlDocument, XmlElement loanStatusElement, Entity deliveryFramework)
        {
            try
            {
                Money principalArrears = deliveryFramework.GetAttributeValue<Money>("msiati_crsprincipalarrears");
                if (principalArrears != null)
                {
                    // Create principal-arrears element
                    XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, loanStatusElement, "principal-arrears", principalArrears.Value,
                        Constants.DecimalFormatTwoDecimalDigits);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add/loan-terms/interest-arrears element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="loanStatusElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <returns></returns>
        private bool CreateCrsAddLoanStatusInterestArrearsElement(XmlDocument xmlDocument, XmlElement loanStatusElement, Entity deliveryFramework)
        {
            try
            {
                Money interestArrears = deliveryFramework.GetAttributeValue<Money>("msiati_crsinterestarrears");
                if (interestArrears != null)
                {
                    // Create interest-arrears element
                    XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, loanStatusElement, "interest-arrears", interestArrears.Value,
                        Constants.DecimalFormatTwoDecimalDigits);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/crs-add/channel-code element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="loanStatusElement"></param>
        /// <param name="deliveryFrameworkAdditionalDetail"></param>
        /// <returns></returns>
        private bool CreateCrsAddChannelCodeElement(XmlDocument xmlDocument, XmlElement loanStatusElement, Entity deliveryFrameworkAdditionalDetail)
        {
            try
            {
                string crsChannelCode = deliveryFrameworkAdditionalDetail?.GetAliasedValue<string>("CRSChannel.msiati_code");
                if (crsChannelCode != null)
                {
                    // Create channel-code element
                    XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, loanStatusElement, "channel-code", crsChannelCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region fss

        /// <summary>
        /// Create iati-activities/iati-activity/fss element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="iatiActivityElement"></param>
        /// <param name="deliveryFramework"></param>
        /// <param name="deliveryFrameworkId"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateFssElement(XmlDocument xmlDocument, XmlElement iatiActivityElement, Entity deliveryFramework, Guid deliveryFrameworkId, string defaultCurrencyCode)
        {
            try
            {
                // Create fss element
                XmlElement fssElement = xmlDocument.CreateElement("fss");

                // Create extraction-date attribute
                DateTime? extractionDate = deliveryFramework.GetAttributeValue<DateTime?>("msiati_fssextractiondate");
                bool anyChildElement = extractionDate != null;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, fssElement, "extraction-date", extractionDate, Constants.DateFormatDateOnly);

                // Create priority attribute
                bool? isPriority = deliveryFramework.GetAttributeValue<bool?>("msiati_fsspriority");
                string priority = isPriority == true ? "1" : "0";
                anyChildElement = isPriority == true || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, fssElement, "priority", priority);

                // Create phaseout-year attribute
                int? phaseoutYear = deliveryFramework.GetAttributeValue<int?>("msiati_fssphaseoutyear");
                anyChildElement = phaseoutYear != null || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, fssElement, "phaseout-year", phaseoutYear);

                // Create forecast elements
                anyChildElement = CreateFssForecastElements(xmlDocument, fssElement, deliveryFrameworkId, defaultCurrencyCode) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    iatiActivityElement.AppendChild(fssElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create iati-activities/iati-activity/fss/forecast elements
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="fssElement"></param>
        /// <param name="deliveryFrameworkId"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateFssForecastElements(XmlDocument xmlDocument, XmlElement fssElement, Guid deliveryFrameworkId, string defaultCurrencyCode)
        {
            try
            {
                // Build query to fetch data
                var fssForecastQueryExpression = new QueryExpression("msiati_fssforecast")
                {
                    ColumnSet = new ColumnSet("msiati_amount", "msiati_year", "msiati_currencyvaluedate"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_deliveryframeworkid", ConditionOperator.Equal, deliveryFrameworkId)
                        }
                    },
                    LinkEntities =
                    {
                        // Currency
                        new LinkEntity(
                            "msiati_fssforecast",
                            "transactioncurrency",
                            "transactioncurrencyid",
                            "transactioncurrencyid",
                            JoinOperator.LeftOuter)
                        {
                            Columns = new ColumnSet("isocurrencycode"),
                            EntityAlias = "Currency"
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> fssForecasts = _service.RetrieveMultiple(fssForecastQueryExpression).Entities;
                foreach (Entity fssForecast in fssForecasts)
                {
                    // Create forecast element
                    anyChildElement = CreateFssForecastIndividualElement(xmlDocument, fssElement, fssForecast, defaultCurrencyCode) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual iati-activities/iati-activity/fss/forecast element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="fssElement"></param>
        /// <param name="fssForecast"></param>
        /// <param name="defaultCurrencyCode"></param>
        private bool CreateFssForecastIndividualElement(XmlDocument xmlDocument, XmlElement fssElement, Entity fssForecast, string defaultCurrencyCode)
        {
            try
            {
                // Create forecast element
                XmlElement forecastElement = xmlDocument.CreateElement("forecast");

                bool anyChildElement = false;

                // Set amount value (inner text)
                Money amount = fssForecast.GetAttributeValue<Money>("msiati_amount");
                if (amount != null)
                {
                    forecastElement.InnerText = amount.Value.ToString(Constants.DecimalFormatTwoDecimalDigits);
                    anyChildElement = true;
                }

                // Create year attribute
                int? year = fssForecast.GetAttributeValue<int?>("msiati_year");
                anyChildElement = year != null || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, forecastElement, "year", year);

                // Create currency attribute
                CommonUtilities.CreateCurrencyAttribute(xmlDocument, forecastElement, fssForecast, "Currency.isocurrencycode", true, defaultCurrencyCode);

                // Create value-date attribute
                DateTime? valueDate = fssForecast.GetAttributeValue<DateTime?>("msiati_currencyvaluedate");
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, forecastElement, "value-date", valueDate, Constants.DateFormatDateOnly);

                // If any child element, add parent
                if (anyChildElement)
                {
                    fssElement.AppendChild(forecastElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                CommonUtilities.LogException(_exceptionLog, _tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #endregion
    }
}
