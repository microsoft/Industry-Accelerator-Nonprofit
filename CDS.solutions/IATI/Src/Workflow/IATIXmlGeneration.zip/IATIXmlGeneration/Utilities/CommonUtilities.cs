﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml;
using IATIXmlGeneration.Containers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace IATIXmlGeneration.Utilities
{
    public static class CommonUtilities
    {
        #region Notes

        /// <summary>
        /// Create a note
        /// </summary>
        /// <param name="service"></param>
        /// <param name="relatedEntityLogicalName"></param>
        /// <param name="relatedEntityId"></param>
        /// <param name="subject"></param>
        /// <param name="mimeType"></param>
        /// <param name="noteText"></param>
        /// <param name="fileName"></param>
        /// <param name="documentBody"></param>
        public static void CreateNoteWithAttachment(IOrganizationService service, string relatedEntityLogicalName, Guid relatedEntityId,
            string subject = null, string mimeType = null, string noteText = null, string fileName = null, string documentBody = null)
        {
            Entity annotation = new Entity("annotation")
            {
                ["objectid"] = new EntityReference(relatedEntityLogicalName, relatedEntityId),
                ["objecttypecode"] = relatedEntityLogicalName
            };

            if (!string.IsNullOrWhiteSpace(subject))
            {
                annotation["subject"] = subject;
            }

            if (!string.IsNullOrWhiteSpace(mimeType))
            {
                annotation["mimetype"] = mimeType;
            }

            if (!string.IsNullOrWhiteSpace(noteText))
            {
                annotation["notetext"] = noteText;
            }

            if (!string.IsNullOrWhiteSpace(fileName))
            {
                annotation["filename"] = fileName;
            }

            if (!string.IsNullOrWhiteSpace(documentBody))
            {
                annotation["documentbody"] = documentBody;
            }

            service.Create(annotation);
        }

        #endregion

        #region Exception Logging

        /// <summary>
        /// 
        /// </summary>
        /// <param name="exceptionLog"></param>
        /// <param name="tracingService"></param>
        /// <param name="exceptionMethod"></param>
        /// <param name="exception"></param>
        public static void LogException(List<ExceptionLogEntry> exceptionLog, ITracingService tracingService, string exceptionMethod, Exception exception)
        {
            try
            {
                exceptionLog.Add(new ExceptionLogEntry(DateTime.Now, exception.Message, exception.StackTrace));
                tracingService.Trace($"Error in {exceptionMethod}. {Environment.NewLine}Exception: {exception.Message}");
            }
            catch (Exception)
            {
                // Do nothing if exceptions fail to log
                return;
            }
        }

        /// <summary>
        /// Create note with exception log
        /// </summary>
        /// <param name="exceptionLog"></param>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="relatedEntityLogicalName"></param>
        /// <param name="relatedEntityId"></param>
        /// <param name="noteSubject"></param>
        /// <param name="noteText"></param>
        public static void CreateExceptionLogNote(List<ExceptionLogEntry> exceptionLog, IOrganizationService service, ITracingService tracingService,
            string relatedEntityLogicalName, Guid relatedEntityId, string noteSubject = "Exception Log", string noteText = "Log of process exceptions")
        {
            try
            {
                if (exceptionLog == null || !exceptionLog.Any())
                {
                    return;
                }

                tracingService.Trace("Creating exception log file");

                StringBuilder stringBuilder = new StringBuilder($"Exceptions:{Environment.NewLine}");
                foreach (ExceptionLogEntry exceptionLogEntry in exceptionLog.OrderBy(t => t.ExceptionDate))
                {
                    stringBuilder.AppendLine("");
                    stringBuilder.Append($"{exceptionLogEntry.ExceptionDate:yyyy-MM-dd HH:mm:ss tt}: {exceptionLogEntry.ExceptionMessage}");
                    stringBuilder.AppendLine(exceptionLogEntry.ExceptionStackTrace);
                }

                string logContent = Convert.ToBase64String(Encoding.ASCII.GetBytes(stringBuilder.ToString()));

                CreateNoteWithAttachment(service, relatedEntityLogicalName, relatedEntityId, noteSubject, Constants.MimeTypeTxt, noteText,
                    $"Exception Log {DateTime.Now:yyyyMMddHHmmss}.txt", logContent);

                tracingService.Trace("Exceptions log file created");
            }
            catch (Exception)
            {
                tracingService.Trace("Failed to log exceptions");
            }
        }

        #endregion

        #region Narrative

        /// <summary>
        /// Get narrative translations for a specific entity and attribute. If no attribute is specified, all 
        /// translations for the entity are returned
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entityId"></param>
        /// <param name="lookupEntity"></param>
        /// <param name="narrativeTranslationAttribute"></param>
        /// <returns></returns>
        public static List<Entity> GetEntityNarrativeTranslations(IOrganizationService service, Guid entityId, NarrativeTranslationEntity lookupEntity,
            NarrativeTranslationAttribute narrativeTranslationAttribute = NarrativeTranslationAttribute.Undefined)
        {
            // Build the Narrative Translation entity query
            var narrativeTranslationQueryExpression = new QueryExpression("msiati_narrativetranslation")
            {
                ColumnSet = new ColumnSet("msiati_attribute", "msiati_translation"),
            };

            var entityNameCondition = new ConditionExpression
            {
                AttributeName = Constants.NarrativeTranslationEntityLookupMapping[lookupEntity],
                Operator = ConditionOperator.Equal
            };
            entityNameCondition.Values.Add(entityId);

            var filterExpression = new FilterExpression();
            filterExpression.Conditions.Add(entityNameCondition);
            narrativeTranslationQueryExpression.Criteria.AddFilter(filterExpression);

            // If a specific attribute was passed, only get translations for that attribute
            if (narrativeTranslationAttribute != NarrativeTranslationAttribute.Undefined)
            {
                var attributeCondition = new ConditionExpression
                {
                    AttributeName = "msiati_attribute",
                    Operator = ConditionOperator.Equal
                };
                attributeCondition.Values.Add((int)narrativeTranslationAttribute);

                filterExpression.Conditions.Add(attributeCondition);
                narrativeTranslationQueryExpression.Criteria.AddFilter(filterExpression);
            }

            LinkEntity languageLinkEntity = new LinkEntity(
                "msiati_narrativetranslation",
                "msiati_nonembeddedcodelist",
                "msiati_languageid",
                "msiati_nonembeddedcodelistid",
                JoinOperator.Inner)
            {
                EntityAlias = "Language",
                Columns = new ColumnSet("msiati_code")
            };
            narrativeTranslationQueryExpression.LinkEntities.Add(languageLinkEntity);

            // Get narrative translations
            List<Entity> list =
                service.RetrieveMultiple(narrativeTranslationQueryExpression).Entities
                    .OrderBy(t => t.GetOptionSetValue("msiati_attribute"))
                    .ThenBy(t => t.GetAliasedValue<string>("Language.msiati_code"))
                    .ToList();

            return list;
        }

        /// <summary>
        /// Create narrative elements for a specific attribute
        /// </summary>
        /// <param name="service"></param>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="mainNarrative"></param>
        /// <param name="narrativeEntityId"></param>
        /// <param name="narrativeTranslationEntity"></param>
        /// <param name="narrativeTranslationAttribute"></param>
        /// <param name="createGroupingElement"></param>
        /// <param name="groupingElementName"></param>
        public static bool CreateNarrativeElements(IOrganizationService service, XmlDocument xmlDocument, XmlElement parentElement, string mainNarrative, Guid narrativeEntityId,
            NarrativeTranslationEntity narrativeTranslationEntity, NarrativeTranslationAttribute narrativeTranslationAttribute, bool createGroupingElement,
            string groupingElementName = null)
        {
            List<Entity> narrativeTranslations = GetEntityNarrativeTranslations(service, narrativeEntityId, narrativeTranslationEntity, narrativeTranslationAttribute);
            return CreateNarrativeElements(xmlDocument, parentElement, mainNarrative, narrativeTranslations, createGroupingElement, groupingElementName);
        }

        /// <summary>
        /// Create an individual narrative translation element
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="narrativeTranslation"></param>
        public static void CreateNarrativeTranslationIndividualElement(XmlDocument xmlDocument, XmlElement parentElement, Entity narrativeTranslation)
        {
            // If the translation contains text, add it to the XML
            string translation = narrativeTranslation.GetAttributeValue<string>("msiati_translation");
            if (!string.IsNullOrWhiteSpace(translation))
            {
                XmlElement narrativeElement = XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, parentElement, "narrative", translation);

                // Create xml:lang attribute
                string languageCode = narrativeTranslation.GetAliasedValue<string>("Language.msiati_code");
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, narrativeElement, "xml:lang", languageCode);
            }
        }

        /// <summary>
        /// Create narrative elements for a specific attribute
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="mainNarrative"></param>
        /// <param name="narrativeTranslations"></param>
        /// <param name="createGroupingElement"></param>
        /// <param name="groupingElementName"></param>
        private static bool CreateNarrativeElements(XmlDocument xmlDocument, XmlElement parentElement, string mainNarrative, List<Entity> narrativeTranslations,
            bool createGroupingElement, string groupingElementName = null)
        {
            bool anyChildElement = false;

            // If there is a narrative text, or if there are translations, add them to the XML
            if (!string.IsNullOrWhiteSpace(mainNarrative) || narrativeTranslations.Any())
            {
                anyChildElement = true;

                XmlElement groupingElement = parentElement;
                if (createGroupingElement && !string.IsNullOrWhiteSpace(groupingElementName))
                {
                    groupingElement = XmlUtilities.CreateChildXmlElement(xmlDocument, parentElement, groupingElementName);
                }

                XmlUtilities.CreateChildXmlElementWithInnerTextIfValueNotNull(xmlDocument, groupingElement, "narrative", mainNarrative);

                foreach (Entity narrativeTranslation in narrativeTranslations)
                {
                    // Create narrative element
                    CreateNarrativeTranslationIndividualElement(xmlDocument, groupingElement, narrativeTranslation);
                }
            }

            return anyChildElement;
        }

        /// <summary>
        /// Create narrative elements for a specific attribute
        /// </summary>
        /// <param name="service"></param>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="entityWithNarrative"></param>
        /// <param name="narrativeAttributeLogicalName"></param>
        /// <param name="isAliased"></param>
        /// <param name="narrativeEntityId"></param>
        /// <param name="narrativeTranslationEntity"></param>
        /// <param name="narrativeTranslationAttribute"></param>
        /// <param name="createGroupingElement"></param>
        /// <param name="groupingElementName"></param>
        public static bool CreateNarrativeElements(IOrganizationService service, XmlDocument xmlDocument, XmlElement parentElement, Entity entityWithNarrative,
            string narrativeAttributeLogicalName, bool isAliased, Guid narrativeEntityId, NarrativeTranslationEntity narrativeTranslationEntity,
            NarrativeTranslationAttribute narrativeTranslationAttribute, bool createGroupingElement, string groupingElementName = null)
        {
            string narrative = isAliased
                ? entityWithNarrative.GetAliasedValue<string>(narrativeAttributeLogicalName)
                : entityWithNarrative.GetAttributeValue<string>(narrativeAttributeLogicalName);

            return CreateNarrativeElements(service, xmlDocument, parentElement, narrative, narrativeEntityId, narrativeTranslationEntity, narrativeTranslationAttribute,
                createGroupingElement, groupingElementName);
        }

        #endregion

        #region Currency

        /// <summary>
        /// Create currency attributes (if transaction currency is different to default currency)
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="entityWithCurrencyAttribute"></param>
        /// <param name="attributeKey"></param>
        /// <param name="isAliased"></param>
        /// <param name="defaultCurrencyCode"></param>
        /// <param name="attributeName"></param>
        public static void CreateCurrencyAttribute(XmlDocument xmlDocument, XmlElement parentElement, Entity entityWithCurrencyAttribute, string attributeKey, bool isAliased,
            string defaultCurrencyCode, string attributeName = "currency")
        {
            // Create currency attribute
            string currencyCode = isAliased
                ? entityWithCurrencyAttribute?.GetAliasedValue<string>(attributeKey)
                : entityWithCurrencyAttribute?.GetAttributeValue<string>(attributeKey);

            CreateCurrencyAttribute(xmlDocument, parentElement, currencyCode, defaultCurrencyCode, attributeName);
        }

        /// <summary>
        /// Create currency attributes (if transaction currency is different to default currency)
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="currencyCode"></param>
        /// <param name="defaultCurrencyCode"></param>
        /// <param name="attributeName"></param>
        public static void CreateCurrencyAttribute(XmlDocument xmlDocument, XmlElement parentElement, string currencyCode, string defaultCurrencyCode, string attributeName = "currency")
        {
            if (!string.IsNullOrWhiteSpace(currencyCode) && currencyCode != defaultCurrencyCode)
            {
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, parentElement, attributeName, currencyCode);
            }
        }

        #endregion

        #region Document Link

        /// <summary>
        /// Create document-link elements (for different elements; e.g. iati-activity, baseline, target, actual, etc.)
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="exceptionLog"></param>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="relatedEntityId"></param>
        /// <param name="connectionRoleName"></param>
        /// <param name="isOrganizationStandard"></param>
        public static bool CreateDocumentLinkElements(IOrganizationService service, ITracingService tracingService, List<ExceptionLogEntry> exceptionLog, XmlDocument xmlDocument,
            XmlElement parentElement, Guid relatedEntityId, string connectionRoleName, bool isOrganizationStandard)
        {
            try
            {
                // Build query to fetch data
                var connectionQueryExpression = new QueryExpression("connection")
                {
                    ColumnSet = new ColumnSet(),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("record1id", ConditionOperator.Equal, relatedEntityId)
                        }
                    },
                    LinkEntities =
                    {
                        // Connection Role
                        new LinkEntity(
                            "connection",
                            "connectionrole",
                            "record1roleid",
                            "connectionroleid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "ConnectionRole",
                            Columns = new ColumnSet("name"),
                            LinkCriteria = new FilterExpression
                            {
                                Conditions =
                                {
                                    new ConditionExpression("name", ConditionOperator.Equal, connectionRoleName)
                                }
                            }
                        },
                        // Document Link
                        new LinkEntity(
                            "connection",
                            "msiati_documentlink",
                            "record2id",
                            "msiati_documentlinkid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "DocumentLink",
                            Columns = new ColumnSet("msiati_documentlinkid", "msiati_name", "msiati_description", "msiati_url", "msiati_publicationdate"),
                            LinkEntities =
                            {
                                // File Format
                                new LinkEntity(
                                    "msiati_documentlink",
                                    "msiati_nonembeddedcodelist",
                                    "msiati_fileformatid",
                                    "msiati_nonembeddedcodelistid",
                                    JoinOperator.LeftOuter)
                                {
                                    EntityAlias = "FileFormat",
                                    Columns = new ColumnSet("msiati_code")
                                }
                            }
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> documentLinkConnections = service.RetrieveMultiple(connectionQueryExpression).Entities;
                foreach (Entity documentLinkConnection in documentLinkConnections)
                {
                    // Create document-link element
                    anyChildElement =
                        CreateDocumentLinkIndividualElement(service, tracingService, exceptionLog, xmlDocument, parentElement, documentLinkConnection, isOrganizationStandard) ||
                        anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                LogException(exceptionLog, tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual document-link element
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="exceptionLog"></param>
        /// <param name="xmlDocument"></param>
        /// <param name="parentElement"></param>
        /// <param name="documentLinkConnection"></param>
        /// <param name="isOrganizationStandard"></param>
        private static bool CreateDocumentLinkIndividualElement(IOrganizationService service, ITracingService tracingService, List<ExceptionLogEntry> exceptionLog,
            XmlDocument xmlDocument, XmlElement parentElement, Entity documentLinkConnection, bool isOrganizationStandard)
        {
            try
            {
                // Create document-link element
                XmlElement documentLinkElement = xmlDocument.CreateElement("document-link");

                // Create url attribute
                string url = documentLinkConnection.GetAliasedValue<string>("DocumentLink.msiati_url");
                bool anyChildElement = !string.IsNullOrWhiteSpace(url);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, documentLinkElement, "url", url);

                // Create format attribute
                string fileFormatCode = documentLinkConnection.GetAliasedValue<string>("FileFormat.msiati_code");
                anyChildElement = !string.IsNullOrWhiteSpace(fileFormatCode) || anyChildElement;
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, documentLinkElement, "format", fileFormatCode);

                Guid documentLinkId = documentLinkConnection.GetAliasedValue<Guid>("DocumentLink.msiati_documentlinkid");

                // Create title element
                anyChildElement =
                    CreateDocumentLinkTitleElement(service, tracingService, exceptionLog, xmlDocument, documentLinkElement, documentLinkConnection, documentLinkId) ||
                    anyChildElement;

                // Create description element
                anyChildElement =
                    CreateDocumentLinkDescriptionElement(service, tracingService, exceptionLog, xmlDocument, documentLinkElement, documentLinkConnection, documentLinkId) ||
                    anyChildElement;

                // Create category elements
                anyChildElement = CreateDocumentLinkCategoryElements(service, tracingService, exceptionLog, xmlDocument, documentLinkElement, documentLinkId) || anyChildElement;

                // Create language elements
                anyChildElement = CreateDocumentLinkLanguageElements(service, tracingService, exceptionLog, xmlDocument, documentLinkElement, documentLinkId) || anyChildElement;

                // Create document-date element
                anyChildElement = CreateDocumentLinkDocumentDateElement(tracingService, exceptionLog, xmlDocument, documentLinkElement, documentLinkConnection) || anyChildElement;

                if (isOrganizationStandard)
                {
                    // Create recipient-country element
                    anyChildElement =
                        CreateDocumentLinkRecipientCountryElements(service, tracingService, exceptionLog, xmlDocument, documentLinkElement, documentLinkId) ||
                        anyChildElement;
                }

                // If any child element, add parent
                if (anyChildElement)
                {
                    parentElement.AppendChild(documentLinkElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                LogException(exceptionLog, tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create document-link/title element
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="exceptionLog"></param>
        /// <param name="xmlDocument"></param>
        /// <param name="documentLinkElement"></param>
        /// <param name="documentLinkConnection"></param>
        /// <param name="documentLinkId"></param>
        private static bool CreateDocumentLinkTitleElement(IOrganizationService service, ITracingService tracingService, List<ExceptionLogEntry> exceptionLog,
            XmlDocument xmlDocument, XmlElement documentLinkElement, Entity documentLinkConnection, Guid documentLinkId)
        {
            try
            {
                // Create title/name narrative elements
                return CreateNarrativeElements(service, xmlDocument, documentLinkElement, documentLinkConnection, "DocumentLink.msiati_name", true, documentLinkId,
                    NarrativeTranslationEntity.DocumentLink, NarrativeTranslationAttribute.Name, true, "title");
            }
            catch (Exception ex)
            {
                LogException(exceptionLog, tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create document-link/description element
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="exceptionLog"></param>
        /// <param name="xmlDocument"></param>
        /// <param name="documentLinkElement"></param>
        /// <param name="documentLinkConnection"></param>
        /// <param name="documentLinkId"></param>
        private static bool CreateDocumentLinkDescriptionElement(IOrganizationService service, ITracingService tracingService, List<ExceptionLogEntry> exceptionLog,
            XmlDocument xmlDocument, XmlElement documentLinkElement, Entity documentLinkConnection, Guid documentLinkId)
        {
            try
            {
                // Create description narrative elements
                return CreateNarrativeElements(service, xmlDocument, documentLinkElement, documentLinkConnection, "DocumentLink.msiati_description", true, documentLinkId,
                    NarrativeTranslationEntity.DocumentLink, NarrativeTranslationAttribute.Description, true, "description");
            }
            catch (Exception ex)
            {
                LogException(exceptionLog, tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create document-link/category elements
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="exceptionLog"></param>
        /// <param name="xmlDocument"></param>
        /// <param name="documentLinkElement"></param>
        /// <param name="documentLinkId"></param>
        private static bool CreateDocumentLinkCategoryElements(IOrganizationService service, ITracingService tracingService, List<ExceptionLogEntry> exceptionLog,
            XmlDocument xmlDocument, XmlElement documentLinkElement, Guid documentLinkId)
        {
            try
            {
                // Build query to fetch data
                var documentCategoryQueryExpression = new QueryExpression("msiati_documentcategory")
                {
                    ColumnSet = new ColumnSet("msiati_category"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_documentlinkid", ConditionOperator.Equal, documentLinkId)
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> documentCategories = service.RetrieveMultiple(documentCategoryQueryExpression).Entities;
                foreach (Entity documentCategory in documentCategories)
                {
                    // Create category element
                    anyChildElement = CreateDocumentLinkCategoryIndividualElement(tracingService, exceptionLog, xmlDocument, documentLinkElement, documentCategory) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                LogException(exceptionLog, tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual document-link/category element
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="exceptionLog"></param>
        /// <param name="xmlDocument"></param>
        /// <param name="documentLinkElement"></param>
        /// <param name="documentCategory"></param>
        private static bool CreateDocumentLinkCategoryIndividualElement(ITracingService tracingService, List<ExceptionLogEntry> exceptionLog, XmlDocument xmlDocument,
            XmlElement documentLinkElement, Entity documentCategory)
        {
            try
            {
                int? categoryId = documentCategory.GetOptionSetValue("msiati_category");
                if (categoryId != null)
                {
                    string categoryCode = GetCodelistCodeByOptionSetId(Constants.DocumentCategoryIdCodeMapping, (DocumentCategory)categoryId);
                    if (!string.IsNullOrWhiteSpace(categoryCode))
                    {
                        // Create category element
                        XmlElement categoryElement = XmlUtilities.CreateChildXmlElement(xmlDocument, documentLinkElement, "category");

                        // Create code attribute
                        XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, categoryElement, "code", categoryCode);

                        return true;
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                LogException(exceptionLog, tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create document-link/language elements
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="exceptionLog"></param>
        /// <param name="xmlDocument"></param>
        /// <param name="documentLinkElement"></param>
        /// <param name="documentLinkId"></param>
        private static bool CreateDocumentLinkLanguageElements(IOrganizationService service, ITracingService tracingService, List<ExceptionLogEntry> exceptionLog,
            XmlDocument xmlDocument, XmlElement documentLinkElement, Guid documentLinkId)
        {
            try
            {
                // Build query to fetch data
                var documentLanguageQueryExpression = new QueryExpression("msiati_documentlanguage")
                {
                    ColumnSet = new ColumnSet(),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_documentlinkid", ConditionOperator.Equal, documentLinkId)
                        }
                    },
                    LinkEntities =
                    {
                        new LinkEntity(
                            "msiati_documentlanguage",
                            "msiati_nonembeddedcodelist",
                            "msiati_languageid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.Inner)
                        {
                            EntityAlias = "LanguageCode",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> documentLanguages = service.RetrieveMultiple(documentLanguageQueryExpression).Entities;
                foreach (Entity documentLanguage in documentLanguages)
                {
                    // Create language element
                    anyChildElement = CreateDocumentLinkLanguageIndividualElement(tracingService, exceptionLog, xmlDocument, documentLinkElement, documentLanguage) || anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                LogException(exceptionLog, tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual document-link/language element
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="exceptionLog"></param>
        /// <param name="xmlDocument"></param>
        /// <param name="documentLinkElement"></param>
        /// <param name="documentLanguage"></param>
        private static bool CreateDocumentLinkLanguageIndividualElement(ITracingService tracingService, List<ExceptionLogEntry> exceptionLog, XmlDocument xmlDocument,
            XmlElement documentLinkElement, Entity documentLanguage)
        {
            try
            {
                string languageCode = documentLanguage.GetAliasedValue<string>("LanguageCode.msiati_code");
                if (!string.IsNullOrWhiteSpace(languageCode))
                {
                    // Create language element
                    XmlElement languageElement = XmlUtilities.CreateChildXmlElement(xmlDocument, documentLinkElement, "language");

                    // Create code attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, languageElement, "code", languageCode);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                LogException(exceptionLog, tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create document-link/document-date element
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="exceptionLog"></param>
        /// <param name="xmlDocument"></param>
        /// <param name="documentLinkElement"></param>
        /// <param name="documentLinkConnection"></param>
        private static bool CreateDocumentLinkDocumentDateElement(ITracingService tracingService, List<ExceptionLogEntry> exceptionLog, XmlDocument xmlDocument,
            XmlElement documentLinkElement, Entity documentLinkConnection)
        {
            try
            {
                DateTime? documentDate = documentLinkConnection.GetAliasedValue<DateTime?>("DocumentLink.msiati_publicationdate");
                if (documentDate != null)
                {
                    // Create document-date element
                    XmlElement documentDateElement = XmlUtilities.CreateChildXmlElement(xmlDocument, documentLinkElement, "document-date");

                    // Create iso-date attribute
                    XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, documentDateElement, "iso-date", documentDate, Constants.DateFormatDateOnly);

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                LogException(exceptionLog, tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create document-link/recipient-country elements
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="exceptionLog"></param>
        /// <param name="xmlDocument"></param>
        /// <param name="documentLinkElement"></param>
        /// <param name="documentLinkId"></param>
        private static bool CreateDocumentLinkRecipientCountryElements(IOrganizationService service, ITracingService tracingService, List<ExceptionLogEntry> exceptionLog,
            XmlDocument xmlDocument, XmlElement documentLinkElement, Guid documentLinkId)
        {
            try
            {
                // Build query to fetch data
                var documentCountryQueryExpression = new QueryExpression("msiati_documentcountry")
                {
                    ColumnSet = new ColumnSet("msiati_name"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("msiati_documentlinkid", ConditionOperator.Equal, documentLinkId)
                        }
                    },
                    LinkEntities =
                    {
                        new LinkEntity(
                            "msiati_documentcountry",
                            "msiati_nonembeddedcodelist",
                            "msiati_countryid",
                            "msiati_nonembeddedcodelistid",
                            JoinOperator.LeftOuter)
                        {
                            EntityAlias = "Country",
                            Columns = new ColumnSet("msiati_code")
                        }
                    }
                };

                bool anyChildElement = false;
                DataCollection<Entity> documentCountries = service.RetrieveMultiple(documentCountryQueryExpression).Entities;
                foreach (Entity documentCountry in documentCountries)
                {
                    // Create recipient-country element
                    anyChildElement =
                        CreateDocumentLinkRecipientCountryIndividualElement(service, tracingService, exceptionLog, xmlDocument, documentLinkElement, documentCountry) ||
                        anyChildElement;
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                LogException(exceptionLog, tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Create individual document-link/recipient-country element
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="exceptionLog"></param>
        /// <param name="xmlDocument"></param>
        /// <param name="documentLinkElement"></param>
        /// <param name="documentCountry"></param>
        private static bool CreateDocumentLinkRecipientCountryIndividualElement(IOrganizationService service, ITracingService tracingService, List<ExceptionLogEntry> exceptionLog,
            XmlDocument xmlDocument, XmlElement documentLinkElement, Entity documentCountry)
        {
            try
            {
                // Create recipient-country element
                XmlElement recipientCountryElement = xmlDocument.CreateElement("recipient-country");

                // Create code attribute
                string countryCode = documentCountry.GetAliasedValue<string>("Country.msiati_code");
                bool anyChildElement = !string.IsNullOrWhiteSpace(countryCode);
                XmlUtilities.CreateXmlAttributeWithValueIfNotNull(xmlDocument, recipientCountryElement, "code", countryCode);

                anyChildElement =
                    CreateNarrativeElements(service, xmlDocument, recipientCountryElement, documentCountry, "msiati_name", false, documentCountry.Id,
                        NarrativeTranslationEntity.DocumentCountry, NarrativeTranslationAttribute.Name, false) || anyChildElement;

                // If any child element, add parent
                if (anyChildElement)
                {
                    documentLinkElement.AppendChild(recipientCountryElement);
                }

                return anyChildElement;
            }
            catch (Exception ex)
            {
                LogException(exceptionLog, tracingService, MethodBase.GetCurrentMethod().Name, ex);
                return false;
            }
        }

        #endregion

        #region Misc Utilities

        /// <summary>
        /// Get the Related Activity Type code by the connection role name
        /// </summary>
        /// <param name="roleName"></param>
        /// <returns></returns>
        public static string GetRelatedActivityTypeCodeByConnectionRoleName(string roleName)
        {
            switch (roleName)
            {
                case Constants.ConnectionRoleParentDeliveryFramework:
                    return "1";
                case Constants.ConnectionRoleChildDeliveryFramework:
                    return "2";
                case Constants.ConnectionRoleSiblingDeliveryFramework:
                    return "3";
                case Constants.ConnectionRoleCoFundedDeliveryFramework:
                    return "4";
                case Constants.ConnectionRoleThirdPartyDeliveryFramework:
                    return "5";
                default:
                    return null;
            }
        }

        /// <summary>
        /// Get a codelist's code by its OptionSet ID
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="T1"></typeparam>
        /// <param name="dictionary"></param>
        /// <param name="optionSetEnum"></param>
        /// <returns></returns>
        public static string GetCodelistCodeByOptionSetId<T, T1>(T dictionary, T1 optionSetEnum) where T : Dictionary<T1, string>
        {
            if (dictionary.ContainsKey(optionSetEnum))
            {
                return dictionary[optionSetEnum];
            }

            return null;
        }

        #endregion
    }
}
