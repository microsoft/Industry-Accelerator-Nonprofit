﻿using System;
using System.Collections.Generic;
using IATIXmlGeneration.Utilities;
using Microsoft.Xrm.Sdk;

namespace IATIXmlGeneration.Containers
{
    public class Transaction
    {
        public Transaction(TransactionEntity transactionEntity)
        {
            TransactionEntity = transactionEntity;
        }

        public TransactionEntity TransactionEntity { get; set; }
        public Guid Id { get; set; }
        public string Reference { get; set; }
        public string Description { get; set; }
        public bool? Humanitarian { get; set; }
        public string TransactionTypeCode { get; set; }
        public DateTime? Date { get; set; }
        public Money Amount { get; set; }
        public string CurrencyCode { get; set; }
        public DateTime? CurrencyValueDate { get; set; }
        public Guid? ProviderOrganizationId { get; set; }
        public string ProviderOrganizationName { get; set; }
        public string ProviderOrganizationIatiIdentifier { get; set; }
        public string ProviderOrganizationTypeCode { get; set; }
        public string ProviderActivityIdentifier { get; set; }
        public Guid? RecipientOrganizationId { get; set; }
        public string RecipientOrganizationName { get; set; }
        public string RecipientOrganizationIatiIdentifier { get; set; }
        public string RecipientOrganizationTypeCode { get; set; }
        public string RecipientActivityIdentifier { get; set; }
        public string DisbursementChannelCode { get; set; }
        public string RecipientCountryCode { get; set; }
        public string RecipientCountryDescription { get; set; }
        public string RecipientRegionCode { get; set; }
        public string RecipientRegionVocabularyCode { get; set; }
        public string RecipientRegionVocabularyUri { get; set; }
        public string RecipientRegionDescription { get; set; }
        public string FlowTypeCode { get; set; }
        public string FinanceTypeCode { get; set; }
        public string TiedStatusCode { get; set; }
        public List<Entity> SectorList { get; set; }
    }
}
